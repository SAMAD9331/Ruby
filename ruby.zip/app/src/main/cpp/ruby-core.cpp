#include <jni.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <cmath>
#include <cstdint>
#include <atomic>
#include <android/log.h>

#define LOG_TAG "RubyNativeCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::atomic<float> g_current_amplitude(0.0f);
static std::atomic<float> g_mouth_open_weight(0.0f);
static std::atomic<float> g_viseme_aa(0.0f);
static std::atomic<float> g_jaw_open(0.0f);
static std::atomic<float> g_breathing_offset(0.0f);
static std::atomic<float> g_time_sec(0.0f);
static std::atomic<int> g_active_emotion(0); // 0=NEUTRAL, 1=HAPPY, 2=LAUGH, 3=SURPRISED, 4=THINKING, 5=WINK, 6=SHY, 7=EXCITED, 8=LOVING, 9=ANGRY
static std::atomic<int> g_active_anim_state(0); // 0=IDLE, 1=TALKING, 2=DANCING, 3=THINKING, 4=EXCITED, 5=GUITAR, 6=SHY
static std::atomic<float> g_anim_playback_speed(1.0f);
static std::atomic<int> g_imported_anim_count(0);

struct CppAnimationTrack {
    char name[64];
    float duration;
    int keyframeCount;
    bool isLooping;
};

static CppAnimationTrack g_imported_tracks[16];

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_nativecore_RubyNativeCore_initializeCore(JNIEnv *env, jobject instance) {
    g_current_amplitude.store(0.0f);
    g_mouth_open_weight.store(0.0f);
    g_viseme_aa.store(0.0f);
    g_jaw_open.store(0.0f);
    g_breathing_offset.store(0.0f);
    g_time_sec.store(0.0f);
    LOGI("Ruby C++ Native Core Initialized Successfully!");
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_example_nativecore_RubyNativeCore_processAudioFrame(JNIEnv *env, jobject instance, jbyteArray pcm_data) {
    if (pcm_data == nullptr) return;

    jsize len = env->GetArrayLength(pcm_data);
    if (len <= 0) return;

    jbyte* samples = env->GetByteArrayElements(pcm_data, nullptr);
    if (samples == nullptr) return;

    // Process 16-bit PCM Audio Buffer
    int num_samples = len / 2;
    if (num_samples > 0) {
        double sum_squares = 0.0;
        for (int i = 0; i < num_samples; i++) {
            int16_t sample = static_cast<int16_t>((samples[2 * i] & 0xFF) | (samples[2 * i + 1] << 8));
            double norm = sample / 32768.0;
            sum_squares += norm * norm;
        }

        float rms = std::sqrt(sum_squares / num_samples);
        float amp = std::min(1.0f, rms * 3.0f); // Gain boost
        g_current_amplitude.store(amp);

        // Blendshape morph target calculations
        float mouth = std::min(1.0f, amp * 1.5f);
        g_mouth_open_weight.store(mouth);
        g_viseme_aa.store(std::min(1.0f, mouth * 1.2f));
        g_jaw_open.store(mouth * 0.85f);
    }

    env->ReleaseByteArrayElements(pcm_data, samples, JNI_ABORT);
}

JNIEXPORT jfloat JNICALL
Java_com_example_nativecore_RubyNativeCore_getMouthOpenWeight(JNIEnv *env, jobject instance) {
    return g_mouth_open_weight.load();
}

JNIEXPORT jfloat JNICALL
Java_com_example_nativecore_RubyNativeCore_getBreathingOffset(JNIEnv *env, jobject instance) {
    float t = g_time_sec.load();
    t += 0.016f; // 60 FPS tick
    g_time_sec.store(t);

    float breathY = 0.025f * std::sin(t * 2.2f);
    g_breathing_offset.store(breathY);
    return breathY;
}

JNIEXPORT jstring JNICALL
Java_com_example_nativecore_RubyNativeCore_getEngineVersion(JNIEnv *env, jobject instance) {
    std::string version = "Ruby Native Core Engine v3.5 [3D Filament & VTuber C++17]";
    return env->NewStringUTF(version.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_nativecore_RubyNativeCore_analyzeIntentNative(JNIEnv *env, jobject instance, jstring input_text) {
    const char *native_str = env->GetStringUTFChars(input_text, nullptr);
    std::string text(native_str ? native_str : "");
    if (native_str) env->ReleaseStringUTFChars(input_text, native_str);

    std::string lower = text;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);

    std::string intent = "GENERAL_CHAT";
    if (lower.find("volume") != std::string::npos || lower.find("torch") != std::string::npos ||
        lower.find("video") != std::string::npos || lower.find("clipboard") != std::string::npos ||
        lower.find("screenshot") != std::string::npos) {
        intent = "SYSTEM_CONTROL";
    } else if (lower.find("kholo") != std::string::npos || lower.find("open") != std::string::npos ||
               lower.find("capcut") != std::string::npos || lower.find("youtube") != std::string::npos ||
               lower.find("whatsapp") != std::string::npos) {
        intent = "APP_LAUNCH";
    } else if (lower.find("draw") != std::string::npos || lower.find("image") != std::string::npos ||
               lower.find("photo") != std::string::npos || lower.find("logo") != std::string::npos) {
        intent = "IMAGE_GENERATION";
    }

    return env->NewStringUTF(intent.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_nativecore_RubyNativeCore_processAutomationQueryNative(JNIEnv *env, jobject instance, jstring query) {
    const char *native_query = env->GetStringUTFChars(query, nullptr);
    std::string text(native_query ? native_query : "");
    if (native_query) env->ReleaseStringUTFChars(query, native_query);

    std::string result = "[NATIVE_AUTOMATION_PROCESSED]: " + text;
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_nativecore_RubyNativeCore_optimizePromptNative(JNIEnv *env, jobject instance, jstring raw_prompt) {
    const char *native_prompt = env->GetStringUTFChars(raw_prompt, nullptr);
    std::string text(native_prompt ? native_prompt : "");
    if (native_prompt) env->ReleaseStringUTFChars(raw_prompt, native_prompt);

    std::string optimized = "[RUBY_NATIVE_CORE_PROMPT]: " + text;
    return env->NewStringUTF(optimized.c_str());
}

JNIEXPORT void JNICALL
Java_com_example_nativecore_RubyNativeCore_setEmotionNative(JNIEnv *env, jobject instance, jint emotion_code) {
    g_active_emotion.store(emotion_code);
    LOGI("Ruby Native Core Emotion Updated to Code: %d", emotion_code);
}

// --- High FPS 3D VTuber & Filament NDK Engine Math Bridges ---

JNIEXPORT jfloatArray JNICALL
Java_com_example_nativecore_RubyNativeCore_calculate3DMorphTargetsNative(
        JNIEnv *env, jobject instance, jfloat audio_amplitude, jfloat time_sec) {

    // Output array: [mouthOpen, jawTranslation, lipStretch, eyeBlink]
    float effectiveAmp = std::max(audio_amplitude, g_mouth_open_weight.load());
    int emotion = g_active_emotion.load();

    // Base morph calculations modulated by audio amplitude & lip-sync
    float mouthOpen = std::min(1.0f, std::max(0.0f, effectiveAmp * 1.45f + 0.15f * std::sin(time_sec * 12.0f)));
    float jawTranslation = mouthOpen * 0.08f;
    float lipStretch = 0.3f * std::cos(time_sec * 8.0f) * effectiveAmp;

    // Emotion Blendshape Modifiers
    // Emotion codes: 1=HAPPY, 2=LAUGH, 3=SURPRISED, 4=THINKING, 5=WINK, 6=SHY, 7=EXCITED, 8=LOVING, 9=ANGRY
    if (emotion == 1 || emotion == 7 || emotion == 8) { // HAPPY, EXCITED, LOVING
        lipStretch += 0.55f;
    } else if (emotion == 2) { // LAUGH
        lipStretch += 0.75f;
        mouthOpen = std::max(mouthOpen, 0.35f + 0.15f * std::sin(time_sec * 14.0f));
    } else if (emotion == 3) { // SURPRISED
        mouthOpen = std::max(mouthOpen, 0.45f);
        jawTranslation = mouthOpen * 0.12f;
    } else if (emotion == 4 || emotion == 9) { // THINKING, ANGRY
        lipStretch -= 0.30f;
    } else if (emotion == 5) { // WINK
        lipStretch += 0.40f;
    } else if (emotion == 6) { // SHY
        lipStretch += 0.25f;
    }

    // Organic Eye Blink & Emotion Squint
    float blinkPhase = std::fmod(time_sec, 3.5f);
    float eyeBlink = 0.0f;
    if (blinkPhase > 3.3f) {
        eyeBlink = std::sin((blinkPhase - 3.3f) / 0.2f * 3.14159f);
    }
    if (emotion == 5) { // Forced Wink
        eyeBlink = std::max(eyeBlink, 0.85f);
    } else if (emotion == 2 || emotion == 8) { // Laugh / Loving Squint
        eyeBlink = std::max(eyeBlink, 0.35f);
    }

    jfloatArray result = env->NewFloatArray(4);
    if (result != nullptr) {
        jfloat values[4] = {mouthOpen, jawTranslation, lipStretch, eyeBlink};
        env->SetFloatArrayRegion(result, 0, 4, values);
    }
    return result;
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_nativecore_RubyNativeCore_computeVTuber3DInertiaNative(
        JNIEnv *env, jobject instance, jfloat delta_time, jfloat current_time_sec) {

    // Output array: [breathDisplacementY, hipSwayX, shoulderPitchZ, hairInertiaX]
    float breathY = 0.025f * std::sin(current_time_sec * 2.2f);
    float hipSwayX = 0.015f * std::cos(current_time_sec * 1.1f);
    float shoulderZ = 0.01f * std::sin(current_time_sec * 1.8f);
    float hairInertiaX = 0.02f * std::sin(current_time_sec * 3.5f);

    jfloatArray result = env->NewFloatArray(4);
    if (result != nullptr) {
        jfloat values[4] = {breathY, hipSwayX, shoulderZ, hairInertiaX};
        env->SetFloatArrayRegion(result, 0, 4, values);
    }
    return result;
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_nativecore_RubyNativeCore_calculate3DTouchRotationNative(
        JNIEnv *env, jobject instance, jfloat drag_dx, jfloat drag_dy, jfloat current_pitch, jfloat current_yaw) {

    float targetYaw = current_yaw + drag_dx * 0.45f;
    float targetPitch = current_pitch - drag_dy * 0.45f;

    targetPitch = std::min(35.0f, std::max(-35.0f, targetPitch));
    targetYaw = std::min(75.0f, std::max(-75.0f, targetYaw));

    jfloatArray result = env->NewFloatArray(2);
    if (result != nullptr) {
        jfloat values[2] = {targetPitch, targetYaw};
        env->SetFloatArrayRegion(result, 0, 2, values);
    }
    return result;
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_nativecore_RubyNativeCore_scanPackageSecurityNative(
        JNIEnv *env, jobject instance, jint permissionCount, jint dangerousPermCount,
        jfloat dataUsageMB, jboolean isSystemApp, jboolean isSideloaded) {

    float riskScore = 0.0f;
    riskScore += dangerousPermCount * 14.5f;
    riskScore += (permissionCount - dangerousPermCount) * 1.2f;

    if (isSideloaded && !isSystemApp) riskScore += 25.0f;
    if (dataUsageMB > 1024.0f) riskScore += 30.0f;
    else if (dataUsageMB > 250.0f) riskScore += 15.0f;

    if (isSystemApp) riskScore *= 0.25f;
    riskScore = std::min(100.0f, std::max(0.0f, riskScore));

    float threatType = 0.0f;
    if (riskScore >= 75.0f) threatType = 4.0f;
    else if (riskScore >= 55.0f) threatType = 3.0f;
    else if (dataUsageMB > 500.0f && riskScore >= 40.0f) threatType = 2.0f;
    else if (riskScore >= 25.0f) threatType = 1.0f;

    float severity = 0.0f;
    if (threatType == 4.0f) severity = 3.0f;
    else if (threatType == 3.0f || threatType == 2.0f) severity = 2.0f;
    else if (threatType == 1.0f) severity = 1.0f;

    jfloatArray result = env->NewFloatArray(3);
    if (result != nullptr) {
        jfloat values[3] = {riskScore, threatType, severity};
        env->SetFloatArrayRegion(result, 0, 3, values);
    }
    return result;
}

JNIEXPORT jint JNICALL
Java_com_example_nativecore_RubyNativeCore_evaluateSystemIntegrityNative(
        JNIEnv *env, jobject instance, jboolean isRooted, jboolean isAdbEnabled,
        jboolean isUnknownSourcesAllowed, jboolean isVpnActive) {

    int securityHealthScore = 100;
    if (isRooted) securityHealthScore -= 35;
    if (isAdbEnabled) securityHealthScore -= 15;
    if (isUnknownSourcesAllowed) securityHealthScore -= 20;
    if (isVpnActive) securityHealthScore -= 10;

    return std::max(0, std::min(100, securityHealthScore));
}

// --- C++ NDK Automated 3D Animation Importer & Evaluator Engine ---

JNIEXPORT jint JNICALL
Java_com_example_nativecore_RubyNativeCore_importAnimationTrackNative(
        JNIEnv *env, jobject instance, jstring anim_name, jfloat duration_sec, jint keyframe_count, jboolean is_looping) {

    int currentIdx = g_imported_anim_count.load();
    if (currentIdx >= 16) {
        LOGE("C++ Animation Registry full (max 16 tracks)");
        return currentIdx;
    }

    const char *native_name = env->GetStringUTFChars(anim_name, nullptr);
    if (native_name) {
        snprintf(g_imported_tracks[currentIdx].name, sizeof(g_imported_tracks[currentIdx].name), "%s", native_name);
        env->ReleaseStringUTFChars(anim_name, native_name);
    } else {
        snprintf(g_imported_tracks[currentIdx].name, sizeof(g_imported_tracks[currentIdx].name), "anim_track_%d", currentIdx);
    }

    g_imported_tracks[currentIdx].duration = duration_sec > 0.1f ? duration_sec : 2.5f;
    g_imported_tracks[currentIdx].keyframeCount = keyframe_count > 0 ? keyframe_count : 30;
    g_imported_tracks[currentIdx].isLooping = is_looping;

    g_imported_anim_count.store(currentIdx + 1);
    LOGI("Imported 3D Animation Track [%d] into C++ Engine: '%s' (Dur: %.2fs, Keys: %d)",
         currentIdx, g_imported_tracks[currentIdx].name, duration_sec, keyframe_count);

    return currentIdx;
}

JNIEXPORT void JNICALL
Java_com_example_nativecore_RubyNativeCore_setAnimationStateNative(
        JNIEnv *env, jobject instance, jint anim_state_code, jfloat playback_speed) {
    g_active_anim_state.store(anim_state_code);
    g_anim_playback_speed.store(std::max(0.1f, std::min(5.0f, playback_speed)));
    LOGI("Set C++ Automated 3D Animation State Code: %d (Speed: %.2f)", anim_state_code, playback_speed);
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_nativecore_RubyNativeCore_evaluateAutomated3DAnimationNative(
        JNIEnv *env, jobject instance, jfloat current_time_sec, jfloat delta_time, jfloat audio_amplitude, jboolean is_speaking) {

    // Output 12 floats:
    // [0:headPitch, 1:headYaw, 2:headRoll, 3:armRightPitch, 4:armLeftPitch, 5:spineSway, 6:legSway, 7:mouthVisemeOpen, 8:eyeBlink, 9:hairInertia, 10:scaleX, 11:scaleY]

    float speed = g_anim_playback_speed.load();
    float t = current_time_sec * speed;
    int animState = g_active_anim_state.load();
    if (is_speaking && animState == 0) {
        animState = 1; // Auto-switch to TALKING animation when voice speaking
    }

    float headPitch = 0.0f;
    float headYaw = 0.0f;
    float headRoll = 0.0f;
    float armRightPitch = 0.0f;
    float armLeftPitch = 0.0f;
    float spineSway = 0.0f;
    float legSway = 0.0f;
    float scaleX = 1.0f;
    float scaleY = 1.0f;

    // Automated C++ Procedural + Imported Animation Interpolation
    switch (animState) {
        case 1: // TALKING / SPEAKING
            headPitch = 0.08f * std::sin(t * 6.0f) + 0.03f * std::cos(t * 11.0f);
            headYaw = 0.12f * std::sin(t * 4.5f);
            headRoll = 0.05f * std::sin(t * 3.2f);
            armRightPitch = 0.15f * std::sin(t * 5.0f) + audio_amplitude * 0.3f;
            armLeftPitch = -0.12f * std::cos(t * 4.8f);
            spineSway = 0.03f * std::sin(t * 2.5f);
            scaleY = 1.0f + 0.015f * std::sin(t * 6.0f);
            break;

        case 2: // DANCING
            headPitch = 0.15f * std::sin(t * 8.0f);
            headYaw = 0.25f * std::cos(t * 6.0f);
            headRoll = 0.10f * std::sin(t * 7.0f);
            armRightPitch = 0.45f * std::sin(t * 7.5f);
            armLeftPitch = 0.45f * std::cos(t * 7.5f);
            spineSway = 0.08f * std::sin(t * 5.0f);
            legSway = 0.12f * std::cos(t * 5.0f);
            scaleX = 1.0f + 0.03f * std::cos(t * 8.0f);
            scaleY = 1.0f + 0.03f * std::sin(t * 8.0f);
            break;

        case 3: // THINKING
            headPitch = -0.18f;
            headYaw = 0.15f * std::sin(t * 1.5f);
            headRoll = 0.12f;
            armRightPitch = 0.35f;
            armLeftPitch = -0.05f;
            spineSway = 0.015f * std::sin(t * 1.2f);
            break;

        case 4: // EXCITED / HAPPY BOUNCE
            headPitch = 0.12f * std::abs(std::sin(t * 10.0f));
            headYaw = 0.10f * std::sin(t * 8.0f);
            armRightPitch = 0.50f * std::sin(t * 9.0f);
            armLeftPitch = 0.50f * std::sin(t * 9.0f + 0.5f);
            spineSway = 0.04f * std::sin(t * 6.0f);
            scaleY = 1.0f + 0.04f * std::abs(std::sin(t * 10.0f));
            break;

        case 5: // GUITAR PLAYING
            headPitch = 0.10f * std::sin(t * 4.0f);
            headYaw = -0.15f;
            armRightPitch = 0.65f + 0.20f * std::sin(t * 12.0f); // Strumming motion
            armLeftPitch = 0.30f + 0.08f * std::cos(t * 6.0f); // Fretting motion
            spineSway = 0.04f * std::sin(t * 3.0f);
            break;

        case 6: // SHY
            headPitch = 0.15f;
            headYaw = -0.20f * std::sin(t * 1.8f);
            headRoll = -0.08f;
            armRightPitch = -0.10f;
            armLeftPitch = -0.10f;
            spineSway = 0.01f * std::sin(t * 1.5f);
            break;

        case 0: // IDLE / BREATHING DEFAULT
        default:
            headPitch = 0.03f * std::sin(t * 2.2f);
            headYaw = 0.04f * std::cos(t * 1.4f);
            headRoll = 0.02f * std::sin(t * 1.8f);
            armRightPitch = 0.05f * std::sin(t * 2.0f);
            armLeftPitch = -0.05f * std::sin(t * 2.0f);
            spineSway = 0.02f * std::sin(t * 1.8f);
            legSway = 0.01f * std::cos(t * 1.2f);
            scaleY = 1.0f + 0.008f * std::sin(t * 2.2f);
            break;
    }

    // Mouth Viseme & Eye Blink Calculation
    float mouthVisemeOpen = std::min(1.0f, std::max(0.0f, audio_amplitude * 1.45f + 0.15f * std::sin(t * 12.0f)));
    if (is_speaking) {
        mouthVisemeOpen = std::max(mouthVisemeOpen, 0.30f + 0.25f * std::abs(std::sin(t * 14.0f)));
    }

    float blinkPhase = std::fmod(t, 3.8f);
    float eyeBlink = (blinkPhase > 3.6f) ? std::sin((blinkPhase - 3.6f) / 0.2f * 3.14159f) : 0.0f;
    float hairInertia = 0.03f * std::sin(t * 4.2f) + headYaw * 0.5f;

    jfloatArray result = env->NewFloatArray(12);
    if (result != nullptr) {
        jfloat values[12] = {
            headPitch, headYaw, headRoll,
            armRightPitch, armLeftPitch,
            spineSway, legSway,
            mouthVisemeOpen, eyeBlink, hairInertia,
            scaleX, scaleY
        };
        env->SetFloatArrayRegion(result, 0, 12, values);
    }
    return result;
}

}
