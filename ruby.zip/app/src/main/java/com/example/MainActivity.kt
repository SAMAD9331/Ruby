package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.RubyAppBuilderScreen
import com.example.ui.screens.RubyAssistantScreen
import com.example.ui.screens.RubySecurityScreen
import com.example.ui.screens.RubyYouTubeScreen
import com.example.ui.theme.*
import com.example.viewmodel.RubyViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val viewModel = ViewModelProvider(this)[RubyViewModel::class.java]

        setContent {
            MyApplicationTheme {
                var selectedTab by remember { mutableStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = RubySurface,
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.SmartToy, contentDescription = "Ruby Assistant") },
                                label = { Text("Ruby AI", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    unselectedIconColor = RubyTextMuted,
                                    selectedTextColor = RubyRed,
                                    unselectedTextColor = RubyTextMuted,
                                    indicatorColor = RubyRed
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.DeveloperMode, contentDescription = "App Creator") },
                                label = { Text("App Builder", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    unselectedIconColor = RubyTextMuted,
                                    selectedTextColor = RubyRed,
                                    unselectedTextColor = RubyTextMuted,
                                    indicatorColor = RubyRed
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "YouTube studio") },
                                label = { Text("YouTube", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    unselectedIconColor = RubyTextMuted,
                                    selectedTextColor = RubyRed,
                                    unselectedTextColor = RubyTextMuted,
                                    indicatorColor = RubyRed
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Security, contentDescription = "Security Guard") },
                                label = { Text("Security", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    unselectedIconColor = RubyTextMuted,
                                    selectedTextColor = RubyRed,
                                    unselectedTextColor = RubyTextMuted,
                                    indicatorColor = RubyRed
                                )
                            )
                        }
                    },
                    containerColor = RubyBg
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            0 -> RubyAssistantScreen(viewModel = viewModel)
                            1 -> RubyAppBuilderScreen(viewModel = viewModel)
                            2 -> RubyYouTubeScreen(viewModel = viewModel)
                            3 -> RubySecurityScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
