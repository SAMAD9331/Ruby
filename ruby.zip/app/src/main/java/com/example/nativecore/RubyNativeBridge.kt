package com.example.nativecore

import android.util.Log

/**
 * Ruby AI JNI Bridge for High-Performance NDK C++ Core.
 *
 * Exposes thread-safe native operations for:
 * 1. Real-time PCM audio amplitude & lip-sync processing at 60 FPS
 * 2. Morph target blendshapes calculation (viseme_AA, jawOpen, mouthOpen)
 * 3. Procedural motion engine (chest breathing expansion & sway)
 * 4. High-level security and intent classification
 */
object RubyNativeBridge {

    private const val TAG = "RubyNativeBridge"

    /**
     * Initializes native core engine structures and resets state.
     */
    fun initializeCore(): Boolean {
        return if (RubyNativeCore.isNativeReady()) {
            try {
                RubyNativeCore.initializeCore()
            } catch (e: Throwable) {
                Log.e(TAG, "Error initializing native core", e)
                false
            }
        } else {
            Log.w(TAG, "Native library not ready during initializeCore call")
            false
        }
    }

    /**
     * Feeds real-time PCM audio buffer (from TTS / ElevenLabs stream) into native core to calculate amplitude & blendshapes.
     */
    fun processAudioFrame(pcmData: ByteArray) {
        if (RubyNativeCore.isNativeReady()) {
            try {
                RubyNativeCore.processAudioFrame(pcmData)
            } catch (e: Throwable) {
                Log.e(TAG, "Error in processAudioFrame", e)
            }
        }
    }

    /**
     * Returns the current mouth open weight calculated by the native audio engine (0.0f - 1.0f).
     */
    fun getMouthOpenWeight(): Float {
        return if (RubyNativeCore.isNativeReady()) {
            try {
                RubyNativeCore.getMouthOpenWeight()
            } catch (e: Throwable) {
                0.0f
            }
        } else {
            0.0f
        }
    }

    /**
     * Returns current procedural sine-wave chest breathing offset calculated by native core.
     */
    fun getBreathingOffset(): Float {
        return if (RubyNativeCore.isNativeReady()) {
            try {
                RubyNativeCore.getBreathingOffset()
            } catch (e: Throwable) {
                0.0f
            }
        } else {
            0.0f
        }
    }

    /**
     * Calculates dynamic 3D blendshapes array: [mouthOpen, jawTranslation, lipStretch, eyeBlink]
     */
    fun calculate3DMorphTargets(audioAmplitude: Float, timeSec: Float): FloatArray {
        return RubyNativeCore.calculate3DMorphTargets(audioAmplitude, timeSec)
    }

    /**
     * Computes full body procedural inertia array: [breathDisplacementY, hipSwayX, shoulderPitchZ, hairInertiaX]
     */
    fun computeVTuber3DInertia(deltaTime: Float, currentTimeSec: Float): FloatArray {
        return RubyNativeCore.computeVTuber3DInertia(deltaTime, currentTimeSec)
    }

    /**
     * Computes touch drag rotation delta array: [targetPitch, targetYaw]
     */
    fun calculate3DTouchRotation(dragDx: Float, dragDy: Float, currentPitch: Float, currentYaw: Float): FloatArray {
        return RubyNativeCore.calculate3DTouchRotation(dragDx, dragDy, currentPitch, currentYaw)
    }

    /**
     * Updates active emotion code (0-9) in native C++ core to dynamically modulate 3D blendshapes.
     */
    fun setEmotion(emotionCode: Int) {
        if (RubyNativeCore.isNativeReady()) {
            try {
                RubyNativeCore.setEmotion(emotionCode)
            } catch (e: Throwable) {
                Log.e(TAG, "Error setting native emotion code", e)
            }
        }
    }

    /**
     * Safe call to retrieve C++ Native Engine version info string.
     */
    fun getEngineVersion(): String {
        return RubyNativeCore.getEngineVersionSafe()
    }
}
