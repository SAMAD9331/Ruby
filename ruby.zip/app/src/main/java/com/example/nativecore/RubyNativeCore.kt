package com.example.nativecore

import android.util.Log

object RubyNativeCore {

    private var isNativeLibraryLoaded = false

    init {
        try {
            System.loadLibrary("ruby-core")
            isNativeLibraryLoaded = true
            Log.i("RubyNativeCore", "Successfully loaded native library 'ruby-core'")
        } catch (e: Throwable) {
            isNativeLibraryLoaded = false
            Log.w("RubyNativeCore", "Native library 'ruby-core' not loaded: ${e.message}. Using high-performance fallback engine.")
        }
    }

    fun isNativeReady(): Boolean = isNativeLibraryLoaded

    external fun initializeCore(): Boolean
    external fun processAudioFrame(pcmData: ByteArray)
    external fun getMouthOpenWeight(): Float
    external fun getBreathingOffset(): Float

    external fun getEngineVersion(): String
    external fun setEmotionNative(emotionCode: Int)
    external fun analyzeIntentNative(inputText: String): String
    external fun processAutomationQueryNative(query: String): String
    external fun optimizePromptNative(rawPrompt: String): String
    external fun calculate3DMorphTargetsNative(audioAmplitude: Float, timeSec: Float): FloatArray
    external fun computeVTuber3DInertiaNative(deltaTime: Float, currentTimeSec: Float): FloatArray
    external fun calculate3DTouchRotationNative(dragDx: Float, dragDy: Float, currentPitch: Float, currentYaw: Float): FloatArray
    external fun scanPackageSecurityNative(permissionCount: Int, dangerousPermCount: Int, dataUsageMB: Float, isSystemApp: Boolean, isSideloaded: Boolean): FloatArray
    external fun evaluateSystemIntegrityNative(isRooted: Boolean, isAdbEnabled: Boolean, isUnknownSourcesAllowed: Boolean, isVpnActive: Boolean): Int
    external fun importAnimationTrackNative(animName: String, durationSec: Float, keyframeCount: Int, isLooping: Boolean): Int
    external fun setAnimationStateNative(animStateCode: Int, playbackSpeed: Float)
    external fun evaluateAutomated3DAnimationNative(currentTimeSec: Float, deltaTime: Float, audioAmplitude: Float, isSpeaking: Boolean): FloatArray

    fun scanPackageSecurity(permissionCount: Int, dangerousPermCount: Int, dataUsageMB: Float, isSystemApp: Boolean, isSideloaded: Boolean): FloatArray {
        if (isNativeLibraryLoaded) {
            try {
                return scanPackageSecurityNative(permissionCount, dangerousPermCount, dataUsageMB, isSystemApp, isSideloaded)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native scan package security fallback", e)
            }
        }
        var riskScore = (dangerousPermCount * 14.5f) + ((permissionCount - dangerousPermCount) * 1.2f)
        if (isSideloaded && !isSystemApp) riskScore += 25f
        if (dataUsageMB > 1024f) riskScore += 30f else if (dataUsageMB > 250f) riskScore += 15f
        if (isSystemApp) riskScore *= 0.25f
        riskScore = riskScore.coerceIn(0f, 100f)
        val threatType = when {
            riskScore >= 75f -> 4f
            riskScore >= 55f -> 3f
            dataUsageMB > 500f && riskScore >= 40f -> 2f
            riskScore >= 25f -> 1f
            else -> 0f
        }
        val severity = when (threatType) {
            4f -> 3f
            3f, 2f -> 2f
            1f -> 1f
            else -> 0f
        }
        return floatArrayOf(riskScore, threatType, severity)
    }

    fun evaluateSystemIntegrity(isRooted: Boolean, isAdbEnabled: Boolean, isUnknownSourcesAllowed: Boolean, isVpnActive: Boolean): Int {
        if (isNativeLibraryLoaded) {
            try {
                return evaluateSystemIntegrityNative(isRooted, isAdbEnabled, isUnknownSourcesAllowed, isVpnActive)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native evaluate system integrity fallback", e)
            }
        }
        var score = 100
        if (isRooted) score -= 35
        if (isAdbEnabled) score -= 15
        if (isUnknownSourcesAllowed) score -= 20
        if (isVpnActive) score -= 10
        return score.coerceIn(0, 100)
    }

    fun calculate3DMorphTargets(audioAmplitude: Float, timeSec: Float): FloatArray {
        if (isNativeLibraryLoaded) {
            try {
                return calculate3DMorphTargetsNative(audioAmplitude, timeSec)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native morph calculation fallback", e)
            }
        }
        val mouthOpen = (audioAmplitude * 1.45f + 0.15f * kotlin.math.sin(timeSec * 12.0f)).coerceIn(0f, 1f)
        val jawTranslation = mouthOpen * 0.08f
        val lipStretch = 0.3f * kotlin.math.cos(timeSec * 8.0f) * audioAmplitude
        val blinkPhase = timeSec % 3.5f
        val eyeBlink = if (blinkPhase > 3.3f) kotlin.math.sin((blinkPhase - 3.3f) / 0.2f * Math.PI.toFloat()) else 0f
        return floatArrayOf(mouthOpen, jawTranslation, lipStretch, eyeBlink)
    }

    fun computeVTuber3DInertia(deltaTime: Float, currentTimeSec: Float): FloatArray {
        if (isNativeLibraryLoaded) {
            try {
                return computeVTuber3DInertiaNative(deltaTime, currentTimeSec)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native VTuber inertia fallback", e)
            }
        }
        val breathY = 0.025f * kotlin.math.sin(currentTimeSec * 2.2f)
        val hipSwayX = 0.015f * kotlin.math.cos(currentTimeSec * 1.1f)
        val shoulderZ = 0.01f * kotlin.math.sin(currentTimeSec * 1.8f)
        val hairInertiaX = 0.02f * kotlin.math.sin(currentTimeSec * 3.5f)
        return floatArrayOf(breathY, hipSwayX, shoulderZ, hairInertiaX)
    }

    fun calculate3DTouchRotation(dragDx: Float, dragDy: Float, currentPitch: Float, currentYaw: Float): FloatArray {
        if (isNativeLibraryLoaded) {
            try {
                return calculate3DTouchRotationNative(dragDx, dragDy, currentPitch, currentYaw)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native touch rotation fallback", e)
            }
        }
        val targetYaw = (currentYaw + dragDx * 0.45f).coerceIn(-75f, 75f)
        val targetPitch = (currentPitch - dragDy * 0.45f).coerceIn(-35f, 35f)
        return floatArrayOf(targetPitch, targetYaw)
    }

    fun setEmotion(emotionCode: Int) {
        if (isNativeLibraryLoaded) {
            try {
                setEmotionNative(emotionCode)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native set emotion error", e)
            }
        }
    }

    // High-performance safe caller with native execution & zero-crash fallback
    fun getEngineVersionSafe(): String {
        return if (isNativeLibraryLoaded) {
            try {
                getEngineVersion()
            } catch (e: Throwable) {
                "Ruby Core Engine v3.0 [Kotlin High-Perf Layer]"
            }
        } else {
            "Ruby Core Engine v3.0 [Kotlin High-Perf Layer]"
        }
    }

    fun analyzeIntent(inputText: String): String {
        if (isNativeLibraryLoaded) {
            try {
                return analyzeIntentNative(inputText)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native intent analysis error", e)
            }
        }
        // Ultra-fast algorithmic fallback
        val lower = inputText.lowercase()
        return when {
            lower.contains("volume") || lower.contains("torch") || lower.contains("video") || lower.contains("clipboard") || lower.contains("screenshot") -> "SYSTEM_CONTROL"
            lower.contains("kholo") || lower.contains("open") || lower.contains("capcut") || lower.contains("youtube") || lower.contains("whatsapp") -> "APP_LAUNCH"
            lower.contains("draw") || lower.contains("image") || lower.contains("photo") || lower.contains("logo") -> "IMAGE_GENERATION"
            else -> "GENERAL_CHAT"
        }
    }

    fun processAutomationQuery(query: String): String {
        if (isNativeLibraryLoaded) {
            try {
                return processAutomationQueryNative(query)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native automation processing error", e)
            }
        }
        return "[RUBY_ENGINE_PROCESSED]: $query"
    }

    fun optimizePrompt(rawPrompt: String): String {
        if (isNativeLibraryLoaded) {
            try {
                return optimizePromptNative(rawPrompt)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native prompt optimization error", e)
            }
        }
        return rawPrompt.trim()
    }

    fun importAnimationTrack(animName: String, durationSec: Float = 2.5f, keyframeCount: Int = 30, isLooping: Boolean = true): Int {
        if (isNativeLibraryLoaded) {
            try {
                return importAnimationTrackNative(animName, durationSec, keyframeCount, isLooping)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native import animation track error", e)
            }
        }
        return 0
    }

    fun setAnimationState(animStateCode: Int, playbackSpeed: Float = 1.0f) {
        if (isNativeLibraryLoaded) {
            try {
                setAnimationStateNative(animStateCode, playbackSpeed)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native set animation state error", e)
            }
        }
    }

    fun evaluateAutomated3DAnimation(currentTimeSec: Float, deltaTime: Float = 0.016f, audioAmplitude: Float = 0f, isSpeaking: Boolean = false): FloatArray {
        if (isNativeLibraryLoaded) {
            try {
                return evaluateAutomated3DAnimationNative(currentTimeSec, deltaTime, audioAmplitude, isSpeaking)
            } catch (e: Throwable) {
                Log.e("RubyNativeCore", "Native evaluate automated animation error", e)
            }
        }
        val headPitch = 0.03f * kotlin.math.sin(currentTimeSec * 2.2f)
        val headYaw = 0.04f * kotlin.math.cos(currentTimeSec * 1.4f)
        val headRoll = 0.02f * kotlin.math.sin(currentTimeSec * 1.8f)
        val mouthVisemeOpen = (audioAmplitude * 1.45f).coerceIn(0f, 1f)
        val eyeBlink = 0f
        return floatArrayOf(headPitch, headYaw, headRoll, 0.05f, -0.05f, 0.02f, 0.01f, mouthVisemeOpen, eyeBlink, 0.02f, 1.0f, 1.0f)
    }
}
