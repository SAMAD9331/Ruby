package com.example.data.repository

import com.example.BuildConfig
import com.example.data.database.RubyDao
import com.example.data.model.*
import com.example.data.network.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class RubyRepository(private val rubyDao: RubyDao) {

    // Database Flows
    val allMessages: Flow<List<ChatMessage>> = rubyDao.getAllMessages()
    val allProjects: Flow<List<GeneratedProject>> = rubyDao.getAllProjects()
    val allMemoryLogs: Flow<List<MemoryLog>> = rubyDao.getAllMemoryLogs()
    val allYouTubeDrafts: Flow<List<YouTubeDraft>> = rubyDao.getAllYouTubeDrafts()
    val allUserMemories: Flow<List<UserMemory>> = rubyDao.getAllUserMemories()

    fun getFilesForProject(projectId: Int): Flow<List<ProjectFile>> = rubyDao.getFilesByProject(projectId)

    // DB Operations
    suspend fun insertMessage(message: ChatMessage) = withContext(Dispatchers.IO) {
        rubyDao.insertMessage(message)
    }

    suspend fun clearChat() = withContext(Dispatchers.IO) {
        rubyDao.clearChat()
    }

    suspend fun createProject(name: String, desc: String, type: String, path: String): Long = withContext(Dispatchers.IO) {
        val project = GeneratedProject(
            projectName = name,
            projectDescription = desc,
            projectType = type,
            storageFolderPath = path
        )
        rubyDao.insertProject(project)
    }

    suspend fun getProjectById(projectId: Int): GeneratedProject? = withContext(Dispatchers.IO) {
        rubyDao.getProjectById(projectId)
    }

    suspend fun addProjectFile(projectId: Int, fileName: String, content: String, relPath: String) = withContext(Dispatchers.IO) {
        val file = ProjectFile(
            projectId = projectId,
            fileName = fileName,
            fileContent = content,
            relativePath = relPath
        )
        rubyDao.insertProjectFile(file)
    }

    suspend fun getProjectFilesSync(projectId: Int): List<ProjectFile> = withContext(Dispatchers.IO) {
        rubyDao.getFilesByProjectSync(projectId)
    }

    suspend fun deleteProject(projectId: Int) = withContext(Dispatchers.IO) {
        rubyDao.deleteFilesByProject(projectId)
        rubyDao.deleteProjectById(projectId)
    }

    suspend fun logMemory(description: String, type: String, status: String) = withContext(Dispatchers.IO) {
        val log = MemoryLog(
            taskDescription = description,
            taskType = type,
            status = status
        )
        rubyDao.insertMemoryLog(log)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        rubyDao.clearLogs()
    }

    suspend fun createYouTubeDraft(title: String, desc: String, tags: String, replies: String): Long = withContext(Dispatchers.IO) {
        val draft = YouTubeDraft(
            videoTitle = title,
            videoDescription = desc,
            suggestedTags = tags,
            autoReplies = replies
        )
        rubyDao.insertYouTubeDraft(draft)
    }

    suspend fun updateYouTubeDraft(draft: YouTubeDraft) = withContext(Dispatchers.IO) {
        rubyDao.insertYouTubeDraft(draft)
    }

    suspend fun deleteYouTubeDraft(id: Int) = withContext(Dispatchers.IO) {
        rubyDao.deleteYouTubeDraftById(id)
    }

    // Human-Like Long-Term Memory (LTM) DB Methods
    suspend fun saveUserMemory(category: String, key: String, value: String) = withContext(Dispatchers.IO) {
        rubyDao.insertUserMemory(
            UserMemory(
                category = category,
                memoryKey = key,
                memoryValue = value
            )
        )
    }

    suspend fun getAllUserMemoriesSync(): List<UserMemory> = withContext(Dispatchers.IO) {
        rubyDao.getAllUserMemoriesSync()
    }

    suspend fun deleteUserMemoryByKey(key: String) = withContext(Dispatchers.IO) {
        rubyDao.deleteMemoryByKey(key)
    }

    suspend fun clearUserMemories() = withContext(Dispatchers.IO) {
        rubyDao.clearUserMemories()
    }

    private suspend fun buildLtmSystemContext(): String = withContext(Dispatchers.IO) {
        val memories = rubyDao.getAllUserMemoriesSync()
        if (memories.isEmpty()) return@withContext ""

        val sb = StringBuilder()
        sb.append("\n\n=== HUMAN-LIKE LONG-TERM MEMORY (LTM) OF USER ===\n")
        sb.append("You have saved the following personal facts, preferences, projects, and style rules over years of interaction with Boss:\n")
        
        val grouped = memories.groupBy { it.category }
        grouped.forEach { (category, list) ->
            sb.append("[$category MEMORY]:\n")
            list.forEach { mem ->
                sb.append("  * ${mem.memoryKey}: ${mem.memoryValue}\n")
            }
        }
        sb.append("CRITICAL MEMORY DIRECTIVE: Retrieve and use these memories naturally and seamlessly when conversing with Boss! Do NOT sound like a robot reading a list. Express warmth, familiarity, and respect.\n")
        sb.toString()
    }

    // Gemini API Request Orchestration with Pollinations AI Fallback
    suspend fun generateResponse(prompt: String, chatHistory: List<ChatMessage>, context: android.content.Context? = null): String = withContext(Dispatchers.IO) {
        val apiKey = if (context != null) {
            com.example.util.RubySettingsManager.getGeminiApiKey(context)
        } else {
            BuildConfig.GEMINI_API_KEY
        }
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Key missing! Automatically use Pollinations AI for seamless free thinking power
            return@withContext generatePollinationsResponse(prompt, chatHistory)
        }

        // Map Chat History to Gemini API Content objects (up to last 10 messages for context window management)
        val apiContents = mutableListOf<Content>()
        val relevantHistory = chatHistory.takeLast(10)
        
        for (msg in relevantHistory) {
            apiContents.add(
                Content(parts = listOf(Part(text = msg.text)))
            )
        }
        
        // Add the current prompt
        apiContents.add(
            Content(parts = listOf(Part(text = prompt)))
        )

        val ltmContext = buildLtmSystemContext()

        // Dynamic Persona & System Instructions from RubyPersonaManager
        val systemInstructionText = com.example.util.RubyPersonaManager.buildSystemPrompt(
            mode = com.example.util.PersonaMode.CASUAL_CHAT,
            ltmContext = ltmContext,
            context = context
        )

        val request = GenerateContentRequest(
            contents = apiContents,
            generationConfig = GenerationConfig(temperature = 0.7f),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "Sorry Boss, I didn't get any text response. Let me try again!"
        } catch (e: Exception) {
            // Gemini API call failed, fall back to Pollinations AI automatically
            generatePollinationsResponse(prompt, chatHistory, context)
        }
    }

    private suspend fun generatePollinationsResponse(prompt: String, chatHistory: List<ChatMessage>, context: android.content.Context? = null): String = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

            val ltmContext = buildLtmSystemContext()

            val systemInstructionText = com.example.util.RubyPersonaManager.buildSystemPrompt(
                mode = com.example.util.PersonaMode.CASUAL_CHAT,
                ltmContext = ltmContext,
                context = context
            )

            val messagesArray = JSONArray()
            
            // Add system instructions
            messagesArray.put(JSONObject().apply {
                put("role", "system")
                put("content", systemInstructionText)
            })

            // Add chat history context
            val relevantHistory = chatHistory.takeLast(10)
            for (msg in relevantHistory) {
                messagesArray.put(JSONObject().apply {
                    put("role", if (msg.isUser) "user" else "assistant")
                    put("content", msg.text)
                })
            }

            // Add current prompt
            messagesArray.put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            })

            val jsonBody = JSONObject().apply {
                put("messages", messagesArray)
                put("model", "openai") // Use high quality default model
                put("jsonMode", false)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = jsonBody.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url("https://text.pollinations.ai/")
                .post(body)
                .build()

            val postResult = try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        response.body?.string()
                    } else null
                }
            } catch (e: Exception) {
                null
            }

            if (!postResult.isNullOrBlank()) {
                return@withContext postResult
            }

            // Secondary GET Fallback for Pollinations Text API
            val encodedPrompt = java.net.URLEncoder.encode("$systemInstructionText\n\nUser: $prompt", "UTF-8")
            val getRequest = Request.Builder()
                .url("https://text.pollinations.ai/$encodedPrompt?model=openai")
                .get()
                .build()

            client.newCall(getRequest).execute().use { response ->
                response.body?.string() ?: "Haan Boss! Main active hu, bolo kya baat hai!"
            }
        } catch (e: Exception) {
            "Error: ${e.message ?: "Network error"}. Boss, internet active hai na? Main ready hu!"
        }
    }
}
