package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "generated_projects")
data class GeneratedProject(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectName: String,
    val projectDescription: String,
    val projectType: String, // "Android Kotlin", "Web HTML/CSS/JS", "Simple Jetpack Compose", "Simple Game"
    val storageFolderPath: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "project_files")
data class ProjectFile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val fileName: String,
    val fileContent: String,
    val relativePath: String, // e.g. "src/main/java/MainActivity.kt" or "index.html"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory_logs")
data class MemoryLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskDescription: String,
    val status: String, // "PENDING", "COMPLETED", "IN_PROGRESS", "ALERT"
    val taskType: String, // "APP_BUILD", "YOUTUBE_POST", "REPLY_COMMENT", "SYSTEM"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "youtube_drafts")
data class YouTubeDraft(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val videoTitle: String,
    val videoDescription: String,
    val suggestedTags: String,
    val autoReplies: String, // JSON or semicolon-separated reply rules
    val isUploaded: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_memories")
data class UserMemory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "IDENTITY", "PREFERENCE", "PROJECT", "BEHAVIORAL"
    val memoryKey: String, // e.g. "user_name", "user_nickname", "favorite_games", "projects", "response_style"
    val memoryValue: String, // e.g. "Samad", "Free Fire / GTA V", "Ruby AI App", "Casual & Friendly"
    val timestamp: Long = System.currentTimeMillis()
)
