package com.example.data.database

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RubyDao {
    // Chat messages
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChat()

    // Generated Projects
    @Query("SELECT * FROM generated_projects ORDER BY timestamp DESC")
    fun getAllProjects(): Flow<List<GeneratedProject>>

    @Query("SELECT * FROM generated_projects WHERE id = :id")
    suspend fun getProjectById(id: Int): GeneratedProject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: GeneratedProject): Long

    @Query("DELETE FROM generated_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Int)

    // Project Files
    @Query("SELECT * FROM project_files WHERE projectId = :projectId")
    fun getFilesByProject(projectId: Int): Flow<List<ProjectFile>>

    @Query("SELECT * FROM project_files WHERE projectId = :projectId")
    suspend fun getFilesByProjectSync(projectId: Int): List<ProjectFile>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjectFile(file: ProjectFile): Long

    @Query("DELETE FROM project_files WHERE projectId = :projectId")
    suspend fun deleteFilesByProject(projectId: Int)

    // Memory Logs
    @Query("SELECT * FROM memory_logs ORDER BY timestamp DESC LIMIT 50")
    fun getAllMemoryLogs(): Flow<List<MemoryLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemoryLog(log: MemoryLog): Long

    @Query("DELETE FROM memory_logs")
    suspend fun clearLogs()

    // YouTube Drafts
    @Query("SELECT * FROM youtube_drafts ORDER BY timestamp DESC")
    fun getAllYouTubeDrafts(): Flow<List<YouTubeDraft>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertYouTubeDraft(draft: YouTubeDraft): Long

    @Query("DELETE FROM youtube_drafts WHERE id = :id")
    suspend fun deleteYouTubeDraftById(id: Int)

    // Human-Like Long-Term Memory (LTM)
    @Query("SELECT * FROM user_memories ORDER BY timestamp DESC")
    fun getAllUserMemories(): Flow<List<UserMemory>>

    @Query("SELECT * FROM user_memories")
    suspend fun getAllUserMemoriesSync(): List<UserMemory>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserMemory(memory: UserMemory): Long

    @Query("DELETE FROM user_memories WHERE memoryKey = :key")
    suspend fun deleteMemoryByKey(key: String)

    @Query("DELETE FROM user_memories")
    suspend fun clearUserMemories()
}
