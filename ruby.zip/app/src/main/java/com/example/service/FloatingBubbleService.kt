package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.database.AppDatabase
import com.example.data.repository.RubyRepository
import com.example.ui.components.RubyDigitalPet
import kotlinx.coroutines.*
import java.util.Locale

/**
 * Service Lifecycle Owner helper to enable ComposeView rendering inside Android Services.
 */
private class ServiceLifecycleOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
    }

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store
}

/**
 * Ruby Siri-Style Background Voice AI & Floating Companion Service.
 * 
 * Features:
 * - Hands-Free & One-Touch Voice Assistant: Tapping the mic button or bubble listens directly in the background.
 * - Multi-Tasking AI: Works over any app (YouTube, WhatsApp, Games, System Settings, Home Screen).
 * - Real-Time AI Vocal Response: Uses Gemini / Pollinations AI to generate and speak answers via TTS in real time.
 * - Floating Siri Subtitle Display: Shows real-time speech-to-text and AI responses directly on floating widget overlay.
 * - Medium-Sized Full Body Ruby 3D Anime Avatar Overlay.
 */
class FloatingBubbleService : Service(), TextToSpeech.OnInitListener {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var subtitleTextView: TextView? = null
    private var statusBadge: TextView? = null
    private var micButton: TextView? = null

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    private val isListeningState = mutableStateOf(false)
    private val isSpeakingState = mutableStateOf(false)
    private val isThinkingState = mutableStateOf(false)
    private val isMusicianState = mutableStateOf(false)

    private var lastSongTitle = "Ruby_Special_Melody"
    private var lastSongLyrics = "Ruby is singing for Boss..."

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var repository: RubyRepository

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // 1. Setup Foreground Service Notification for Android 14/15
        startForegroundNotification()

        // 2. Initialize Database & Repository for AI queries
        val db = AppDatabase.getDatabase(applicationContext)
        repository = RubyRepository(db.rubyDao())

        // 3. Initialize TTS Voice Engine (Ruby 18yo Anime Siri pitch)
        tts = TextToSpeech(this, this)

        // 4. Initialize Speech Recognizer
        setupSpeechRecognizer()

        // 5. Setup Window Overlay
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val scale = resources.displayMetrics.density

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        params.x = 80
        params.y = 200

        // Outer Root Layout with 100% Transparent Background
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.TRANSPARENT)
        }

        // Medium-Sized Full Body Ruby 3D Anime Avatar Overlay
        val avatarComposeView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            val wPx = (140 * scale).toInt()
            val hPx = (185 * scale).toInt()
            layoutParams = LinearLayout.LayoutParams(wPx, hPx).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = (4 * scale).toInt()
            }
        }

        val serviceLifecycleOwner = ServiceLifecycleOwner()
        avatarComposeView.setViewTreeLifecycleOwner(serviceLifecycleOwner)
        avatarComposeView.setViewTreeSavedStateRegistryOwner(serviceLifecycleOwner)
        avatarComposeView.setViewTreeViewModelStoreOwner(serviceLifecycleOwner)

        avatarComposeView.setContent {
            val listening by isListeningState
            val speaking by isSpeakingState
            val thinking by isThinkingState
            val musician by isMusicianState

            RubyDigitalPet(
                isThinking = thinking,
                isSpeaking = speaking,
                isListening = listening,
                isMusician = musician,
                modifier = Modifier.fillMaxSize(),
                onClick = {
                    toggleVoiceListening()
                }
            )
        }

        var currentScaleFactor = 1.0f

        fun updateOverlayScale(newScale: Float) {
            currentScaleFactor = newScale.coerceIn(0.5f, 2.5f)
            val density = resources.displayMetrics.density
            val wPx = (140 * density * currentScaleFactor).toInt()
            val hPx = (185 * density * currentScaleFactor).toInt()
            avatarComposeView.layoutParams = LinearLayout.LayoutParams(wPx, hPx).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = (4 * density).toInt()
            }
            floatingView?.let { view ->
                try {
                    windowManager?.updateViewLayout(view, params)
                } catch (e: Exception) {
                    Log.e("FloatingBubbleService", "Error updating overlay layout scale", e)
                }
            }
        }

        fun cycleZoomScale() {
            val nextScale = when {
                currentScaleFactor < 0.85f -> 1.0f
                currentScaleFactor < 1.3f -> 1.6f
                currentScaleFactor < 1.9f -> 2.2f
                else -> 0.7f
            }
            updateOverlayScale(nextScale)
        }

        val scaleGestureDetector = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                val scaleFactor = detector.scaleFactor
                updateOverlayScale(currentScaleFactor * scaleFactor)
                return true
            }
        })

        // Main Bubble Bar Container
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * scale).toInt(), (4 * scale).toInt(), (10 * scale).toInt(), (4 * scale).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FA12101D"))
                cornerRadius = 28 * scale
                setStroke((1.5f * scale).toInt(), Color.parseColor("#88FF2E93"))
            }
        }

        // App/Ruby Avatar Icon
        val bubbleSize = (32 * scale + 0.5f).toInt()
        val bubbleIcon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(bubbleSize, bubbleSize)
            setOnClickListener {
                val launchIntent = Intent(this@FloatingBubbleService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(launchIntent)
            }
        }

        // Siri Status Indicator - Stealth Mode (No text on screen)
        statusBadge = TextView(this).apply {
            text = ""
            visibility = View.GONE
        }

        // Mic Button Trigger
        micButton = TextView(this).apply {
            text = "🎙️"
            textSize = 16f
            setPadding((5 * scale).toInt(), (2 * scale).toInt(), (5 * scale).toInt(), (2 * scale).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FF2E93"))
                cornerRadius = 16 * scale
            }
            setOnClickListener {
                toggleVoiceListening()
            }
        }

        // Zoom In / Zoom Out Toggle Button
        val zoomButton = TextView(this).apply {
            text = "🔍"
            textSize = 15f
            setPadding((5 * scale).toInt(), (2 * scale).toInt(), (5 * scale).toInt(), (2 * scale).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#3300E5FF"))
                cornerRadius = 16 * scale
            }
            setOnClickListener {
                cycleZoomScale()
            }
        }

        container.addView(bubbleIcon)
        container.addView(statusBadge)
        container.addView(micButton)
        container.addView(zoomButton)

        // Floating Subtitle / Response Box - Completely hidden so no text pops up on screen
        subtitleTextView = TextView(this).apply {
            text = ""
            visibility = View.GONE
        }

        rootLayout.addView(avatarComposeView)
        rootLayout.addView(container)
        rootLayout.addView(subtitleTextView)
        floatingView = rootLayout

        val doubleTapDetector = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                cycleZoomScale()
                return true
            }
        })

        // Support Dynamic Dragging, Pinch-to-Zoom & Tap Interaction
        val touchListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isMoved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                doubleTapDetector.onTouchEvent(event)
                if (event.pointerCount >= 2) {
                    scaleGestureDetector.onTouchEvent(event)
                    return true
                }

                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isMoved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) {
                            isMoved = true
                        }
                        params.x = (initialX + dx).toInt()
                        params.y = (initialY + dy).toInt()
                        windowManager?.updateViewLayout(floatingView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (Math.abs(dx) <= 12 && Math.abs(dy) <= 12) {
                            toggleVoiceListening()
                        }
                        return true
                    }
                }
                return false
            }
        }

        container.setOnTouchListener(touchListener)
        avatarComposeView.setOnTouchListener { _, event ->
            doubleTapDetector.onTouchEvent(event)
            if (event.pointerCount >= 2) {
                scaleGestureDetector.onTouchEvent(event)
                true
            } else {
                touchListener.onTouch(container, event)
            }
        }

        // Long click to open main app
        container.setOnLongClickListener {
            val launchIntent = Intent(this@FloatingBubbleService, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(launchIntent)
            true
        }

        try {
            windowManager?.addView(floatingView, params)
        } catch (e: Exception) {
            Log.e("FloatingBubbleService", "Failed to add floating view overlay", e)
        }
    }

    private fun setupSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListeningState.value = true
                        isSpeakingState.value = false
                        isThinkingState.value = false
                        statusBadge?.text = "🎙️ Listening..."
                        statusBadge?.setTextColor(Color.parseColor("#00E676"))
                        subtitleTextView?.text = "Suno Boss, Ruby sun rahi hai..."
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        isListeningState.value = false
                        isThinkingState.value = true
                        statusBadge?.text = "🧠 Ruby Thinking..."
                        statusBadge?.setTextColor(Color.parseColor("#FFD54F"))
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        isListeningState.value = false
                        isThinkingState.value = false
                        isSpeakingState.value = false
                        statusBadge?.text = "🔴 Ruby Ready"
                        statusBadge?.setTextColor(Color.parseColor("#FF5252"))
                        subtitleTextView?.text = "Mic idle. Tap 🎙️ to talk or Ruby will auto-listen!"
                        if (isAutoContinuousListening) {
                            serviceScope.launch {
                                delay(2000)
                                if (isAutoContinuousListening && !isListening) {
                                    startListening()
                                }
                            }
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        isListeningState.value = false
                        isThinkingState.value = true
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val userQuery = matches[0]
                            processUserVoiceQuery(userQuery)
                        } else {
                            isThinkingState.value = false
                            statusBadge?.text = "🔴 Ruby Ready"
                            subtitleTextView?.text = "Boss, kuch sunayi nahi diya. Fir se bolo!"
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            subtitleTextView?.text = "You: ${matches[0]}"
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    private var isAutoContinuousListening = true

    private fun startListening() {
        if (!isListening) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            }
            try {
                speechRecognizer?.startListening(intent)
                isListening = true
            } catch (e: Exception) {
                Log.e("FloatingBubbleService", "Speech recognizer start failed", e)
                subtitleTextView?.text = "Mic error!"
            }
        }
    }

    private fun toggleVoiceListening() {
        if (isListening) {
            isAutoContinuousListening = false
            speechRecognizer?.stopListening()
            isListening = false
            statusBadge?.text = "🔴 Ruby Ready"
            statusBadge?.setTextColor(Color.parseColor("#FFD54F"))
        } else {
            isAutoContinuousListening = true
            startListening()
        }
    }

    private fun processUserVoiceQuery(query: String) {
        val lower = query.lowercase()
        val isSaveSongRequest = lower.contains("save") && (lower.contains("ruby") || lower.contains("folder") || lower.contains("song") || lower.contains("gana"))
        val isSongRequest = lower.contains("song") || lower.contains("gana") || lower.contains("guitar") || lower.contains("gitar") ||
                lower.contains("gao") || lower.contains("sing") || lower.contains("music") || lower.contains("tune") || lower.contains("dhun")

        if (isSaveSongRequest) {
            val (txtFile, wavFile) = com.example.util.RubyMusicianEngine.saveSongToRubyFolder(this, lastSongTitle, lastSongLyrics)
            speakResponse("Boss, '$lastSongTitle' Ruby folder me txt aur audio file ke saath save ho gaya hai!")
            return
        }

        serviceScope.launch {
            try {
                val aiReply = repository.generateResponse(query, emptyList())
                val cleanReply = aiReply.replace(Regex("\\[POLLINATIONS_IMAGE:.*?\\]"), "").trim()
                lastSongLyrics = cleanReply

                if (isSongRequest) {
                    val extractedTitle = query
                        .replace(Regex("(?i)gana|song|guitar|gitar|gao|sing|music|play|sonao|sunao|ke|ka|par|banao|me|me|ko"), "")
                        .trim()
                        .ifEmpty { "Ruby_Special_Melody" }
                    lastSongTitle = extractedTitle
                    isMusicianState.value = true
                    com.example.util.RubyMusicianEngine.playGuitarMelody(12) {
                        isMusicianState.value = false
                    }
                }

                speakResponse(cleanReply)
            } catch (e: Exception) {
                Log.e("FloatingBubbleService", "Error processing voice query", e)
                speakResponse("Boss, main aapki baat samajh gayi hu par network check kar lijiye.")
            }
        }
    }

    private fun speakResponse(text: String) {
        com.example.util.ElevenLabsTtsEngine.speak(
            context = this,
            text = text,
            tts = tts,
            isTtsReady = isTtsReady,
            onStart = {
                isSpeakingState.value = true
                isThinkingState.value = false
            },
            onDone = {
                isSpeakingState.value = false
                if (isAutoContinuousListening) {
                    serviceScope.launch {
                        delay(500)
                        if (isAutoContinuousListening && !isListening) {
                            startListening()
                        }
                    }
                }
            }
        )
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }

            try {
                val availableVoices = tts?.voices
                val cuteFemaleVoice = availableVoices?.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    (name.contains("female") || name.contains("woman") || name.contains("girl") || name.contains("hi-in") || name.contains("en-in"))
                } ?: availableVoices?.firstOrNull { voice ->
                    voice.name.lowercase().contains("female") || voice.name.lowercase().contains("f0")
                }

                if (cuteFemaleVoice != null) {
                    tts?.voice = cuteFemaleVoice
                }
            } catch (e: Exception) {
                Log.e("FloatingBubbleService", "Voice selection error: ${e.message}")
            }

            tts?.setPitch(1.35f) // Anime 18yo girl high-pitch voice
            tts?.setSpeechRate(1.05f)

            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeakingState.value = true
                    isThinkingState.value = false
                }
                override fun onDone(utteranceId: String?) {
                    isSpeakingState.value = false
                    if (isAutoContinuousListening) {
                        serviceScope.launch {
                            delay(500)
                            if (isAutoContinuousListening && !isListening) {
                                startListening()
                            }
                        }
                    }
                }
                override fun onError(utteranceId: String?) {
                    isSpeakingState.value = false
                }
            })

            isTtsReady = true
            speakResponse("Ruby Assistant Active, Boss! Tap mic anytime.")
        }
    }

    private fun startForegroundNotification() {
        val channelId = "ruby_bg_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Ruby Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ruby Companion running in background"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("🟢 Ruby Active")
            .setContentText("Background Voice Companion Ready. Tap overlay mic to speak!")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(101, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (floatingView != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (e: Exception) {
                Log.e("FloatingBubbleService", "Error removing overlay", e)
            }
        }
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
