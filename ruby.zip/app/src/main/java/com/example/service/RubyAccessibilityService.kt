package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log
import android.os.Bundle

class RubyAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RubyAccessibilityService? = null
            private set

        fun isServiceRunning(): Boolean = instance != null

        /**
         * Search active window hierarchy for nodes with specific text and click them.
         */
        fun performClickOnText(text: String): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false
            val nodes = rootNode.findAccessibilityNodeInfosByText(text)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (node.isClickable) {
                        val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        if (success) {
                            Log.d("RubyAccessibility", "Clicked on node with text: $text")
                            return true
                        }
                    } else {
                        // Traverse up the hierarchy to find a clickable parent container
                        var parent = node.parent
                        while (parent != null) {
                            if (parent.isClickable) {
                                val success = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                if (success) {
                                    Log.d("RubyAccessibility", "Clicked on parent of node with text: $text")
                                    return true
                                }
                            }
                            parent = parent.parent
                        }
                    }
                }
            }
            return false
        }

        /**
         * Search active window hierarchy for nodes with specific resource ID and click them.
         */
        fun performClickOnId(viewId: String): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                val nodes = rootNode.findAccessibilityNodeInfosByViewId(viewId)
                if (!nodes.isNullOrEmpty()) {
                    for (node in nodes) {
                        if (node.isClickable) {
                            val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            if (success) {
                                Log.d("RubyAccessibility", "Clicked on node with ID: $viewId")
                                return true
                            }
                        } else {
                            var parent = node.parent
                            while (parent != null) {
                                if (parent.isClickable) {
                                    val success = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                    if (success) {
                                        Log.d("RubyAccessibility", "Clicked on parent of ID: $viewId")
                                        return true
                                    }
                                }
                                parent = parent.parent
                            }
                        }
                    }
                }
            }
            return false
        }

        /**
         * Type text into the currently focused edit node.
         */
        fun typeIntoFocusedNode(text: String): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false
            val focusedNode = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focusedNode != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    val arguments = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                    }
                    val success = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
                    if (success) {
                        Log.d("RubyAccessibility", "Typed text successfully into input field")
                        return true
                    }
                }
            }
            return false
        }

        /**
         * Dispatch a custom gesture (swipe) at high speed.
         */
        fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 400): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val path = Path().apply {
                    moveTo(startX, startY)
                    lineTo(endX, endY)
                }
                val gestureBuilder = GestureDescription.Builder()
                gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                return service.dispatchGesture(gestureBuilder.build(), null, null)
            }
            return false
        }

        /**
         * Dispatch a precise single tap at coordinates (X, Y).
         */
        fun performTap(x: Float, y: Float, duration: Long = 50): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val path = Path().apply {
                    moveTo(x, y)
                }
                val gestureBuilder = GestureDescription.Builder()
                gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                return service.dispatchGesture(gestureBuilder.build(), null, null)
            }
            return false
        }

        /**
         * Trigger global actions like Back, Home, Recents, Notifications, Screenshot.
         */
        fun triggerGlobalAction(action: Int): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(action)
        }

        /**
         * Take a screenshot using system global action
         */
        fun takeScreenshot(): Boolean {
            val service = instance ?: return false
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else {
                false
            }
        }

        /**
         * System Control: Torch / Flashlight ON/OFF
         */
        fun setTorch(context: android.content.Context, enabled: Boolean): Boolean {
            return try {
                val cameraManager = context.getSystemService(android.content.Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
                val cameraId = cameraManager.cameraIdList.firstOrNull()
                if (cameraId != null) {
                    cameraManager.setTorchMode(cameraId, enabled)
                    true
                } else false
            } catch (e: Exception) {
                Log.e("RubyAccessibility", "Torch toggle error", e)
                false
            }
        }

        /**
         * System Control: Volume UP/DOWN
         */
        fun adjustVolume(context: android.content.Context, raise: Boolean) {
            try {
                val audioManager = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                val direction = if (raise) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER
                audioManager.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, direction, android.media.AudioManager.FLAG_SHOW_UI)
            } catch (e: Exception) {
                Log.e("RubyAccessibility", "Volume adjust error", e)
            }
        }

        /**
         * System Control: Read Clipboard text
         */
        fun readClipboard(context: android.content.Context): String? {
            return try {
                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                if (clipboard.hasPrimaryClip()) {
                    val item = clipboard.primaryClip?.getItemAt(0)
                    item?.text?.toString()
                } else null
            } catch (e: Exception) {
                Log.e("RubyAccessibility", "Clipboard error", e)
                null
            }
        }

        /**
         * Media Control: YouTube / Music Play/Pause/Skip
         */
        fun controlMedia(context: android.content.Context, action: String): Boolean {
            val key = when (action.lowercase()) {
                "play", "resume" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
                "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
                "skip", "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
                "prev", "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
                else -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            return try {
                val audioManager = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                audioManager.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key))
                audioManager.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key))
                
                // Fallback attempt: if Accessibility Service is active, search for "Pause", "Play", or "Skip" on screen!
                val buttonText = when (action.lowercase()) {
                    "pause" -> "Pause"
                    "play", "resume" -> "Play"
                    "skip", "next" -> "Skip"
                    else -> "Play"
                }
                performClickOnText(buttonText)
                true
            } catch (e: Exception) {
                Log.e("RubyAccessibility", "Media control error", e)
                false
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("RubyAccessibility", "Ruby Accessibility Automation Service CONNECTED successfully!")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: ""
        
        // Listen to screen window movements
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            Log.d("RubyAccessibility", "Active application context shifted to: $packageName")
        }
    }

    override fun onInterrupt() {
        Log.d("RubyAccessibility", "Ruby Accessibility Automation Service INTERRUPTED")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
