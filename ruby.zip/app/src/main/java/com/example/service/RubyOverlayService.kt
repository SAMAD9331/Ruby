package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.nativecore.RubyNativeCore
import com.example.util.RubyModelManager
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.Filament
import com.google.android.filament.LightManager
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.SwapChain
import com.google.android.filament.View as FilamentView
import com.google.android.filament.Viewport
import com.google.android.filament.android.UiHelper
import com.google.android.filament.gltfio.Animator
import com.google.android.filament.gltfio.AssetLoader
import com.google.android.filament.gltfio.FilamentAsset
import com.google.android.filament.gltfio.ResourceLoader
import com.google.android.filament.gltfio.UbershaderProvider
import java.nio.ByteBuffer

/**
 * Ruby 3D VTuber Floating Overlay Service.
 * 
 * Key Features:
 * 1. 100% Transparent WindowType.TYPE_APPLICATION_OVERLAY overlay with SurfaceView (PixelFormat.TRANSLUCENT & setZOrderOnTop(true)).
 * 2. Filament 3D Model Engine loading active_model.glb from storage via RubyModelManager or fallback assets/ruby_model.glb.
 * 3. MCPE-Style Auto Animation Scan: Automatically detects embedded skeletal animations (Idle, Breathing) and auto-plays them at 60 FPS.
 * 4. Fallback or blended NDK procedural breathing, hair sway, and live lip-sync mouth morph targets via RubyNativeCore.
 * 5. Touch-drag floating window positioning & 3D model rotation.
 */
class RubyOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayContainerView: FrameLayout? = null
    private var surfaceView: SurfaceView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    // Filament 3D Engine fields
    private var engine: Engine? = null
    private var renderer: Renderer? = null
    private var scene: Scene? = null
    private var camera: Camera? = null
    private var filamentView: FilamentView? = null
    private var swapChain: SwapChain? = null
    private var uiHelper: UiHelper? = null

    private var assetLoader: AssetLoader? = null
    private var resourceLoader: ResourceLoader? = null
    private var materialProvider: UbershaderProvider? = null
    private var filamentAsset: FilamentAsset? = null

    private var lightEntity: Int = 0
    private var isInitialized = false

    private val choreographer = Choreographer.getInstance()
    private var isRendering = false

    // State parameters
    var audioAmplitude: Float = 0f
    var isSpeaking: Boolean = false
    var pitchAngle: Float = 0f
    var yawAngle: Float = 0f

    // Auto animation scan state
    private var activeAnimationIndex: Int = -1
    private var hasSkeletalAnimation: Boolean = false

    private val startTimeSec = System.currentTimeMillis() / 1000f

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (isRendering) {
                renderFrame()
                choreographer.postFrameCallback(this)
            }
        }
    }

    private val renderCallback = object : UiHelper.RendererCallback {
        override fun onNativeWindowChanged(surface: Surface) {
            swapChain?.let { engine?.destroySwapChain(it) }
            swapChain = engine?.createSwapChain(surface)
        }

        override fun onDetachedFromSurface() {
            swapChain?.let { engine?.destroySwapChain(it) }
            swapChain = null
        }

        override fun onResized(width: Int, height: Int) {
            if (height > 0) {
                val aspect = width.toDouble() / height.toDouble()
                camera?.setProjection(45.0, aspect, 0.1, 100.0, Camera.Fov.VERTICAL)
                filamentView?.viewport = Viewport(0, 0, width, height)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Creating RubyOverlayService...")
        startForegroundServiceNotification()
        setupOverlayWindow()
        setupFilamentEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD_MODEL -> {
                reloadModel()
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceNotification() {
        val channelId = "ruby_overlay_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Ruby VTuber Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running 3D VTuber Overlay for Live Streaming and Voice AI"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Ruby 3D VTuber Floating Companion")
            .setContentText("3D Model Live Overlay Active")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun setupOverlayWindow() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val density = resources.displayMetrics.density
        val widthPx = (220 * density).toInt()
        val heightPx = (320 * density).toInt()

        layoutParams = WindowManager.LayoutParams(
            widthPx,
            heightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 180
        }

        overlayContainerView = FrameLayout(this)

        surfaceView = SurfaceView(this).apply {
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
        }

        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        overlayContainerView?.addView(surfaceView, lp)

        // Setup touch listener for dragging overlay & model rotation
        setupTouchInteractions()

        try {
            windowManager?.addView(overlayContainerView, layoutParams)
            Log.i(TAG, "Overlay window added successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlay window to WindowManager", e)
        }
    }

    private fun setupTouchInteractions() {
        surfaceView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams?.x ?: 0
                    initialY = layoutParams?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    // Update floating window layout position
                    layoutParams?.x = initialX + dx.toInt()
                    layoutParams?.y = initialY + dy.toInt()
                    windowManager?.updateViewLayout(overlayContainerView, layoutParams)

                    // Pass rotation delta to NDK rotation computation
                    val newAngles = RubyNativeCore.calculate3DTouchRotation(dx * 0.1f, dy * 0.1f, pitchAngle, yawAngle)
                    pitchAngle = newAngles[0]
                    yawAngle = newAngles[1]

                    true
                }
                else -> false
            }
        }
    }

    private fun setupFilamentEngine() {
        try {
            Filament.init()
            engine = Engine.create()
            renderer = engine?.createRenderer()
            scene = engine?.createScene()
            camera = engine?.createCamera(engine?.entityManager?.create() ?: 0)
            filamentView = engine?.createView()

            // Translucent clear options for zero-alpha floating overlay
            renderer?.clearOptions = Renderer.ClearOptions().apply {
                clear = true
                clearColor[0] = 0.0f
                clearColor[1] = 0.0f
                clearColor[2] = 0.0f
                clearColor[3] = 0.0f
            }

            // Directional lighting
            lightEntity = EntityManager.get().create()
            LightManager.Builder(LightManager.Type.DIRECTIONAL)
                .color(1.0f, 0.92f, 0.96f)
                .intensity(110000.0f)
                .direction(0.2f, -0.8f, -0.5f)
                .build(engine!!, lightEntity)
            scene?.addEntity(lightEntity)

            filamentView?.scene = scene
            filamentView?.camera = camera
            filamentView?.isPostProcessingEnabled = true

            // Attach SurfaceView via UiHelper
            uiHelper = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK).apply {
                renderCallback = this@RubyOverlayService.renderCallback
                surfaceView?.let { attachTo(it) }
            }

            // Load 3D Model
            loadModel()

            isInitialized = true
            startRendering()
            Log.i(TAG, "Filament Engine setup completed for Overlay Service")
        } catch (e: Throwable) {
            Log.e(TAG, "Error setting up Filament in RubyOverlayService", e)
        }
    }

    private fun loadModel() {
        try {
            // Clean up existing asset
            filamentAsset?.let { asset ->
                assetLoader?.destroyAsset(asset)
            }

            val bytes = RubyModelManager.loadActiveModelBytes(this)
            if (bytes == null || bytes.isEmpty()) {
                Log.w(TAG, "No valid model bytes found")
                return
            }

            val buffer = ByteBuffer.allocateDirect(bytes.size)
            buffer.put(bytes)
            buffer.flip()

            if (materialProvider == null) {
                materialProvider = UbershaderProvider(engine!!)
            }
            if (assetLoader == null) {
                assetLoader = AssetLoader(engine!!, materialProvider!!, EntityManager.get())
            }
            if (resourceLoader == null) {
                resourceLoader = ResourceLoader(engine!!)
            }

            filamentAsset = assetLoader?.createAsset(buffer)
            filamentAsset?.let { asset ->
                resourceLoader?.loadResources(asset)
                scene?.addEntity(asset.root)
                for (entity in asset.entities) {
                    scene?.addEntity(entity)
                }

                // Initial position & scale
                val tm = engine!!.transformManager
                val instance = tm.getInstance(asset.root)
                if (instance != 0) {
                    val transform = FloatArray(16)
                    android.opengl.Matrix.setIdentityM(transform, 0)
                    android.opengl.Matrix.translateM(transform, 0, 0f, -0.6f, -2.5f)
                    android.opengl.Matrix.scaleM(transform, 0, 1.2f, 1.2f, 1.2f)
                    tm.setTransform(instance, transform)
                }

                // Auto Animation Scan
                scanAndSetupSkeletalAnimations(asset)

                Log.i(TAG, "Successfully loaded 3D GLB model into Overlay Scene!")
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error loading GLB model in Overlay Service", e)
        }
    }

    /**
     * Scans GLB asset for embedded skeletal animations (Idle, Breathing, etc.).
     */
    private fun scanAndSetupSkeletalAnimations(asset: FilamentAsset) {
        hasSkeletalAnimation = false
        activeAnimationIndex = -1

        try {
            val getAnimatorMethod = asset.javaClass.methods.firstOrNull { 
                it.name == "getAnimator" || it.name == "animator" || it.name == "getInstanceAnimator" 
            }
            val animatorObj = when (getAnimatorMethod?.parameterCount) {
                0 -> getAnimatorMethod.invoke(asset)
                1 -> getAnimatorMethod.invoke(asset, 0)
                else -> null
            }

            if (animatorObj != null) {
                val countMethod = animatorObj.javaClass.methods.firstOrNull { it.name == "getAnimationCount" || it.name == "animationCount" }
                val count = (countMethod?.invoke(animatorObj) as? Int) ?: 0
                Log.i(TAG, "Auto Animation Scan found $count animations in model")

                if (count > 0) {
                    hasSkeletalAnimation = true
                    var bestIndex = 0
                    val getNameMethod = animatorObj.javaClass.methods.firstOrNull { it.name == "getAnimationName" || it.name == "animationName" }

                    for (i in 0 until count) {
                        val animName = (getNameMethod?.invoke(animatorObj, i) as? String)?.lowercase() ?: "anim_$i"
                        Log.i(TAG, "Animation [$i]: name='$animName'")
                        
                        // Import track into C++ NDK Animation Engine
                        RubyNativeCore.importAnimationTrack(animName, durationSec = 3.0f, keyframeCount = 60, isLooping = true)
                        
                        if (animName.contains("idle") || animName.contains("breath") || animName.contains("stand") || animName.contains("loop")) {
                            bestIndex = i
                        }
                    }

                    activeAnimationIndex = bestIndex
                    RubyNativeCore.setAnimationState(if (isSpeaking) 1 else 0)
                    Log.i(TAG, "Auto Selected animation index $activeAnimationIndex for C++ playback")
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Model does not contain standard skeletal animator or scan failed: ${e.message}")
        }
    }

    fun reloadModel() {
        Log.i(TAG, "Reloading 3D Model in Overlay Service...")
        loadModel()
    }

    private fun startRendering() {
        if (!isRendering) {
            isRendering = true
            choreographer.postFrameCallback(frameCallback)
        }
    }

    private fun stopRendering() {
        if (isRendering) {
            isRendering = false
            choreographer.removeFrameCallback(frameCallback)
        }
    }

    private fun renderFrame() {
        val eng = engine ?: return
        val rend = renderer ?: return
        val sc = swapChain ?: return
        val fView = filamentView ?: return
        if (!isInitialized) return

        val currentTimeSec = (System.currentTimeMillis() / 1000f) - startTimeSec
        val deltaTime = 0.016f

        // 1. Calculate NDK Live Morph Targets & Automated C++ 3D Animation Evaluation
        val autoAnim = RubyNativeCore.evaluateAutomated3DAnimation(
            currentTimeSec = currentTimeSec,
            deltaTime = deltaTime,
            audioAmplitude = if (isSpeaking) audioAmplitude.coerceAtLeast(0.25f) else audioAmplitude,
            isSpeaking = isSpeaking
        )
        // [0:headPitch, 1:headYaw, 2:headRoll, 3:armRightPitch, 4:armLeftPitch, 5:spineSway, 6:legSway, 7:mouthVisemeOpen, 8:eyeBlink, 9:hairInertia, 10:scaleX, 11:scaleY]
        val cHeadPitch = autoAnim[0]
        val cHeadYaw = autoAnim[1]
        val cHeadRoll = autoAnim[2]
        val cSpineSway = autoAnim[5]
        val cMouthOpen = autoAnim[7]
        val cHairInertia = autoAnim[9]
        val cScaleX = autoAnim[10]
        val cScaleY = autoAnim[11]

        // 2. Calculate NDK VTuber Full-Body Inertia (Breathing, Sway, Hair)
        val inertia = RubyNativeCore.computeVTuber3DInertia(deltaTime, currentTimeSec)
        val breathY = inertia[0]
        val hipSwayX = inertia[1]
        val shoulderZ = inertia[2]
        val hairInertiaX = inertia[3]

        // 3. Apply Skeletal Animation (if available) or Procedural Motion
        filamentAsset?.let { asset ->
            if (hasSkeletalAnimation && activeAnimationIndex >= 0) {
                try {
                    val getAnimatorMethod = asset.javaClass.methods.firstOrNull { 
                        it.name == "getAnimator" || it.name == "animator" || it.name == "getInstanceAnimator" 
                    }
                    val animatorObj = when (getAnimatorMethod?.parameterCount) {
                        0 -> getAnimatorMethod.invoke(asset)
                        1 -> getAnimatorMethod.invoke(asset, 0)
                        else -> null
                    }
                    if (animatorObj != null) {
                        val applyAnimMethod = animatorObj.javaClass.methods.firstOrNull { it.name == "applyAnimation" }
                        val updateBonesMethod = animatorObj.javaClass.methods.firstOrNull { it.name == "updateBoneMatrices" }
                        applyAnimMethod?.invoke(animatorObj, activeAnimationIndex, currentTimeSec)
                        updateBonesMethod?.invoke(animatorObj)
                    }
                } catch (e: Throwable) {
                    // Fallback
                }
            }

            // Apply Root Matrix transforms with C++ automated animation blend
            val tm = eng.transformManager
            val instance = tm.getInstance(asset.root)
            if (instance != 0) {
                val transform = FloatArray(16)
                android.opengl.Matrix.setIdentityM(transform, 0)
                android.opengl.Matrix.translateM(transform, 0, hipSwayX + cSpineSway, -0.6f + breathY + (cMouthOpen * 0.02f), -2.5f)
                android.opengl.Matrix.rotateM(transform, 0, pitchAngle + (cHeadPitch * 57.3f), 1f, 0f, 0f)
                android.opengl.Matrix.rotateM(transform, 0, yawAngle + (hairInertiaX + cHairInertia) * 10f + (cHeadYaw * 57.3f), 0f, 1f, 0f)
                android.opengl.Matrix.rotateM(transform, 0, shoulderZ * 5f + (cHeadRoll * 57.3f), 0f, 0f, 1f)
                android.opengl.Matrix.scaleM(transform, 0, 1.2f * cScaleX, 1.2f * cScaleY, 1.2f)

                tm.setTransform(instance, transform)
            }
        }

        // 4. Render Frame to SwapChain
        if (rend.beginFrame(sc, System.nanoTime())) {
            rend.render(fView)
            rend.endFrame()
        }
    }

    override fun onDestroy() {
        Log.i(TAG, "Destroying RubyOverlayService...")
        stopRendering()
        try {
            uiHelper?.detach()
            filamentAsset?.let { asset ->
                assetLoader?.destroyAsset(asset)
            }
            materialProvider?.destroy()
            assetLoader?.destroy()
            resourceLoader?.destroy()

            engine?.let { eng ->
                scene?.let { eng.destroyScene(it) }
                renderer?.let { eng.destroyRenderer(it) }
                filamentView?.let { eng.destroyView(it) }
                if (lightEntity != 0) eng.destroyEntity(lightEntity)
                eng.destroy()
            }

            if (overlayContainerView != null && windowManager != null) {
                windowManager?.removeView(overlayContainerView)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error cleaning up RubyOverlayService", e)
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "RubyOverlayService"
        private const val NOTIFICATION_ID = 2001

        const val ACTION_START_OVERLAY = "com.example.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"
        const val ACTION_RELOAD_MODEL = "com.example.action.RELOAD_MODEL"

        fun startService(context: Context) {
            val intent = Intent(context, RubyOverlayService::class.java).apply {
                action = ACTION_START_OVERLAY
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, RubyOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            context.startService(intent)
        }

        fun reloadModel(context: Context) {
            val intent = Intent(context, RubyOverlayService::class.java).apply {
                action = ACTION_RELOAD_MODEL
            }
            context.startService(intent)
        }
    }
}
