package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.exp
import kotlin.math.sin

object RubyMusicianEngine {

    private const val TAG = "RubyMusicianEngine"
    private val musicianScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var currentMusicJob: Job? = null
    private var isPlaying = false

    // Musical Frequencies (Acoustic Guitar Chords - E Minor, C Major, G Major, D Major)
    private val guitarNotes = doubleArrayOf(
        164.81, // E3
        196.00, // G3
        220.00, // A3
        246.94, // B3
        261.63, // C4
        293.66, // D4
        329.63, // E4
        392.00, // G4
        440.00, // A4
        493.88  // B4
    )

    /**
     * Plays a guitar strumming chord tone melody using AudioTrack synthesis.
     */
    fun playGuitarMelody(durationSeconds: Int = 8, onComplete: (() -> Unit)? = null) {
        stopGuitarMelody()
        isPlaying = true

        currentMusicJob = musicianScope.launch {
            try {
                val sampleRate = 44100
                val totalSamples = sampleRate * durationSeconds
                val bufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .build()

                audioTrack.play()

                val pcmData = ShortArray(bufferSize)
                var sampleIndex = 0

                val noteDurationSamples = (sampleRate * 0.4).toInt() // 400ms per note strum

                while (sampleIndex < totalSamples && isPlaying) {
                    val currentNoteIdx = (sampleIndex / noteDurationSamples) % guitarNotes.size
                    val freq = guitarNotes[currentNoteIdx]
                    val noteSampleIndex = sampleIndex % noteDurationSamples

                    for (i in pcmData.indices) {
                        if (!isPlaying || sampleIndex >= totalSamples) break

                        val t = noteSampleIndex.toDouble() / sampleRate
                        // Plucked string acoustic decay envelope: exp(-3.8 * t)
                        val envelope = exp(-3.8 * (noteSampleIndex.toDouble() / noteDurationSamples))
                        // Fundamental + Harmonics for rich acoustic guitar timbre
                        val sampleValue = (
                            sin(2.0 * Math.PI * freq * t) +
                            0.5 * sin(2.0 * Math.PI * (freq * 2) * t) +
                            0.25 * sin(2.0 * Math.PI * (freq * 3) * t)
                        ) * envelope * 0.35

                        val shortVal = (sampleValue * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        pcmData[i] = shortVal.toShort()
                        sampleIndex++
                    }

                    audioTrack.write(pcmData, 0, pcmData.size)
                }

                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error playing guitar audio", e)
            } finally {
                isPlaying = false
                onComplete?.invoke()
            }
        }
    }

    fun stopGuitarMelody() {
        isPlaying = false
        currentMusicJob?.cancel()
        currentMusicJob = null
    }

    fun isCurrentlyPlayingMusic(): Boolean = isPlaying

    /**
     * Saves song lyrics & acoustic music tone file directly inside the dedicated "Ruby" folder on device storage.
     * Uses context.getExternalFilesDir("Ruby") as main storage (crash-safe for Android 15, scoped storage compliant).
     */
    fun saveSongToRubyFolder(context: Context, songTitle: String, lyricsText: String): Pair<File, File?> {
        val cleanTitle = songTitle.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(30).ifEmpty { "Ruby_Song" }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

        // 1. Target "Ruby" folder on Android 15 safe storage
        val rubyFolder = try {
            val primaryDir = context.getExternalFilesDir("Ruby")
            val selectedDir = primaryDir ?: File(context.filesDir, "Ruby")
            if (!selectedDir.exists()) {
                selectedDir.mkdirs()
            }
            selectedDir
        } catch (e: Exception) {
            Log.e(TAG, "Storage access error, falling back to internal app storage", e)
            val fallback = File(context.filesDir, "Ruby")
            if (!fallback.exists()) {
                fallback.mkdirs()
            }
            fallback
        }

        // 2. Save Lyrics Text File
        val lyricsFile = File(rubyFolder, "${cleanTitle}_$timeStamp.txt")
        val textContent = """
            ==============================================
            🎵 RUBY MUSICIAN SONG ARCHIVE 🎵
            ==============================================
            Song Title: $songTitle
            Artist: Ruby AI (Musician Mode)
            Date Saved: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
            ----------------------------------------------
            Lyrics & Chords:
            
            $lyricsText
            
            ==============================================
            Saved in Ruby Folder: ${lyricsFile.absolutePath}
            ==============================================
        """.trimIndent()

        try {
            lyricsFile.writeText(textContent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed writing lyrics text file", e)
        }

        // 3. Generate Audio WAV File in Ruby Folder
        var audioFile: File? = null
        try {
            audioFile = File(rubyFolder, "${cleanTitle}_$timeStamp.wav")
            generateWavAudioFile(audioFile, durationSeconds = 6)
        } catch (e: Exception) {
            Log.e(TAG, "WAV generation exception: ${e.message}")
        }

        return Pair(lyricsFile, audioFile)
    }

    private fun generateWavAudioFile(outFile: File, durationSeconds: Int) {
        val sampleRate = 44100
        val totalSamples = sampleRate * durationSeconds
        val bytesPerSample = 2
        val numChannels = 1
        val pcmDataSize = totalSamples * bytesPerSample * numChannels

        val fos = FileOutputStream(outFile)

        // Write WAV Header (44 bytes)
        val header = ByteBuffer.allocate(44).apply {
            order(ByteOrder.LITTLE_ENDIAN)
            put("RIFF".toByteArray())
            putInt(36 + pcmDataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16) // Subchunk1Size
            putShort(1) // AudioFormat (PCM = 1)
            putShort(numChannels.toShort())
            putInt(sampleRate)
            putInt(sampleRate * numChannels * bytesPerSample) // ByteRate
            putShort((numChannels * bytesPerSample).toShort()) // BlockAlign
            putShort((bytesPerSample * 8).toShort()) // BitsPerSample
            put("data".toByteArray())
            putInt(pcmDataSize)
        }.array()

        fos.write(header)

        val noteDurationSamples = (sampleRate * 0.4).toInt()
        val buffer = ByteArray(2048)
        var bufferPos = 0
        var sampleIndex = 0

        while (sampleIndex < totalSamples) {
            val freq = guitarNotes[(sampleIndex / noteDurationSamples) % guitarNotes.size]
            val noteSampleIndex = sampleIndex % noteDurationSamples
            val t = noteSampleIndex.toDouble() / sampleRate
            val envelope = exp(-3.8 * (noteSampleIndex.toDouble() / noteDurationSamples))

            val sampleValue = (
                sin(2.0 * Math.PI * freq * t) +
                0.5 * sin(2.0 * Math.PI * (freq * 2) * t)
            ) * envelope * 0.35

            val shortVal = (sampleValue * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()

            buffer[bufferPos++] = (shortVal.toInt() and 0xFF).toByte()
            buffer[bufferPos++] = ((shortVal.toInt() shr 8) and 0xFF).toByte()

            if (bufferPos >= buffer.size) {
                fos.write(buffer, 0, bufferPos)
                bufferPos = 0
            }
            sampleIndex++
        }

        if (bufferPos > 0) {
            fos.write(buffer, 0, bufferPos)
        }

        fos.close()
    }
}
