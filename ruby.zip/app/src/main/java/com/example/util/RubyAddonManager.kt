package com.example.util

import android.content.Context
import android.net.Uri
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Data model for MCPE-Style Dynamic Addons & Feature Packs.
 */
data class AddonItem(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val author: String,
    val fileName: String,
    val isActive: Boolean,
    val scriptContent: String = "",
    val isPrebundled: Boolean = false
)

/**
 * Minecraft MCPE-Style Dynamic Addon & Feature Importer Engine for Ruby AI.
 * 
 * Features:
 * 1. Manages external feature scripts (.js, .json, .zip, .mcaddon) in context.filesDir/addons/
 * 2. Maintains a dynamic JSON manifest (addons_manifest.json) storing metadata and active status.
 * 3. Scans & injects ACTIVE addons dynamically into Ruby's LLM prompt execution pipeline.
 */
object RubyAddonManager {

    private const val TAG = "RubyAddonManager"
    private const val ADDON_DIR = "addons"
    private const val MANIFEST_FILE = "addons_manifest.json"

    private fun getAddonsDir(context: Context): File {
        val dir = File(context.filesDir, ADDON_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Initializes prebundled default MCPE-style addons if first launch.
     */
    private fun ensureDefaultAddons(context: Context) {
        val manifestFile = File(getAddonsDir(context), MANIFEST_FILE)
        if (!manifestFile.exists()) {
            val defaults = listOf(
                AddonItem(
                    id = "vtuber_gamer_hud",
                    name = "VTuber Gamer HUD & Overlay Pack",
                    version = "1.2.0",
                    description = "Adds MCPE-style streaming HUD overlays, live viewer counter, and gamer reactions.",
                    author = "Ruby Core Team",
                    fileName = "vtuber_gamer_hud.js",
                    isActive = true,
                    scriptContent = "// VTuber Gamer HUD script\nconsole.log('Gamer HUD active');",
                    isPrebundled = true
                ),
                AddonItem(
                    id = "cyber_security_guard",
                    name = "C++ NDK Security Scanner Pack",
                    version = "2.1.0",
                    description = "Injects C++ memory guard telemetries and automated app security audits.",
                    author = "Ruby Security Labs",
                    fileName = "cyber_security_guard.js",
                    isActive = true,
                    scriptContent = "// NDK Security Guard script",
                    isPrebundled = true
                ),
                AddonItem(
                    id = "emotion_tts_tuner",
                    name = "Emotion Voice & Pitch Tuner",
                    version = "1.0.5",
                    description = "Extends ElevenLabs & Local TTS with dynamic pitch modulation per emotion tag.",
                    author = "Ruby Audio Team",
                    fileName = "emotion_tts_tuner.js",
                    isActive = false,
                    scriptContent = "// Emotion Voice Tuner",
                    isPrebundled = true
                ),
                AddonItem(
                    id = "master_game_texture_engine",
                    name = "Automated 3D Texture & Game Logic Pack",
                    version = "3.0.0",
                    description = "Auto-generates PBR procedural textures, custom shaders, and 100% complete game logic for Unity, Android NDK & PC apps.",
                    author = "Ruby Game Studio Labs",
                    fileName = "master_game_texture_engine.js",
                    isActive = true,
                    scriptContent = "// Ruby Automated Texture & Game Logic Engine Pack active\nconsole.log('Game Engine Addon Ready');",
                    isPrebundled = true
                )
            )
            saveManifest(context, defaults)
        }
    }

    /**
     * Returns list of all installed addons with current active/inactive status.
     */
    fun getAvailableAddons(context: Context): List<AddonItem> {
        ensureDefaultAddons(context)
        val manifestFile = File(getAddonsDir(context), MANIFEST_FILE)
        if (!manifestFile.exists()) return emptyList()

        val list = mutableListOf<AddonItem>()
        try {
            val jsonStr = manifestFile.readText()
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("id", "")
                val name = obj.optString("name", "Unknown Addon")
                val version = obj.optString("version", "1.0.0")
                val description = obj.optString("description", "")
                val author = obj.optString("author", "Community Creator")
                val fileName = obj.optString("fileName", "")
                val isActive = obj.optBoolean("isActive", false)
                val isPrebundled = obj.optBoolean("isPrebundled", false)

                val scriptFile = File(getAddonsDir(context), fileName)
                val scriptContent = if (scriptFile.exists()) scriptFile.readText() else ""

                list.add(
                    AddonItem(
                        id = id,
                        name = name,
                        version = version,
                        description = description,
                        author = author,
                        fileName = fileName,
                        isActive = isActive,
                        scriptContent = scriptContent,
                        isPrebundled = isPrebundled
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading addons manifest", e)
        }
        return list
    }

    /**
     * Toggles an addon's active status and updates manifest.
     */
    fun setAddonActive(context: Context, addonId: String, isActive: Boolean): Boolean {
        val current = getAvailableAddons(context).toMutableList()
        val index = current.indexOfFirst { it.id == addonId }
        if (index != -1) {
            val updatedItem = current[index].copy(isActive = isActive)
            current[index] = updatedItem
            saveManifest(context, current)
            Log.i(TAG, "Addon $addonId active state set to: $isActive")
            return true
        }
        return false
    }

    /**
     * Imports a new .js, .json, .zip, or .mcaddon file from SAF picker into addons/ directory.
     */
    fun importAddon(context: Context, uri: Uri, customName: String? = null): Boolean {
        return try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "Failed to open input stream for URI: $uri")
                return false
            }

            val addonsDir = getAddonsDir(context)
            val baseName = (customName ?: "addon_${System.currentTimeMillis()}")
                .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            val id = "addon_" + System.currentTimeMillis()
            val fileName = "$baseName.js"

            val targetFile = File(addonsDir, fileName)

            // Copy file or extract if ZIP/mcaddon
            var description = "Custom imported addon pack"
            var scriptText = ""

            if (uri.path?.endsWith(".zip", true) == true || uri.path?.endsWith(".mcaddon", true) == true) {
                ZipInputStream(inputStream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && (entry.name.endsWith(".js", true) || entry.name.endsWith(".json", true))) {
                            scriptText = zis.readBytes().toString(Charsets.UTF_8)
                            break
                        }
                        entry = zis.nextEntry
                    }
                }
                if (scriptText.isBlank()) {
                    scriptText = "// MCPE Addon Pack script imported\nconsole.log('$baseName active');"
                }
                targetFile.writeText(scriptText)
            } else {
                FileOutputStream(targetFile).use { output ->
                    inputStream.use { input ->
                        input.copyTo(output)
                    }
                }
                scriptText = targetFile.readText()
            }

            // Create new AddonItem & update manifest
            val newAddon = AddonItem(
                id = id,
                name = baseName.replace('_', ' ').capitalizeWords(),
                version = "1.0.0",
                description = description,
                author = "External Importer",
                fileName = fileName,
                isActive = true,
                scriptContent = scriptText,
                isPrebundled = false
            )

            val list = getAvailableAddons(context).toMutableList()
            list.add(newAddon)
            saveManifest(context, list)

            Log.i(TAG, "Successfully imported addon: ${newAddon.name} ($fileName)")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error importing addon", e)
            false
        }
    }

    /**
     * Deletes an addon and cleans up files.
     */
    fun deleteAddon(context: Context, addonId: String): Boolean {
        val current = getAvailableAddons(context).toMutableList()
        val item = current.find { it.id == addonId } ?: return false

        val scriptFile = File(getAddonsDir(context), item.fileName)
        if (scriptFile.exists()) {
            scriptFile.delete()
        }

        current.removeAll { it.id == addonId }
        saveManifest(context, current)
        Log.i(TAG, "Deleted addon: $addonId")
        return true
    }

    /**
     * Registers a newly generated addon directly from Ruby AI into storage and activates it.
     */
    fun registerAddon(
        context: Context,
        name: String,
        description: String,
        scriptContent: String,
        author: String = "Ruby AI (Self-Created)"
    ): AddonItem? {
        return try {
            val addonsDir = getAddonsDir(context)
            val id = "addon_" + System.currentTimeMillis()
            val safeName = name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").lowercase()
            val fileName = "${safeName}_${System.currentTimeMillis() % 1000}.js"
            val targetFile = File(addonsDir, fileName)
            targetFile.writeText(scriptContent)

            // Also write copy to external Ruby directory inside storage
            try {
                val externalRubyDir = File(context.getExternalFilesDir("Ruby") ?: context.filesDir, "RubyAddons")
                if (!externalRubyDir.exists()) externalRubyDir.mkdirs()
                val extFile = File(externalRubyDir, fileName)
                extFile.writeText(scriptContent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save external addon copy", e)
            }

            val newAddon = AddonItem(
                id = id,
                name = name,
                version = "1.0.0",
                description = description,
                author = author,
                fileName = fileName,
                isActive = true,
                scriptContent = scriptContent,
                isPrebundled = false
            )

            val current = getAvailableAddons(context).toMutableList()
            current.add(newAddon)
            saveManifest(context, current)
            Log.i(TAG, "Successfully registered self-created addon: $name")
            newAddon
        } catch (e: Exception) {
            Log.e(TAG, "Error registering addon", e)
            null
        }
    }

    /**
     * Generates active addon feature instructions string to inject dynamically into LLM prompt context.
     */
    fun getActiveAddonsPromptContext(context: Context): String {
        val activeList = getAvailableAddons(context).filter { it.isActive }
        if (activeList.isEmpty()) return ""

        val sb = java.lang.StringBuilder()
        sb.append("\n\n--- ACTIVE MCPE-STYLE ADDONS & FEATURE PACKS LOADED ---\n")
        activeList.forEachIndexed { index, addon ->
            sb.append("${index + 1}. [${addon.name} v${addon.version} by ${addon.author}]\n")
            sb.append("   - Description: ${addon.description}\n")
            if (addon.scriptContent.isNotBlank()) {
                val snippet = addon.scriptContent.lines().take(5).joinToString("\n")
                sb.append("   - Instructions: $snippet\n")
            }
        }
        sb.append("--- END ACTIVE ADDONS ---\n")
        return sb.toString()
    }

    /**
     * Saves list of AddonItems to addons_manifest.json.
     */
    private fun saveManifest(context: Context, addons: List<AddonItem>) {
        try {
            val array = JSONArray()
            addons.forEach { item ->
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("name", item.name)
                obj.put("version", item.version)
                obj.put("description", item.description)
                obj.put("author", item.author)
                obj.put("fileName", item.fileName)
                obj.put("isActive", item.isActive)
                obj.put("isPrebundled", item.isPrebundled)
                array.put(obj)
            }
            val manifestFile = File(getAddonsDir(context), MANIFEST_FILE)
            manifestFile.writeText(array.toString(2))
        } catch (e: Exception) {
            Log.e(TAG, "Error saving manifest", e)
        }
    }

    private fun String.capitalizeWords(): String {
        return split(" ").joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }
}
