package com.example.util

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

object ElevenLabsTtsEngine {
    private const val TAG = "ElevenLabsTtsEngine"
    private const val PREF_NAME = "ruby_tts_prefs"
    private const val KEY_ELEVENLABS_API_KEY = "elevenlabs_api_key"
    private const val KEY_ELEVENLABS_VOICE_ID = "elevenlabs_voice_id"

    // Default ElevenLabs Voice ID (Bella - Natural Sweet Female Voice)
    private const val DEFAULT_VOICE_ID = "EXAVITQu4vr4xnSDxMaL"

    private var mediaPlayer: MediaPlayer? = null
    private val ttsScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val currentAudioAmplitude = androidx.compose.runtime.mutableFloatStateOf(0f)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun saveApiKey(context: Context, apiKey: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ELEVENLABS_API_KEY, apiKey.trim()).apply()
    }

    fun getApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ELEVENLABS_API_KEY, "") ?: ""
    }

    fun saveVoiceId(context: Context, voiceId: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ELEVENLABS_VOICE_ID, voiceId.trim()).apply()
    }

    fun getVoiceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val id = prefs.getString(KEY_ELEVENLABS_VOICE_ID, "")
        return if (!id.isNullOrBlank()) id else DEFAULT_VOICE_ID
    }

    // Detect language from text (Bangla 'bn', Hindi 'hi', English 'en')
    fun detectLanguageLocale(text: String): Locale {
        val hasBengaliChar = text.any { it in '\u0980'..'\u09FF' }
        val hasHindiChar = text.any { it in '\u0900'..'\u097F' }

        return when {
            hasBengaliChar -> Locale("bn", "IN")
            hasHindiChar -> Locale("hi", "IN")
            else -> {
                val lower = text.lowercase()
                if (lower.contains("kemon") || lower.contains("khobor") || lower.contains("bhalo") || lower.contains("bangla") || lower.contains("amra") || lower.contains("tomar")) {
                    Locale("bn", "IN")
                } else {
                    Locale("hi", "IN")
                }
            }
        }
    }

    fun speak(
        context: Context,
        text: String,
        tts: TextToSpeech?,
        isTtsReady: Boolean,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {}
    ) {
        // Clean markdown, emotion tags & formatting
        val cleanText = text
            .replace(Regex("\\[(happy|laugh|surprised|thinking|wink|shy|excited|loving|angry|neutral)\\]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("`{3}[\\s\\S]*?`{3}"), "[Code block generated, Boss]")
            .replace(Regex("\\[GENERATE_APP:[\\s\\S]*?\\]"), "")
            .replace(Regex("\\[FILE:[\\s\\S]*?\\]"), "")
            .replace(Regex("\\*|_|#"), "")
            .trim()

        if (cleanText.isEmpty()) {
            onDone()
            return
        }

        val apiKey = getApiKey(context)
        val voiceId = getVoiceId(context)

        if (apiKey.isNotBlank()) {
            // Attempt ElevenLabs Realistic Voice Generation
            ttsScope.launch {
                val success = fetchAndPlayElevenLabs(context, cleanText, apiKey, voiceId, onStart, onDone)
                if (!success) {
                    // Fallback to local TTS with Bangla/Hindi auto-detection
                    withContext(Dispatchers.Main) {
                        speakLocalTts(cleanText, tts, isTtsReady, onStart, onDone)
                    }
                }
            }
        } else {
            // Speak using enhanced local TTS with Bangla/Hindi support
            speakLocalTts(cleanText, tts, isTtsReady, onStart, onDone)
        }
    }

    private suspend fun fetchAndPlayElevenLabs(
        context: Context,
        text: String,
        apiKey: String,
        voiceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit
    ): Boolean {
        return try {
            val url = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId"
            
            val jsonBody = JSONObject().apply {
                put("text", text.take(500))
                put("model_id", "eleven_multilingual_v2") // Multilingual v2 supports Bangla, Hindi, English natively
                put("voice_settings", JSONObject().apply {
                    put("stability", 0.5)
                    put("similarity_boost", 0.8)
                    put("style", 0.3)
                    put("use_speaker_boost", true)
                })
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("xi-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "audio/mpeg")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e(TAG, "ElevenLabs API failed with code: ${response.code}")
                return false
            }

            val responseBody = response.body ?: return false
            val audioFile = File(context.cacheCacheDir(), "ruby_elevenlabs_${System.currentTimeMillis()}.mp3")
            
            FileOutputStream(audioFile).use { output ->
                responseBody.byteStream().copyTo(output)
            }

            withContext(Dispatchers.Main) {
                stopPlayback()
                onStart()
                
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(audioFile.absolutePath)
                    prepare()
                    setOnCompletionListener {
                        stopPlayback()
                        audioFile.delete()
                        onDone()
                    }
                    setOnErrorListener { _, _, _ ->
                        stopPlayback()
                        audioFile.delete()
                        onDone()
                        true
                    }
                    start()
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Exception during ElevenLabs speech generation", e)
            false
        }
    }

    private fun Context.cacheCacheDir(): File {
        val dir = File(cacheDir, "elevenlabs_audio")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun speakLocalTts(
        text: String,
        tts: TextToSpeech?,
        isTtsReady: Boolean,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {}
    ) {
        if (!isTtsReady || tts == null) {
            onDone()
            return
        }

        try {
            // Auto detect language locale (Bangla 'bn-IN', Hindi 'hi-IN', English 'en-IN')
            val locale = detectLanguageLocale(text)
            val langResult = tts.setLanguage(locale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("hi", "IN"))
            }

            // Set cute anime female voice parameters
            tts.setPitch(1.35f)
            tts.setSpeechRate(1.05f)

            onStart()
            
            tts.speak(text.take(300), TextToSpeech.QUEUE_FLUSH, null, "RubyLocalTTS_${System.currentTimeMillis()}")
            
            // Note: Listener handles completion callback in caller
        } catch (e: Exception) {
            Log.e(TAG, "Local TTS speak error", e)
            onDone()
        }
    }

    fun stopPlayback() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping media player", e)
        }
    }
}
