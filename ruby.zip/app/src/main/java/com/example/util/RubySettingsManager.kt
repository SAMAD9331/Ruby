package com.example.util

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.BuildConfig
import com.example.service.RubyOverlayService
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

/**
 * Data model for 3D Skin items in the Skin Gallery.
 */
data class ModelItem(
    val name: String,
    val fileName: String,
    val sizeBytes: Long,
    val isActive: Boolean,
    val isDefaultAsset: Boolean
)

/**
 * Unified Settings & Model Gallery Manager for Ruby AI.
 * 
 * Features:
 * 1. Skin & 3D Model Registry (lists files in context.filesDir/models/).
 * 2. Active skin selection & instant synchronization with Floating Overlay and Main App 3D View.
 * 3. Dynamic management of Gemini AI API Key, ElevenLabs TTS API Key, and Voice ID.
 */
object RubySettingsManager {

    private const val TAG = "RubySettingsManager"
    private const val PREFS_NAME = "ruby_app_settings"

    private const val KEY_GEMINI_API_KEY = "gemini_api_key"
    private const val KEY_ELEVENLABS_API_KEY = "elevenlabs_api_key"
    private const val KEY_ELEVENLABS_VOICE_ID = "elevenlabs_voice_id"
    private const val KEY_ACTIVE_MODEL_FILENAME = "active_model_filename"

    const val DEFAULT_MODEL_NAME = "default_ruby.glb"
    const val DEFAULT_VOICE_ID = "EXAVITQu4vr4xnSDxMaL"
    private const val MODEL_DIR = "models"

    private fun getPrefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // --- Dynamic API Credentials ---

    fun getGeminiApiKey(context: Context): String {
        val key = getPrefs(context).getString(KEY_GEMINI_API_KEY, "") ?: ""
        return if (key.isNotBlank()) key else BuildConfig.GEMINI_API_KEY
    }

    fun saveGeminiApiKey(context: Context, key: String) {
        getPrefs(context).edit().putString(KEY_GEMINI_API_KEY, key.trim()).apply()
    }

    fun getElevenLabsApiKey(context: Context): String {
        val prefKey = getPrefs(context).getString(KEY_ELEVENLABS_API_KEY, "") ?: ""
        return if (prefKey.isNotBlank()) prefKey else ElevenLabsTtsEngine.getApiKey(context)
    }

    fun saveElevenLabsApiKey(context: Context, key: String) {
        val trimmed = key.trim()
        getPrefs(context).edit().putString(KEY_ELEVENLABS_API_KEY, trimmed).apply()
        ElevenLabsTtsEngine.saveApiKey(context, trimmed)
    }

    fun getElevenLabsVoiceId(context: Context): String {
        val id = getPrefs(context).getString(KEY_ELEVENLABS_VOICE_ID, "") ?: ""
        return if (id.isNotBlank()) id else ElevenLabsTtsEngine.getVoiceId(context)
    }

    fun saveElevenLabsVoiceId(context: Context, voiceId: String) {
        val trimmed = voiceId.trim()
        getPrefs(context).edit().putString(KEY_ELEVENLABS_VOICE_ID, trimmed).apply()
        ElevenLabsTtsEngine.saveVoiceId(context, trimmed)
    }

    // --- 3D Skin / Model Gallery Registry ---

    fun getActiveModelFileName(context: Context): String {
        return getPrefs(context).getString(KEY_ACTIVE_MODEL_FILENAME, DEFAULT_MODEL_NAME) ?: DEFAULT_MODEL_NAME
    }

    /**
     * Retrieves all available GLB model skins in storage gallery.
     */
    fun getAvailableModels(context: Context): List<ModelItem> {
        val activeName = getActiveModelFileName(context)
        val list = mutableListOf<ModelItem>()

        // Default bundled model item
        list.add(
            ModelItem(
                name = "Ruby Classic (Default)",
                fileName = DEFAULT_MODEL_NAME,
                sizeBytes = 0L,
                isActive = (activeName == DEFAULT_MODEL_NAME),
                isDefaultAsset = true
            )
        )

        val modelsDir = File(context.filesDir, MODEL_DIR)
        if (modelsDir.exists() && modelsDir.isDirectory) {
            modelsDir.listFiles()?.filter { file ->
                file.isFile && file.extension.equals("glb", ignoreCase = true) && file.name != "active_model.glb"
            }?.forEach { file ->
                val displayName = file.nameWithoutExtension
                    .replace('_', ' ')
                    .replace('-', ' ')
                    .split(" ")
                    .joinToString(" ") { word ->
                        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                    }

                list.add(
                    ModelItem(
                        name = displayName.ifBlank { file.name },
                        fileName = file.name,
                        sizeBytes = file.length(),
                        isActive = (activeName == file.name),
                        isDefaultAsset = false
                    )
                )
            }
        }
        return list
    }

    /**
     * Imports a .glb skin model into context.filesDir/models/ and automatically activates it.
     */
    fun importModel(context: Context, uri: Uri, customName: String? = null): Boolean {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "Failed to open input stream for URI: $uri")
                return false
            }

            val modelsDir = File(context.filesDir, MODEL_DIR)
            if (!modelsDir.exists()) modelsDir.mkdirs()

            val cleanBaseName = (customName ?: "skin_${System.currentTimeMillis()}")
                .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            val targetFileName = if (cleanBaseName.endsWith(".glb", ignoreCase = true)) cleanBaseName else "$cleanBaseName.glb"

            val targetFile = File(modelsDir, targetFileName)
            FileOutputStream(targetFile).use { output ->
                inputStream.use { input ->
                    input.copyTo(output)
                }
            }

            Log.i(TAG, "Successfully imported model $targetFileName (${targetFile.length()} bytes)")
            
            // Set newly imported model as active
            setActiveModel(context, targetFileName)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error importing model from URI: $uri", e)
            false
        }
    }

    /**
     * Switches active 3D model skin and syncs active_model.glb & Floating Overlay.
     */
    fun setActiveModel(context: Context, fileName: String): Boolean {
        return try {
            getPrefs(context).edit().putString(KEY_ACTIVE_MODEL_FILENAME, fileName).apply()
            
            val modelsDir = File(context.filesDir, MODEL_DIR)
            if (!modelsDir.exists()) modelsDir.mkdirs()

            if (fileName != DEFAULT_MODEL_NAME) {
                val sourceFile = File(modelsDir, fileName)
                if (sourceFile.exists()) {
                    val activeFile = File(modelsDir, "active_model.glb")
                    sourceFile.copyTo(activeFile, overwrite = true)
                }
            } else {
                RubyModelManager.deleteCustomModel(context)
            }

            // Reload Floating Overlay 3D scene instantly
            RubyOverlayService.reloadModel(context)
            Log.i(TAG, "Active 3D skin model updated to: $fileName")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting active model: $fileName", e)
            false
        }
    }

    /**
     * Deletes a model skin from the gallery.
     */
    fun deleteModel(context: Context, fileName: String): Boolean {
        if (fileName == DEFAULT_MODEL_NAME) return false
        return try {
            val modelsDir = File(context.filesDir, MODEL_DIR)
            val file = File(modelsDir, fileName)
            val deleted = file.delete()

            if (getActiveModelFileName(context) == fileName) {
                setActiveModel(context, DEFAULT_MODEL_NAME)
            } else {
                RubyOverlayService.reloadModel(context)
            }
            deleted
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting model $fileName", e)
            false
        }
    }

    /**
     * Loads raw bytes for the currently selected active 3D skin model.
     */
    fun getActiveModelBytes(context: Context): ByteArray? {
        val fileName = getActiveModelFileName(context)
        if (fileName != DEFAULT_MODEL_NAME) {
            val modelsDir = File(context.filesDir, MODEL_DIR)
            val file = File(modelsDir, fileName)
            if (file.exists() && file.length() > 0) {
                return file.readBytes()
            }
        }
        return RubyModelManager.loadActiveModelBytes(context)
    }
}
