package com.example.util

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * MCPE-Style Dynamic 3D Model Importer & Storage Manager for Ruby AI.
 * 
 * Features:
 * - SAF (Storage Access Framework) FilePicker importer for custom .glb models.
 * - Stores imported model at context.filesDir/models/active_model.glb.
 * - Auto-fallback to default app/src/main/assets/ruby_model.glb if no custom model is present.
 */
object RubyModelManager {
    private const val TAG = "RubyModelManager"
    private const val MODEL_DIR = "models"
    private const val ACTIVE_MODEL_NAME = "active_model.glb"
    private const val DEFAULT_ASSET_MODEL = "ruby_model.glb"

    /**
     * Gets the custom active GLB model File if present and non-empty.
     */
    fun getActiveModelFile(context: Context): File? {
        return try {
            val modelsDir = File(context.filesDir, MODEL_DIR)
            val file = File(modelsDir, ACTIVE_MODEL_NAME)
            if (file.exists() && file.length() > 0) file else null
        } catch (e: Exception) {
            Log.e(TAG, "Error checking active model file", e)
            null
        }
    }

    /**
     * Checks if user has imported a custom .glb model.
     */
    fun hasCustomModel(context: Context): Boolean {
        return getActiveModelFile(context) != null
    }

    /**
     * Imports a .glb model from SAF FilePicker Uri into context.filesDir/models/active_model.glb
     */
    fun importModelFromUri(context: Context, uri: Uri): Boolean {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "Failed to open input stream for URI: $uri")
                return false
            }

            val modelsDir = File(context.filesDir, MODEL_DIR)
            if (!modelsDir.exists()) {
                modelsDir.mkdirs()
            }

            val targetFile = File(modelsDir, ACTIVE_MODEL_NAME)
            val outputStream = FileOutputStream(targetFile)

            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            Log.i(TAG, "Successfully imported custom GLB model (${targetFile.length()} bytes) to ${targetFile.absolutePath}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error importing GLB model from Uri: $uri", e)
            false
        }
    }

    /**
     * Deletes the custom GLB model file and restores default model.
     */
    fun deleteCustomModel(context: Context): Boolean {
        return try {
            val file = getActiveModelFile(context)
            if (file != null && file.exists()) {
                val deleted = file.delete()
                Log.i(TAG, "Custom model deleted: $deleted")
                deleted
            } else {
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting custom model", e)
            false
        }
    }

    /**
     * Reads and returns direct raw byte array of active GLB model.
     * Tries context.filesDir/models/active_model.glb first, then falls back to assets/ruby_model.glb.
     */
    fun loadActiveModelBytes(context: Context): ByteArray? {
        val activeName = RubySettingsManager.getActiveModelFileName(context)
        if (activeName != RubySettingsManager.DEFAULT_MODEL_NAME) {
            try {
                val modelsDir = File(context.filesDir, MODEL_DIR)
                val customFile = File(modelsDir, activeName)
                if (customFile.exists() && customFile.length() > 0) {
                    val bytes = customFile.readBytes()
                    if (bytes.isNotEmpty()) {
                        Log.i(TAG, "Loaded active custom GLB model skin '$activeName' (${bytes.size} bytes)")
                        return bytes
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reading active model '$activeName', falling back to default", e)
            }
        }

        // Check active_model.glb fallback
        val customFile = getActiveModelFile(context)
        if (customFile != null) {
            try {
                val bytes = customFile.readBytes()
                if (bytes.isNotEmpty()) {
                    Log.i(TAG, "Loaded fallback active_model.glb (${bytes.size} bytes)")
                    return bytes
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reading active_model.glb", e)
            }
        }

        // Fallback to asset ruby_model.glb
        return try {
            val inputStream = context.assets.open(DEFAULT_ASSET_MODEL)
            val bytes = inputStream.use { it.readBytes() }
            Log.i(TAG, "Loaded fallback asset $DEFAULT_ASSET_MODEL (${bytes.size} bytes)")
            bytes
        } catch (e: Exception) {
            Log.w(TAG, "Failed loading asset model $DEFAULT_ASSET_MODEL: ${e.message}")
            null
        }
    }
}
