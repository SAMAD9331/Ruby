package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.OndemandVideo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.YouTubeDraft
import com.example.ui.theme.*
import com.example.viewmodel.RubyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RubyYouTubeScreen(viewModel: RubyViewModel, modifier: Modifier = Modifier) {
    val drafts by viewModel.youtubeDrafts.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    var videoTitleInput by remember { mutableStateOf("") }
    var videoTopicInput by remember { mutableStateOf("") }
    var generatedTitle by remember { mutableStateOf("") }
    var generatedDescription by remember { mutableStateOf("") }
    var generatedTags by remember { mutableStateOf("") }
    var replyRulesInput by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }

    var draftToDelete by remember { mutableStateOf<YouTubeDraft?>(null) }

    LaunchedEffect(draftToDelete) {
        if (draftToDelete != null) {
            viewModel.speakSamadDeleteCheck()
        }
    }

    // Quick Action Title Generator helper (Simulated or triggered via local AI logic)
    fun generateYouTubeSEO() {
        if (videoTopicInput.trim().isEmpty()) {
            Toast.makeText(context, "Enter a topic/game name first!", Toast.LENGTH_SHORT).show()
            return
        }

        isGenerating = true
        // Let's trigger Ruby chat prompt automatically for YouTube script planning
        val prompt = """
            Hey Ruby, I want to make a YouTube video on the topic: '$videoTopicInput'. 
            Please write:
            1. 3 High-CTR Title ideas
            2. An SEO Optimized Description with timestamps template
            3. 10 High-ranking tags
            4. 3 automated comment reply rules (e.g. if comment has 'nice', reply '...')
        """.trimIndent()
        
        viewModel.sendMessage(prompt)
        isGenerating = false
        
        // Notify user to check assistant chat tab
        Toast.makeText(context, "Ruby is writing script in Chat tab, Boss!", Toast.LENGTH_LONG).show()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RubyBg)
    ) {
        // 1. YouTube Dashboard Intro Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(RubySurface)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VideoCameraFront,
                    contentDescription = "YouTube logo",
                    tint = RubyAccent,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "YouTube Studio Automation Console",
                        color = RubyText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Plan viral gameplays, script code walkthroughs, optimize title tags, and organize automated audience comment replies.",
                        color = RubyTextMuted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Section A: AI Optimizer Tool Box
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RubySurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "QUICK SEO GENERATOR",
                            color = RubyRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        TextField(
                            value = videoTopicInput,
                            onValueChange = { videoTopicInput = it },
                            placeholder = { Text("Topic/Game, e.g. 'Minecraft Speedrun' or 'Compose UI Tutorial'", fontSize = 12.sp, color = RubyTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = RubyBg,
                                unfocusedContainerColor = RubyBg,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = { generateYouTubeSEO() },
                            colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isGenerating
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Sparkles"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGenerating) "PLANNING SCRIPT..." else "GENERATE VIRAL SCRIPT",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Section B: Manual Draft Saver Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RubySurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "CREATE DRAFT TO REMEMBER",
                            color = RubyOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        // Title Field
                        TextField(
                            value = videoTitleInput,
                            onValueChange = { videoTitleInput = it },
                            placeholder = { Text("Video Title", fontSize = 12.sp, color = RubyTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = RubyBg,
                                unfocusedContainerColor = RubyBg,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Description Box
                        TextField(
                            value = generatedDescription,
                            onValueChange = { generatedDescription = it },
                            placeholder = { Text("Video Description & Script Outline", fontSize = 12.sp, color = RubyTextMuted) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 80.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = RubyBg,
                                unfocusedContainerColor = RubyBg,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Tags Box
                        TextField(
                            value = generatedTags,
                            onValueChange = { generatedTags = it },
                            placeholder = { Text("Tags (comma separated)", fontSize = 12.sp, color = RubyTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = RubyBg,
                                unfocusedContainerColor = RubyBg,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Audience Reply Rule
                        TextField(
                            value = replyRulesInput,
                            onValueChange = { replyRulesInput = it },
                            placeholder = { Text("Comment Reply Rule, e.g. 'nice -> Thanks bro!'", fontSize = 12.sp, color = RubyTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = RubyBg,
                                unfocusedContainerColor = RubyBg,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = {
                                if (videoTitleInput.trim().isNotEmpty()) {
                                    viewModel.saveYouTubeDraft(
                                        title = videoTitleInput,
                                        desc = generatedDescription,
                                        tags = generatedTags,
                                        replies = replyRulesInput
                                    )
                                    videoTitleInput = ""
                                    generatedDescription = ""
                                    generatedTags = ""
                                    replyRulesInput = ""
                                    Toast.makeText(context, "Draft Saved successfully, Boss!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Please write a title first!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RubyRed, contentColor = Color.White),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = "Save draft")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SAVE DRAFT TO STORAGE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Section C: YouTube Saved Drafts
            item {
                Text(
                    text = "SAVED VIDEO DRAFTS & SCRIPTS",
                    color = RubyText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            if (drafts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = RubySurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.OndemandVideo,
                                contentDescription = "No video drafts",
                                tint = RubyTextMuted.copy(alpha = 0.4f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No YouTube Video drafts saved.",
                                color = RubyTextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                items(drafts) { draft ->
                    YouTubeDraftCard(
                        draft = draft,
                        onDelete = { draftToDelete = draft },
                        onCopy = {
                            val textToCopy = "Title: ${draft.videoTitle}\nDescription: ${draft.videoDescription}\nTags: ${draft.suggestedTags}\nAuto-Replies: ${draft.autoReplies}"
                            clipboardManager.setText(AnnotatedString(textToCopy))
                            Toast.makeText(context, "Draft details copied, Boss!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }

        // SAMAD BHAI DELETE LOCK DIALOG FOR YOUTUBE DRAFTS
        draftToDelete?.let { d ->
            AlertDialog(
                onDismissRequest = { draftToDelete = null },
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = RubyRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ruby Permission Lock",
                            color = RubyText,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Samad bhai, kya is ko delete karu?",
                            color = RubyRed,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Text(
                            text = "Are you sure you want to delete video draft: '${d.videoTitle}'?",
                            color = RubyTextMuted,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Text(
                            text = "This will clear this item from database memory.",
                            color = RubyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteYouTubeDraft(d.id)
                            draftToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed)
                    ) {
                        Text("Haa, Delete kardo", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { draftToDelete = null }
                    ) {
                        Text("Nahi, Cancel karo", color = RubyTextMuted)
                    }
                },
                containerColor = RubySurface
            )
        }
    }
}

@Composable
fun YouTubeDraftCard(
    draft: YouTubeDraft,
    onDelete: () -> Unit,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, RubySurfaceVariant, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = RubySurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FeaturedPlayList,
                        contentDescription = "Draft icon",
                        tint = RubyRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = draft.videoTitle,
                        color = RubyText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row {
                    IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy draft",
                            tint = RubyTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete draft",
                            tint = RubyTextMuted.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            if (draft.videoDescription.isNotEmpty()) {
                Text(
                    text = draft.videoDescription,
                    color = RubyText,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            if (draft.suggestedTags.isNotEmpty()) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Label,
                        contentDescription = "Tags icon",
                        tint = RubyOrange,
                        modifier = Modifier
                            .size(12.dp)
                            .padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TAGS: ${draft.suggestedTags}",
                        color = RubyTextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (draft.autoReplies.isNotEmpty()) {
                Surface(
                    color = RubyBg.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = "Auto Reply rules",
                            tint = Color.Cyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Auto-Reply: ${draft.autoReplies}",
                            color = RubyTextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
