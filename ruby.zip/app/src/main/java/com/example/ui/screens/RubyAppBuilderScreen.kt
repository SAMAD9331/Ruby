package com.example.ui.screens

import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.GeneratedProject
import com.example.data.model.ProjectFile
import com.example.ui.theme.*
import com.example.viewmodel.RubyViewModel
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RubyAppBuilderScreen(viewModel: RubyViewModel, modifier: Modifier = Modifier) {
    val projects by viewModel.projects.collectAsState()
    val selectedId by viewModel.selectedProjectId.collectAsState()
    val files by viewModel.selectedProjectFiles.collectAsState()

    var activeProject by remember { mutableStateOf<GeneratedProject?>(null) }
    var activeFile by remember { mutableStateOf<ProjectFile?>(null) }
    var codeText by remember { mutableStateOf("") }
    var showEmulator by remember { mutableStateOf(false) }

    // Pollinations AI asset generator states
    var showAssetGenerator by remember { mutableStateOf(false) }
    var assetPrompt by remember { mutableStateOf("") }
    var assetFileName by remember { mutableStateOf("logo.png") }
    var isGeneratingAsset by remember { mutableStateOf(false) }

    var projectToDelete by remember { mutableStateOf<GeneratedProject?>(null) }

    // Speak delete request when user opens deletion dialog
    LaunchedEffect(projectToDelete) {
        if (projectToDelete != null) {
            viewModel.speakSamadDeleteCheck()
        }
    }

    // Sync active project object
    LaunchedEffect(selectedId, projects) {
        activeProject = projects.find { it.id == selectedId }
    }

    // Load file content when a file is selected
    LaunchedEffect(activeFile) {
        codeText = activeFile?.fileContent ?: ""
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RubyBg)
    ) {
        if (selectedId == null) {
            // VIEW 1: Projects Catalog List
            Column(modifier = Modifier.fillMaxSize()) {
                // Headline Banners
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(RubySurface)
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DeveloperMode,
                                contentDescription = "Developer Workbench",
                                tint = RubyOrange,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI App Creator Workbench",
                                color = RubyText,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ruby automatically parses generated source code, structures directories, and writes physical file modules inside external device storage folders.",
                            color = RubyTextMuted,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Project grid/list
                if (projects.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FolderZip,
                            contentDescription = "Empty Projects",
                            tint = RubyRed.copy(alpha = 0.5f),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Projects Built Yet",
                            color = RubyText,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ask Ruby: 'Create a web-based flappy bird game'\nor 'Build a custom calculator app in HTML'",
                            color = RubyTextMuted,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(projects) { project ->
                            ProjectCatalogCard(project = project, onClick = {
                                viewModel.selectProject(project.id)
                            }, onDelete = {
                                projectToDelete = project
                            })
                        }
                    }
                }
            }
        } else {
            // VIEW 2: Project Workspace (Active directory & inline IDE)
            Column(modifier = Modifier.fillMaxSize()) {
                // Directory Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        activeFile = null
                        viewModel.selectProject(null)
                    }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Go Back",
                            tint = RubyText
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeProject?.projectName ?: "Workspace",
                            color = RubyText,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = activeProject?.projectType ?: "HTML Web Workspace",
                            color = RubyOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Check if an index.html file exists in workspace to display live emulator
                    val hasWebIndex = files.any { it.fileName.contains("index.html", ignoreCase = true) }
                    if (hasWebIndex) {
                        Button(
                            onClick = { showEmulator = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run Web App",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("RUN APP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Divider(color = RubySurfaceVariant)

                // Split Workspace: Left is Directory Tree, Right is Editor Workspace
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left navigation rail folder files
                    Column(
                        modifier = Modifier
                            .width(130.dp)
                            .fillMaxHeight()
                            .background(RubySurface)
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "PROJECT FILES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = RubyTextMuted,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )

                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(files) { file ->
                                val isSelected = activeFile?.id == file.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isSelected) RubyBg else Color.Transparent)
                                        .clickable { activeFile = file }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = when {
                                            file.fileName.endsWith(".html") -> Icons.Default.Html
                                            file.fileName.endsWith(".css") -> Icons.Default.Css
                                            file.fileName.endsWith(".js") -> Icons.Default.Javascript
                                            file.fileName.endsWith(".png") || file.fileName.endsWith(".jpg") || file.fileName.endsWith(".jpeg") -> Icons.Default.Image
                                            else -> Icons.Default.Description
                                        },
                                        contentDescription = "File Type",
                                        tint = if (isSelected) RubyRed else RubyTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = file.fileName,
                                        color = if (isSelected) RubyRed else RubyText,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = RubySurfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(4.dp))

                        // Launch Pollinations AI Graphic creator
                        TextButton(
                            onClick = { showAssetGenerator = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            colors = ButtonDefaults.textButtonColors(contentColor = RubyRed)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Brush,
                                    contentDescription = "AI Graphic Designer",
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "AI GRAPHIC",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Right editor pane
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(RubyBg)
                    ) {
                        if (activeFile == null) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = "Terminal IDE",
                                    tint = RubyTextMuted.copy(alpha = 0.3f),
                                    modifier = Modifier.size(54.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Select a source file to edit code",
                                    color = RubyTextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        } else {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Editor Header Controls
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = activeFile?.fileName ?: "file",
                                        color = RubyText,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    IconButton(
                                        onClick = {
                                            activeProject?.let { proj ->
                                                activeFile?.let { file ->
                                                    viewModel.saveProjectFileContent(
                                                        projectId = proj.id,
                                                        fileId = file.id,
                                                        fileName = file.fileName,
                                                        content = codeText,
                                                        relPath = file.relativePath
                                                    )
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Save,
                                            contentDescription = "Save Code Changes",
                                            tint = RubyRed
                                        )
                                    }
                                }

                                // Interactive Terminal Text Area or Binary Image Viewer
                                if (activeFile?.fileContent?.contains("[BINARY_ASSET_IMAGE:") == true || 
                                    activeFile?.fileName?.endsWith(".png") == true || 
                                    activeFile?.fileName?.endsWith(".jpg") == true || 
                                    activeFile?.fileName?.endsWith(".jpeg") == true) {
                                    
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                            .border(1.dp, RubySurfaceVariant, RoundedCornerShape(8.dp))
                                            .background(RubySurface)
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            val imageUrl = if (activeFile?.fileContent?.contains("[BINARY_ASSET_IMAGE:") == true) {
                                                activeFile?.fileContent?.substringAfter("[BINARY_ASSET_IMAGE:")?.substringBefore("]")?.trim() ?: ""
                                            } else {
                                                ""
                                            }

                                            if (imageUrl.isNotEmpty()) {
                                                Card(
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier.size(240.dp),
                                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                                ) {
                                                    AsyncImage(
                                                        model = imageUrl,
                                                        contentDescription = "Project Graphic Asset",
                                                        contentScale = ContentScale.Fit,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(16.dp))
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Image,
                                                    contentDescription = "Local Image Asset",
                                                    tint = RubyTextMuted.copy(alpha = 0.5f),
                                                    modifier = Modifier.size(72.dp)
                                                )
                                                Spacer(modifier = Modifier.height(12.dp))
                                            }

                                            Text(
                                                text = activeFile?.fileName ?: "asset.png",
                                                color = RubyText,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Stored as high-fidelity visual asset in project storage.",
                                                color = RubyTextMuted,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(top = 4.dp)
                                            )
                                            Text(
                                                text = "Usage in code: <img src=\"${activeFile?.fileName}\" />",
                                                color = RubyRed,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .padding(top = 12.dp)
                                                    .background(RubyBg, RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                } else {
                                    TextField(
                                        value = codeText,
                                        onValueChange = { codeText = it },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                            .border(1.dp, RubySurfaceVariant, RoundedCornerShape(8.dp))
                                            .padding(4.dp),
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            color = Color.Green,
                                            fontSize = 12.sp
                                        ),
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = RubyBg,
                                            unfocusedContainerColor = RubyBg,
                                            focusedIndicatorColor = Color.Transparent,
                                            unfocusedIndicatorColor = Color.Transparent
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. FULL SCREEN EMULATOR DIALOG FOR RUNNING HTML WEB PROJECTS
        if (showEmulator && activeProject != null) {
            // Find HTML content, CSS content, JS content from project workspace files
            val indexFile = files.find { it.fileName.contains("index.html", ignoreCase = true) }
            val cssFile = files.find { it.fileName.endsWith(".css") }
            val jsFile = files.find { it.fileName.endsWith(".js") }

            // Assemble a clean composite HTML document if dependencies are local
            val runtimeHtml = if (indexFile != null) {
                var html = indexFile.fileContent
                
                // If the html references a style.css or script.js file, we inject them inline dynamically so they run perfectly offline in the web emulator!
                if (cssFile != null && (html.contains("href=\"style.css\"") || html.contains("href='style.css'"))) {
                    html = html.replace(Regex("<link.*href=[\"']style\\.css[\"'].*>"), "<style>${cssFile.fileContent}</style>")
                } else if (cssFile != null && !html.contains("<style>")) {
                    html = html.replace("</head>", "<style>${cssFile.fileContent}</style></head>")
                }

                if (jsFile != null && (html.contains("src=\"script.js\"") || html.contains("src='script.js'"))) {
                    html = html.replace(Regex("<script.*src=[\"']script\\.js[\"'].*></script>"), "<script>${jsFile.fileContent}</script>")
                } else if (jsFile != null && !html.contains("<script>")) {
                    html = html.replace("</body>", "<script>${jsFile.fileContent}</script></body>")
                }
                html
            } else {
                "<h3>No index.html file found in project workspace, Boss!</h3>"
            }

            WebPreviewEmulatorDialog(
                htmlContent = runtimeHtml,
                projectName = activeProject?.projectName ?: "Web Preview",
                onClose = { showEmulator = false }
            )
        }

        // 4. POLLINATIONS AI GRAPHIC GENERATOR DIALOG
        if (showAssetGenerator) {
            AlertDialog(
                onDismissRequest = { showAssetGenerator = false },
                title = { Text("Generate AI Graphic Asset", color = RubyText, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "Enter a prompt. Ruby will generate a visual asset using Pollinations AI and save it inside your project folder!",
                            fontSize = 12.sp,
                            color = RubyTextMuted,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        OutlinedTextField(
                            value = assetPrompt,
                            onValueChange = { assetPrompt = it },
                            label = { Text("AI Image Prompt", color = RubyRed) },
                            placeholder = { Text("e.g. game icon, background pattern") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RubyRed,
                                unfocusedBorderColor = RubySurfaceVariant,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = assetFileName,
                            onValueChange = { assetFileName = it },
                            label = { Text("File Name in project", color = RubyRed) },
                            placeholder = { Text("e.g. logo.png") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RubyRed,
                                unfocusedBorderColor = RubySurfaceVariant,
                                focusedTextColor = RubyText,
                                unfocusedTextColor = RubyText
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (assetPrompt.isNotBlank() && assetFileName.isNotBlank()) {
                                isGeneratingAsset = true
                                activeProject?.let { proj ->
                                    viewModel.generateAndSaveProjectAsset(
                                        projectId = proj.id,
                                        assetName = assetFileName,
                                        prompt = assetPrompt
                                    ) { success ->
                                        isGeneratingAsset = false
                                        showAssetGenerator = false
                                        assetPrompt = ""
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                        enabled = !isGeneratingAsset && assetPrompt.isNotBlank() && assetFileName.isNotBlank()
                    ) {
                        if (isGeneratingAsset) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        } else {
                            Text("Generate & Save", color = Color.White)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAssetGenerator = false }) {
                        Text("Cancel", color = RubyTextMuted)
                    }
                },
                containerColor = RubySurface
            )
        }

        // 5. SAMAD BHAI DELETE LOCK DIALOG
        projectToDelete?.let { proj ->
            AlertDialog(
                onDismissRequest = { projectToDelete = null },
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = RubyRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ruby Permission Lock",
                            color = RubyText,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Samad bhai, kya is ko delete karu?",
                            color = RubyRed,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Text(
                            text = "Are you sure you want to delete project: '${proj.projectName}'?",
                            color = RubyTextMuted,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Text(
                            text = "This will physically delete all file structures.",
                            color = RubyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteProject(proj.id)
                            projectToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed)
                    ) {
                        Text("Haa, Delete kardo", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { projectToDelete = null }
                    ) {
                        Text("Nahi, Cancel karo", color = RubyTextMuted)
                    }
                },
                containerColor = RubySurface
            )
        }
    }
}

@Composable
fun ProjectCatalogCard(
    project: GeneratedProject,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = RubySurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(RubySurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        project.projectType.contains("Web", ignoreCase = true) -> Icons.Default.Html
                        else -> Icons.Default.Android
                    },
                    contentDescription = "Project Type",
                    tint = RubyRed,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.projectName,
                    color = RubyText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = project.projectDescription,
                    color = RubyTextMuted,
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "DIR: .../${project.projectName}",
                    color = RubyOrange,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete project",
                    tint = RubyTextMuted.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun WebPreviewEmulatorDialog(
    htmlContent: String,
    projectName: String,
    onClose: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = RubyBg
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top control bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RubySurface)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AppShortcut,
                            contentDescription = "App active preview",
                            tint = RubyRed
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$projectName [Live Preview]",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close preview",
                            tint = Color.White
                        )
                    }
                }

                // Native WebView Canvas Container
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            webViewClient = WebViewClient()
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            }
                            loadDataWithBaseURL(
                                "file:///android_asset/",
                                htmlContent,
                                "text/html",
                                "utf-8",
                                null
                            )
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}
