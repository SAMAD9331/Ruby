package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

private val RubyColorScheme = lightColorScheme(
    primary = RubyRed,
    secondary = RubyOrange,
    tertiary = RubyAccent,
    background = RubyBg,
    surface = RubySurface,
    onPrimary = Color.White,
    onSecondary = RubyText,
    onTertiary = RubyText,
    onBackground = RubyText,
    onSurface = RubyText,
    surfaceVariant = RubySurfaceVariant,
    onSurfaceVariant = RubyTextMuted
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Force light theme for that clean Sleek Interface look
    dynamicColor: Boolean = false, // Enforce the customized Sleek aesthetic
    content: @Composable () -> Unit,
) {
    val colorScheme = RubyColorScheme

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
