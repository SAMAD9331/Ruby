package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.util.Log
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.compose.ui.text.font.FontFamily
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.components.RubyDigitalPet
import com.example.ui.components.RubySettingsDialog
import com.example.ui.theme.*
import com.example.viewmodel.RubyViewModel
import com.example.viewmodel.LaunchTargetType
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RubyAssistantScreen(viewModel: RubyViewModel, modifier: Modifier = Modifier) {
    val messages by viewModel.messages.collectAsState()
    val isThinking by viewModel.isRubyThinking.collectAsState()
    val isSpeaking by viewModel.isRubySpeaking.collectAsState()
    val isListening by viewModel.isRubyListening.collectAsState()
    val isMusicianMode by viewModel.isMusicianMode.collectAsState()
    val statusText by viewModel.currentStatusText.collectAsState()
    val logs by viewModel.memoryLogs.collectAsState()
    val userMemories by viewModel.userMemories.collectAsState()

    val isVoiceCallActive by viewModel.isVoiceCallActive.collectAsState()
    val isCallMuted by viewModel.isCallMuted.collectAsState()
    val isCallSpeakerOn by viewModel.isCallSpeakerOn.collectAsState()
    val callDurationSeconds by viewModel.callDurationSeconds.collectAsState()

    var isRealAccessibilityActive by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showAddonDialog by remember { mutableStateOf(false) }
    var modelReloadTrigger by remember { mutableIntStateOf(0) }
    var textInput by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // STT Speech Recognizer Launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            viewModel.setListeningState(false)
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spokenText = matches?.firstOrNull() ?: ""
                if (spokenText.isNotEmpty()) {
                    textInput = spokenText
                    viewModel.sendMessage(spokenText)
                    textInput = ""
                }
            }
        }
    )

    fun startSpeechToText() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Ruby is listening, speak now Boss!")
            }
            viewModel.setListeningState(true)
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            viewModel.setListeningState(false)
            viewModel.speakSpeechSafe("Speech recognition is not supported on this device, Boss.")
        }
    }

    val launchEvent by viewModel.launchEvent.collectAsState()

    // Handle App Launch Intent Events (Photo/Video Editing Apps & Media Tools)
    LaunchedEffect(launchEvent) {
        launchEvent?.let { event ->
            try {
                val intent = when (event.target) {
                    LaunchTargetType.PHOTO_EDITOR -> {
                        Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                            type = "image/*"
                        }
                    }
                    LaunchTargetType.VIDEO_EDITOR -> {
                        Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).apply {
                            type = "video/*"
                        }
                    }
                    LaunchTargetType.CAMERA -> {
                        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    }
                    LaunchTargetType.GALLERY -> {
                        Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    }
                    LaunchTargetType.CAPCUT -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.lemon.lvoverseas")
                            ?: pm.getLaunchIntentForPackage("com.capcut.edit")
                            ?: Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).apply { type = "video/*" }
                    }
                    LaunchTargetType.KINEMASTER -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.nexstreaming.app.kinemasterfree")
                            ?: Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).apply { type = "video/*" }
                    }
                    LaunchTargetType.PICSART -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.picsart.studio")
                            ?: Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply { type = "image/*" }
                    }
                    LaunchTargetType.LIGHTROOM -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.adobe.lrmobile")
                            ?: Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply { type = "image/*" }
                    }
                    LaunchTargetType.INSHOT -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.camerasideas.instashot")
                            ?: Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).apply { type = "video/*" }
                    }
                    LaunchTargetType.SETTINGS -> Intent(Settings.ACTION_SETTINGS)
                    LaunchTargetType.CALCULATOR -> {
                        val pm = context.packageManager
                        pm.getLaunchIntentForPackage("com.google.android.calculator")
                            ?: pm.getLaunchIntentForPackage("com.sec.android.app.popupcalculator")
                            ?: Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_APP_CALCULATOR) }
                    }
                    LaunchTargetType.YOUTUBE, LaunchTargetType.WHATSAPP, LaunchTargetType.INSTAGRAM,
                    LaunchTargetType.FACEBOOK, LaunchTargetType.CHROME, LaunchTargetType.SPOTIFY,
                    LaunchTargetType.TELEGRAM, LaunchTargetType.PLAYSTORE, LaunchTargetType.GMAIL -> {
                        val pm = context.packageManager
                        val pkg = event.packageName
                        val launchIntent = if (pkg != null) pm.getLaunchIntentForPackage(pkg) else null
                        launchIntent ?: Intent(Intent.ACTION_VIEW, Uri.parse(if (pkg != null) "market://details?id=$pkg" else "https://play.google.com"))
                    }
                    LaunchTargetType.GENERIC_APP -> {
                        val pm = context.packageManager
                        val query = (event.searchKeyword ?: event.label).lowercase()
                        var launchIntent: Intent? = null
                        try {
                            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
                            val apps = pm.queryIntentActivities(mainIntent, 0)
                            for (app in apps) {
                                val label = app.loadLabel(pm).toString().lowercase()
                                if (label.contains(query) || app.activityInfo.packageName.lowercase().contains(query)) {
                                    launchIntent = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
                                    if (launchIntent != null) break
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("RubyScreen", "App launch search failed", e)
                        }
                        launchIntent ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(query)}"))
                    }
                }
                context.startActivity(intent)
                Toast.makeText(context, "Opening ${event.label}...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Launching ${event.label}...", Toast.LENGTH_SHORT).show()
            }
            viewModel.clearLaunchEvent()
        }
    }

    // Auto-scroll chat to bottom whenever a new message is loaded
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RubyBg)
    ) {
        // 1. Digital Pet Center Frame
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = RubySurface),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RubyDigitalPet(
                    isThinking = isThinking,
                    isSpeaking = isSpeaking,
                    isListening = isListening,
                    isMusician = isMusicianMode,
                    modifier = Modifier.size(110.dp),
                    onClick = {
                        coroutineScope.launch {
                            if (messages.isNotEmpty()) {
                                lazyListState.animateScrollToItem(messages.size - 1)
                            }
                            try {
                                focusRequester.requestFocus()
                            } catch (e: Exception) {
                                Log.e("RubyScreen", "Focus request failed", e)
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RUBY AI v1.0",
                                color = RubyRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (isRealAccessibilityActive) Color(0xFF1B5E20) else Color(0xFF333344),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (isRealAccessibilityActive) "🟢 Agent Online" else "🔴 Agent Offline",
                                    color = if (isRealAccessibilityActive) Color(0xFF81C784) else Color.LightGray,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Live Voice Call Mode Trigger & Ruby Folder Song Saver
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.saveCurrentSongToRubyFolder() },
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(Color(0xFF8E24AA), RoundedCornerShape(14.dp))
                            ) {
                                Text("🎵", fontSize = 12.sp)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Button(
                                onClick = { viewModel.startVoiceCall() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Live Voice Call",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Call Ruby", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { showAddonDialog = true },
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(Color(0xFF2E7D32), RoundedCornerShape(14.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Extension,
                                    contentDescription = "MCPE Addons",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { showSettingsDialog = true },
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(RubySurfaceVariant, RoundedCornerShape(14.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Ruby Settings",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = when {
                            isListening -> "Listening closely..."
                            isThinking -> "Processing algorithms..."
                            isSpeaking -> "Speaking to you..."
                            else -> "Online & At Your Service"
                        },
                        color = RubyText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Animated ticker bar showing "Kya kaam ho raha hai"
                    Surface(
                        color = RubyBg.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Circle,
                                contentDescription = "Status dot",
                                tint = if (isThinking || isListening || isSpeaking) RubyRed else Color.Green,
                                modifier = Modifier
                                    .size(8.dp)
                                    .padding(1.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = statusText,
                                color = RubyTextMuted,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // 1.5. ACCESSIBILITY & FLOATING OVERLAY CONTROLLER HUB
        var isOverlayExpanded by remember { mutableStateOf(false) }
        var isAccessibilityActive by remember { mutableStateOf(false) }
        var isFloatingBubbleActive by remember { mutableStateOf(false) }
        var clickTextInput by remember { mutableStateOf("") }
        var typeTextInput by remember { mutableStateOf("") }
        var isStorageGranted by remember { mutableStateOf(false) }

        var is3DVTuberOverlayActive by remember { mutableStateOf(false) }

        // SAF launcher to pick custom .glb 3D models (MCPE style)
        val glbPickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                val success = com.example.util.RubyModelManager.importModelFromUri(context, uri)
                if (success) {
                    viewModel.speakSpeechSafe("3D GLB Model successfully imported! Reloading VTuber engine...")
                    com.example.service.RubyOverlayService.reloadModel(context)
                } else {
                    viewModel.speakSpeechSafe("Failed to import GLB model file.")
                }
            }
        }

        // Launcher for storage permissions
        val storageLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions(),
            onResult = { permissions ->
                isStorageGranted = permissions.entries.all { it.value }
                if (isStorageGranted) {
                    viewModel.speakSpeechSafe("Samad bhai, storage permission mil chuki hai! Ab video drafts aur visual assets dynamic reading successfully ho jayegi.")
                } else {
                    viewModel.speakSpeechSafe("Storage permissions not fully granted, Boss.")
                }
            }
        )

        // Periodically check if the actual RubyAccessibilityService is enabled in Android settings & storage state
        LaunchedEffect(Unit) {
            while (true) {
                isRealAccessibilityActive = com.example.service.RubyAccessibilityService.isServiceRunning()
                isAccessibilityActive = isRealAccessibilityActive
                
                // Native storage check
                val hasStorage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED
                } else {
                    androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
                }
                isStorageGranted = hasStorage
                
                kotlinx.coroutines.delay(1000)
            }
        }
        
        // Termux terminal output log state simulation
        val termuxLogs = remember { mutableStateListOf<String>() }
        var isTermuxBuilding by remember { mutableStateOf(false) }

        // Handle Termux compiler task loops with Ruby Security Guard validation
        LaunchedEffect(isTermuxBuilding) {
            if (isTermuxBuilding) {
                termuxLogs.clear()
                termuxLogs.add("[Termux @ Android]:~$ pkg update && pkg upgrade -y")
                kotlinx.coroutines.delay(800)
                termuxLogs.add("Updating repository packages... [Done]")
                termuxLogs.add("[Termux @ Android]:~$ ruby_security_guard --scan-cmd")
                
                // Security check verification
                val (isSafe, secMessage) = com.example.util.RubySecurityEngine.validateTermuxCommand("pkg update && node ruby_builder_agent.js")
                termuxLogs.add(">> Ruby Cyber Guard: $secMessage")
                
                if (isSafe) {
                    termuxLogs.add("[Termux @ Android]:~$ node ruby_builder_agent.js")
                    kotlinx.coroutines.delay(1000)
                    termuxLogs.add(">> Ruby: Initializing automated AI build engine...")
                    termuxLogs.add(">> Ruby: Reading project source modules...")
                    kotlinx.coroutines.delay(1000)
                    termuxLogs.add(">> Ruby: Compiling resources into custom APK...")
                    kotlinx.coroutines.delay(1200)
                    termuxLogs.add(">> Ruby: Success! Full automated build complete 'ruby_auto_app.apk'")
                    termuxLogs.add("[Termux @ Android]:~$ am start -n com.aistudio.project/MainActivity")
                    termuxLogs.add(">> Launching application on main hardware loop!")
                }
                isTermuxBuilding = false
            }
        }

        val overlayContext = LocalContext.current

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = RubySurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Header row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isOverlayExpanded = !isOverlayExpanded },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Accessibility,
                            contentDescription = "Accessibility Automation Mode",
                            tint = RubyRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Ruby Automation & Overlay Hub",
                                color = RubyText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Real Screen Injection, Overlay Bubble & Termux Control",
                                color = RubyTextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = if (isOverlayExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Expand",
                        tint = RubyTextMuted
                    )
                }

                if (isOverlayExpanded) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = RubySurfaceVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Controls row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Toggle 1: Floating Overlay Bubble Service
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "OVERLAY BUBBLE",
                                color = RubyText,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FilledIconToggleButton(
                                checked = isFloatingBubbleActive,
                                onCheckedChange = { checked ->
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(overlayContext)) {
                                        // Request permission
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${overlayContext.packageName}")
                                        )
                                        overlayContext.startActivity(intent)
                                        viewModel.speakSpeechSafe("Samad bhai, floating bubble chalane ke liye screen drawing permission allow kar dijiye!")
                                    } else {
                                        isFloatingBubbleActive = checked
                                        val serviceIntent = Intent(overlayContext, com.example.service.FloatingBubbleService::class.java)
                                        if (checked) {
                                            overlayContext.startService(serviceIntent)
                                            viewModel.speakSpeechSafe("Floating bubble mode start ho gaya, Boss!")
                                        } else {
                                            overlayContext.stopService(serviceIntent)
                                            viewModel.speakSpeechSafe("Floating bubble mode band kar diya hai, Samad bhai.")
                                        }
                                    }
                                },
                                colors = IconButtonDefaults.filledIconToggleButtonColors(
                                    checkedContainerColor = RubyRed,
                                    containerColor = RubySurfaceVariant
                                ),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Floating bubble",
                                    tint = if (isFloatingBubbleActive) Color.White else RubyTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Toggle 2: Accessibility Real Robotic Automation Service
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (isRealAccessibilityActive) "ROBOTIC ACTIVE" else "ROBOTIC OFFLINE",
                                color = if (isRealAccessibilityActive) RubyOrange else RubyText,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FilledIconToggleButton(
                                checked = isRealAccessibilityActive,
                                onCheckedChange = {
                                    try {
                                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                        overlayContext.startActivity(intent)
                                        viewModel.speakSpeechSafe("Samad bhai, list me se Ruby AI Smart Agent Automation ko turn on kijiye!")
                                    } catch (e: Exception) {
                                        viewModel.speakSpeechSafe("Failed to open Accessibility Settings, Boss.")
                                    }
                                },
                                colors = IconButtonDefaults.filledIconToggleButtonColors(
                                    checkedContainerColor = RubyOrange,
                                    containerColor = RubySurfaceVariant
                                ),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Accessibility,
                                    contentDescription = "Robotic Automation",
                                    tint = if (isRealAccessibilityActive) Color.White else RubyTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Toggle 3: Storage Access Permission Check
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (isStorageGranted) "STORAGE ON" else "STORAGE OFF",
                                color = if (isStorageGranted) Color.Green else RubyText,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FilledIconToggleButton(
                                checked = isStorageGranted,
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            arrayOf(
                                                android.Manifest.permission.READ_MEDIA_IMAGES,
                                                android.Manifest.permission.READ_MEDIA_VIDEO,
                                                android.Manifest.permission.READ_MEDIA_AUDIO
                                            )
                                        } else {
                                            arrayOf(
                                                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            )
                                        }
                                        storageLauncher.launch(perms)
                                    } else {
                                        viewModel.speakSpeechSafe("Storage permissions settings se allow kijiye, Samad bhai.")
                                    }
                                },
                                colors = IconButtonDefaults.filledIconToggleButtonColors(
                                    checkedContainerColor = Color.Green,
                                    containerColor = RubySurfaceVariant
                                ),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = "Storage Access",
                                    tint = if (isStorageGranted) Color.Black else RubyTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Toggle 4: Termux Compiler Controller
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "TERMUX BUILD",
                                color = RubyText,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FilledIconToggleButton(
                                checked = isTermuxBuilding,
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        isTermuxBuilding = true
                                        viewModel.speakSpeechSafe("Termux se high performance app binary configuration compilation start ho rahi hai, Samad bhai!")
                                    }
                                },
                                colors = IconButtonDefaults.filledIconToggleButtonColors(
                                    checkedContainerColor = Color.Green,
                                    containerColor = RubySurfaceVariant
                                ),
                                modifier = Modifier.size(40.dp),
                                enabled = !isTermuxBuilding
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = "Termux terminal compiler",
                                    tint = if (isTermuxBuilding) Color.Black else RubyTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3D VTuber Overlay & SAF Model Importer Strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(overlayContext)) {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${overlayContext.packageName}")
                                    )
                                    overlayContext.startActivity(intent)
                                    viewModel.speakSpeechSafe("Samad bhai, 3D VTuber overlay chalane ke liye screen overlay permission allow kijiye!")
                                } else {
                                    is3DVTuberOverlayActive = !is3DVTuberOverlayActive
                                    if (is3DVTuberOverlayActive) {
                                        com.example.service.RubyOverlayService.startService(overlayContext)
                                        viewModel.speakSpeechSafe("3D VTuber Floating Overlay active ho gaya hai, Boss!")
                                    } else {
                                        com.example.service.RubyOverlayService.stopService(overlayContext)
                                        viewModel.speakSpeechSafe("3D VTuber Overlay closed.")
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (is3DVTuberOverlayActive) RubyRed else RubySurfaceVariant
                            ),
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (is3DVTuberOverlayActive) "3D VTuber On" else "3D VTuber Overlay",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }

                        Button(
                            onClick = {
                                showSettingsDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A1B9A)),
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Skins & Settings",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                    }

                    // Render Settings & Model Manager Dialog
                    if (showSettingsDialog) {
                        RubySettingsDialog(
                            onDismiss = { showSettingsDialog = false },
                            onModelChanged = { modelReloadTrigger++ }
                        )
                    }

                    // Render MCPE Addon Importer Dialog
                    if (showAddonDialog) {
                        AddonManagerDialog(
                            onDismiss = { showAddonDialog = false }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Real Accessibility System Injection Panel
                    if (isRealAccessibilityActive) {
                        Text(
                            text = "⚡ REAL SYSTEM INJECTION PANEL (Robotic Hands Active)",
                            color = RubyOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Card(
                            colors = CardDefaults.cardColors(containerColor = RubyBg),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Ruby can physically control other apps (like YouTube or MCPE). Use these triggers to test her robotic injection powers:",
                                    color = RubyText,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )

                                // Row 1: Global system navigation buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                                            viewModel.speakSpeechSafe("Going Home!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🏠 Home", fontSize = 10.sp, color = RubyText)
                                    }

                                    Button(
                                        onClick = {
                                            com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                                            viewModel.speakSpeechSafe("Going Back!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("⬅️ Back", fontSize = 10.sp, color = RubyText)
                                    }

                                    Button(
                                        onClick = {
                                            com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                                            viewModel.speakSpeechSafe("Opening Notifications!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🔔 Notify", fontSize = 10.sp, color = RubyText)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                 // Row 2: Gesture swipes
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            com.example.service.RubyAccessibilityService.performSwipe(500f, 1600f, 500f, 400f, 350)
                                            viewModel.speakSpeechSafe("Swiping Up, Samad bhai!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("👆 Swipe Up", fontSize = 10.sp, color = RubyText)
                                    }

                                    Button(
                                        onClick = {
                                            com.example.service.RubyAccessibilityService.performSwipe(500f, 400f, 500f, 1600f, 350)
                                            viewModel.speakSpeechSafe("Swiping Down!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("👇 Swipe Down", fontSize = 10.sp, color = RubyText)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Row 3: Volume & Torch Controls
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.sendMessage("Volume badhao") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🔊 Vol +", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("Volume kam karo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🔉 Vol -", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("Torch ON karo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57C00)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🔦 Torch ON", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("Torch OFF karo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("🔦 Torch OFF", fontSize = 10.sp, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Row 4: YouTube Media Controls & Screenshot / Clipboard
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.sendMessage("YouTube video pause karo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2185B)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("⏯️ Play/Pause", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("YouTube video skip karo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E24AA)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("⏭️ Skip Video", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("Copied text padho") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("📋 Clipboard", fontSize = 10.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { viewModel.sendMessage("Screenshot lo") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("📸 Screenshot", fontSize = 10.sp, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Custom click on text field
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextField(
                                        value = clickTextInput,
                                        onValueChange = { clickTextInput = it },
                                        placeholder = { Text("Enter button/link text...", fontSize = 9.sp, color = RubyTextMuted) },
                                        modifier = Modifier.weight(1.5f).height(44.dp),
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = RubySurface,
                                            unfocusedContainerColor = RubySurface,
                                            focusedTextColor = RubyText,
                                            unfocusedTextColor = RubyText
                                        ),
                                        singleLine = true,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            if (clickTextInput.isNotEmpty()) {
                                                val clicked = com.example.service.RubyAccessibilityService.performClickOnText(clickTextInput)
                                                if (clicked) {
                                                    viewModel.speakSpeechSafe("Successfully clicked $clickTextInput!")
                                                } else {
                                                    viewModel.speakSpeechSafe("Text not found on screen, Samad bhai.")
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubyOrange),
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Click Text", fontSize = 10.sp, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Custom Text typing injection
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextField(
                                        value = typeTextInput,
                                        onValueChange = { typeTextInput = it },
                                        placeholder = { Text("Enter text to type...", fontSize = 9.sp, color = RubyTextMuted) },
                                        modifier = Modifier.weight(1.5f).height(44.dp),
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = RubySurface,
                                            unfocusedContainerColor = RubySurface,
                                            focusedTextColor = RubyText,
                                            unfocusedTextColor = RubyText
                                        ),
                                        singleLine = true,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            if (typeTextInput.isNotEmpty()) {
                                                val typed = com.example.service.RubyAccessibilityService.typeIntoFocusedNode(typeTextInput)
                                                if (typed) {
                                                    viewModel.speakSpeechSafe("Typed successfully!")
                                                } else {
                                                    viewModel.speakSpeechSafe("No active text box focused.")
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Type Text", fontSize = 10.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    } else {
                        // Offline state
                        Card(
                            colors = CardDefaults.cardColors(containerColor = RubyBg),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "🔌 REAL SYSTEM AUTOMATION IS OFFLINE",
                                    color = RubyRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                Text(
                                    text = "Samad bhai, real automation active karne ke liye niche click karke system settings se permission on kijiye! Isse Ruby ko real robotic hands milenge aur woh YouTube ya Kisi bhi app me clicking/typing khud kar sakegi!",
                                    color = RubyTextMuted,
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp,
                                    modifier = Modifier.padding(bottom = 10.dp)
                                )
                                Button(
                                    onClick = {
                                        try {
                                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                            overlayContext.startActivity(intent)
                                            viewModel.speakSpeechSafe("Accessibility page open ho raha hai, Samad bhai. List me se Ruby service ko select karke turn on kijiye!")
                                        } catch (e: Exception) {
                                            viewModel.speakSpeechSafe("Could not open settings, please open manually.")
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RubyOrange),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Activate Ruby Robotic Hands", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Human-Like Long-Term Memory (LTM) Card
                    Text(
                        text = "🧠 HUMAN-LIKE LONG-TERM MEMORY (LTM)",
                        color = Color(0xFFBA68C8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = RubyBg),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Ruby remembers your identity, preferences, projects & style across years:",
                                    color = RubyTextMuted,
                                    fontSize = 10.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = { viewModel.clearUserMemories() },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text("Clear All", fontSize = 9.sp, color = RubyRed)
                                }
                            }

                            if (userMemories.isEmpty()) {
                                Text(
                                    text = "No long-term memories saved yet. Talk to Ruby (e.g. 'Mera naam Samad hai', 'Mera favorite game Free Fire hai') and she will remember forever!",
                                    color = RubyTextMuted,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            } else {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    items(userMemories) { mem ->
                                        Surface(
                                            color = when(mem.category) {
                                                "IDENTITY" -> Color(0xFF1565C0)
                                                "PREFERENCE" -> Color(0xFFC2185B)
                                                "PROJECT" -> Color(0xFF2E7D32)
                                                "BEHAVIORAL" -> Color(0xFF6A1B9A)
                                                else -> RubySurfaceVariant
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "[${mem.category}] ${mem.memoryKey}: ${mem.memoryValue}",
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Delete Memory",
                                                    tint = Color.White.copy(alpha = 0.7f),
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .clickable { viewModel.deleteUserMemory(mem.memoryKey) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (isTermuxBuilding || termuxLogs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Termux Build Logs",
                            color = Color.Green,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 120.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier.padding(8.dp).fillMaxWidth()
                            ) {
                                items(termuxLogs) { log ->
                                    Text(
                                        text = log,
                                        color = if (log.startsWith("[")) Color.Cyan else if (log.startsWith(">> Success")) Color.Green else Color.White,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Chat Log lazy column
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            if (messages.isEmpty()) {
                // Friendly Cyber Greeting for empty screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SmartToy,
                        contentDescription = "Ruby Robot",
                        tint = RubyRed.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Aapka Automated Assistant",
                        color = RubyText,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Speak or type any command like 'Open video editor', 'Run Termux script', 'Volume badhao' or 'Create a calculator web app'!",
                        color = RubyTextMuted,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            } else {
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages) { message ->
                        ChatMessageBubble(message = message, onTextClicked = {
                            viewModel.speakSpeechSafe(message.text)
                        })
                    }
                }
            }
        }

        // 3. System Activity Log Strip (remembers what is happening)
        if (logs.isNotEmpty()) {
            Surface(
                color = RubySurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clickable {
                        coroutineScope.launch {
                            viewModel.clearSystemLogs()
                        }
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "Memory Logs",
                            tint = RubyOrange,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Latest Activity: ${logs.first().taskDescription}",
                            color = RubyTextMuted,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                    Text(
                        text = "CLEAR LOGS",
                        color = RubyRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 4. Input Console Box
        Surface(
            color = RubySurface,
            modifier = Modifier.fillMaxWidth(),
            tonalElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .navigationBarsPadding()
                    .imePadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Voice Call Mode Button
                IconButton(
                    onClick = { viewModel.startVoiceCall() },
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(listOf(Color(0xFF4CAF50), Color(0xFF2E7D32))),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Live Voice Call",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Microphone STT Trigger (Speech input)
                IconButton(
                    onClick = { startSpeechToText() },
                    modifier = Modifier
                        .background(
                            Brush.radialGradient(listOf(RubyRed, RubyOrange)),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .size(44.dp)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.VolumeUp else Icons.Default.Mic,
                        contentDescription = "STT Microphone Speak",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Text input field with Material 3 styling
                TextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Ask Ruby to build an app or write a script...", fontSize = 13.sp, color = RubyTextMuted) },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(max = 120.dp)
                        .focusRequester(focusRequester),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = RubyBg,
                        unfocusedContainerColor = RubyBg,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = RubyText,
                        unfocusedTextColor = RubyText
                    ),
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (textInput.trim().isNotEmpty()) {
                            viewModel.sendMessage(textInput)
                            textInput = ""
                        }
                    })
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Button
                IconButton(
                    onClick = {
                        if (textInput.trim().isNotEmpty()) {
                            viewModel.sendMessage(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp),
                    enabled = textInput.trim().isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send Chat Message",
                        tint = if (textInput.trim().isNotEmpty()) RubyRed else RubyTextMuted
                    )
                }
            }
        }
    }

    // Full Screen Voice Call Overlay
    if (isVoiceCallActive) {
        RubyLiveCallOverlay(
            viewModel = viewModel,
            callDurationSeconds = callDurationSeconds,
            isCallMuted = isCallMuted,
            isCallSpeakerOn = isCallSpeakerOn,
            isThinking = isThinking,
            isSpeaking = isSpeaking,
            isListening = isListening,
            onStartSpeech = { startSpeechToText() },
            onEndCall = { viewModel.endVoiceCall() }
        )
    }
}

@Composable
fun ChatMessageBubble(message: ChatMessage, onTextClicked: () -> Unit) {
    val isUser = message.isUser
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val containerColor = if (isUser) RubyOrange else RubySurface
    val shape = if (isUser) {
        RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
    }
    val textColor = RubyText
    val dateString = remember(message.timestamp) {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        sdf.format(Date(message.timestamp))
    }

    // Parse Pollinations Image URL if available
    val rawText = message.text
    var displayText = rawText
    var imageUrlToRender by remember(rawText) { mutableStateOf<String?>(null) }
    var isZoomed by remember { mutableStateOf(false) }

    LaunchedEffect(rawText) {
        if (rawText.contains("[POLLINATIONS_IMAGE:")) {
            val startIndex = rawText.indexOf("[POLLINATIONS_IMAGE:")
            val endIndex = rawText.indexOf("]", startIndex)
            if (endIndex != -1) {
                imageUrlToRender = rawText.substring(startIndex + 20, endIndex).trim()
            }
        }
    }

    displayText = remember(rawText) {
        if (rawText.contains("[POLLINATIONS_IMAGE:")) {
            val startIndex = rawText.indexOf("[POLLINATIONS_IMAGE:")
            val endIndex = rawText.indexOf("]", startIndex)
            if (endIndex != -1) {
                rawText.removeRange(startIndex, endIndex + 1).trim()
            } else {
                rawText
            }
        } else {
            rawText
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 290.dp)
                .clip(shape)
                .background(containerColor)
                .clickable { onTextClicked() }
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column {
                if (displayText.isNotEmpty()) {
                    Text(
                        text = displayText,
                        color = textColor,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
                
                imageUrlToRender?.let { url ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RubyBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clickable { isZoomed = true }
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = url,
                                contentDescription = "Generated visual graphic by Pollinations AI",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            // Visual overlay badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(6.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "AI",
                                        tint = RubyOrange,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Pollinations AI",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isUser) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speak Text",
                            tint = RubyRed.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(11.dp)
                                .padding(end = 2.dp)
                        )
                    }
                    Text(
                        text = dateString,
                        color = RubyTextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }
        }
    }

    // Zoomed Preview Dialog
    if (isZoomed && imageUrlToRender != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { isZoomed = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RubySurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        AsyncImage(
                            model = imageUrlToRender,
                            contentDescription = "Expanded graphic preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Pollinations AI Graphic",
                        color = RubyText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tap outside to dismiss",
                        color = RubyTextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { isZoomed = false },
                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close Preview", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RubyLiveCallOverlay(
    viewModel: RubyViewModel,
    callDurationSeconds: Int,
    isCallMuted: Boolean,
    isCallSpeakerOn: Boolean,
    isThinking: Boolean,
    isSpeaking: Boolean,
    isListening: Boolean,
    onStartSpeech: () -> Unit,
    onEndCall: () -> Unit
) {
    val minutes = callDurationSeconds / 60
    val seconds = callDurationSeconds % 60
    val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0D18))
            .clickable(enabled = false) {}
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Call Info Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(20.dp))
                Surface(
                    color = Color(0xFF1E1E2E),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Green)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Ruby Voice Call • HD", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text("RUBY AI", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(formattedTime, color = RubyRed, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            // Center Digital Pet & Glowing Voice Animation
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                // Outer glowing circle pulse
                Surface(
                    modifier = Modifier.size(220.dp),
                    shape = RoundedCornerShape(110.dp),
                    color = RubyRed.copy(alpha = if (isSpeaking || isListening) 0.25f else 0.08f)
                ) {}
                Surface(
                    modifier = Modifier.size(170.dp),
                    shape = RoundedCornerShape(85.dp),
                    color = RubyOrange.copy(alpha = if (isSpeaking || isListening) 0.35f else 0.12f)
                ) {}

                RubyDigitalPet(
                    isThinking = isThinking,
                    isSpeaking = isSpeaking,
                    isListening = isListening,
                    modifier = Modifier.size(140.dp),
                    onClick = { onEndCall() }
                )
            }

            // Call Status Message Indicator & Quick Voice Topics
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when {
                        isListening -> "Listening to you, Samad bhai..."
                        isThinking -> "Thinking & processing..."
                        isSpeaking -> "Ruby is speaking..."
                        isCallMuted -> "Microphone Muted"
                        else -> "Real Voice Companion • Connected Live!"
                    },
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                // Quick Call Topic Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendMessage("Kaise ho Ruby?") },
                            label = { Text("👋 How are you Ruby?", color = Color.White, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFF222238))
                        )
                    }
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendMessage("Mujhe ek interesting story batao!") },
                            label = { Text("✨ Tell me a story", color = Color.White, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFFD81B60))
                        )
                    }
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendMessage("Ek naya Android app banao") },
                            label = { Text("💡 Build an App", color = Color.White, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFF283593))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tap Speak button or chip to talk directly anytime",
                    color = RubyTextMuted,
                    fontSize = 11.sp
                )
            }

            // Bottom Action Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute Mic Button
                IconButton(
                    onClick = { viewModel.toggleCallMute() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(if (isCallMuted) RubyRed else Color(0xFF222238), shape = RoundedCornerShape(28.dp))
                ) {
                    Icon(
                        imageVector = if (isCallMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = Color.White
                    )
                }

                // Push to speak button
                IconButton(
                    onClick = { onStartSpeech() },
                    modifier = Modifier
                        .size(72.dp)
                        .background(
                            Brush.linearGradient(listOf(RubyRed, RubyOrange)),
                            shape = RoundedCornerShape(36.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Speak Now",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Speaker Toggle Button
                IconButton(
                    onClick = { viewModel.toggleCallSpeaker() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(if (isCallSpeakerOn) RubyOrange else Color(0xFF222238), shape = RoundedCornerShape(28.dp))
                ) {
                    Icon(
                        imageVector = if (isCallSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = "Speaker",
                        tint = Color.White
                    )
                }

                // End Call Red Button
                IconButton(
                    onClick = { onEndCall() },
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0xFFE53935), shape = RoundedCornerShape(32.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}
