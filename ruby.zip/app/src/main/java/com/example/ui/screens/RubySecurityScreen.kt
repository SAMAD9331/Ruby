package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.AppSecurityReport
import com.example.util.RubySecurityEngine
import com.example.util.ThreatCategory
import com.example.viewmodel.RubyViewModel
import kotlinx.coroutines.launch

/**
 * High-Level Cyber Security & Anti-Hacking Guard Screen for Ruby AI.
 * 
 * Provides:
 * - Automated Full System Virus & Malware Scanner
 * - Data Thief & GB Data Drainer Detection & Background Blocking
 * - Anti-Hacker Shield (Root/ADB/Spyware/Camera & Mic Intrusion Protection)
 * - Real-Time C++ Security Core Metrics
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RubySecurityScreen(
    viewModel: RubyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val isScanning by RubySecurityEngine.isScanning.collectAsState()
    val scanProgress by RubySecurityEngine.scanProgress.collectAsState()
    val scanStatusMessage by RubySecurityEngine.scanStatusMessage.collectAsState()
    val scannedThreats by RubySecurityEngine.scannedThreats.collectAsState()
    val systemOverview by RubySecurityEngine.systemOverview.collectAsState()
    val blockedDataThieves by RubySecurityEngine.blockedDataThieves.collectAsState()

    var activeTabFilter by remember { mutableStateOf(0) } // 0: Overview, 1: Threat Scan, 2: GB Data Block, 3: Anti-Hacker Shield

    // Trigger initial scan if empty
    LaunchedEffect(Unit) {
        if (scannedThreats.isEmpty() && !isScanning) {
            RubySecurityEngine.runAutomatedSecurityScan(context)
        }
    }

    val healthColor = when {
        systemOverview.healthScore >= 80 -> Color(0xFF00E676)
        systemOverview.healthScore >= 50 -> Color(0xFFFFD54F)
        else -> Color(0xFFFF1744)
    }

    val pulseTransition = rememberInfiniteTransition(label = "SecurityPulse")
    val shieldGlow by pulseTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ShieldGlow"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RubyBg)
            .padding(16.dp)
    ) {
        // --- Top Header ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(healthColor.copy(alpha = 0.4f), Color.Transparent)
                            ),
                            shape = CircleShape
                        )
                        .border(1.5.dp, healthColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Shield",
                        tint = healthColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Ruby Cyber Security",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "High-Level Anti-Hacker & Virus Guard",
                        color = RubyTextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Surface(
                color = RubySurface,
                shape = CircleShape,
                border = BorderStroke(1.dp, RubyRed.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF00E676), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "C++ Core Active",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Health Score Card & Scan Trigger ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(20.dp), spotColor = healthColor),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = RubySurface),
            border = BorderStroke(1.5.dp, healthColor.copy(alpha = 0.6f * shieldGlow))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (systemOverview.healthScore >= 80) "DEVICE SECURE & PROTECTED" else "SECURITY RISKS DETECTED!",
                            color = healthColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = scanStatusMessage,
                            color = RubyTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Score Badge Circular Progress
                    Box(
                        modifier = Modifier.size(68.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 7.dp.toPx()
                            drawArc(
                                color = Color.White.copy(alpha = 0.12f),
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(strokeWidth)
                            )
                            drawArc(
                                color = healthColor,
                                startAngle = -90f,
                                sweepAngle = (systemOverview.healthScore / 100f) * 360f,
                                useCenter = false,
                                style = Stroke(strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${systemOverview.healthScore}%",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "HEALTH",
                                color = RubyTextMuted,
                                fontSize = 8.sp
                            )
                        }
                    }
                }

                if (isScanning) {
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { scanProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = RubyRed,
                        trackColor = RubySurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        coroutineScope.launch {
                            RubySecurityEngine.runAutomatedSecurityScan(context)
                        }
                    },
                    enabled = !isScanning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isScanning) Icons.Default.Sync else Icons.Default.Radar,
                        contentDescription = "Scan",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isScanning) "Automated C++ Scanning..." else "Run Automated Virus & Anti-Hacker Scan",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Tab Selection Filter Bar ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                "All Threat Scan (${systemOverview.totalThreatsFound})",
                "Data Thief Block (${systemOverview.dataThievesFound})",
                "Anti-Hacker Shield"
            )

            tabs.forEachIndexed { index, title ->
                val isSelected = activeTabFilter == index
                Surface(
                    onClick = { activeTabFilter = index },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) RubyRed else RubySurface,
                    border = BorderStroke(1.dp, if (isSelected) RubyRed else RubySurfaceVariant)
                ) {
                    Text(
                        text = title,
                        modifier = Modifier
                            .padding(vertical = 10.dp)
                            .fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = if (isSelected) Color.White else RubyTextMuted,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- Main Section Content ---
        when (activeTabFilter) {
            0 -> ThreatScanListSection(
                threats = scannedThreats,
                context = context,
                onBlockData = { pkg -> RubySecurityEngine.toggleBlockDataThief(context, pkg) }
            )
            1 -> DataThiefBlockSection(
                threats = scannedThreats.filter { it.threatCategory == ThreatCategory.DATA_THIEF_GB || it.dataUsageMB > 100f },
                blockedPackages = blockedDataThieves,
                onToggleBlock = { pkg -> RubySecurityEngine.toggleBlockDataThief(context, pkg) }
            )
            2 -> AntiHackerShieldSection(
                overview = systemOverview,
                context = context
            )
        }
    }
}

@Composable
fun ThreatScanListSection(
    threats: List<AppSecurityReport>,
    context: android.content.Context,
    onBlockData: (String) -> Unit
) {
    val suspiciousThreats = threats.filter { it.threatCategory != ThreatCategory.CLEAN }

    if (suspiciousThreats.isEmpty()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = RubySurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "Safe",
                    tint = Color(0xFF00E676),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "No Virus or Malware Threats Detected!",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Ruby automated C++ scanner evaluated all installed packages. Your device is clean and protected from hackers.",
                    color = RubyTextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(suspiciousThreats, key = { it.packageName }) { report ->
                ThreatItemCard(report = report, context = context, onBlockData = onBlockData)
            }
        }
    }
}

@Composable
fun ThreatItemCard(
    report: AppSecurityReport,
    context: android.content.Context,
    onBlockData: (String) -> Unit
) {
    val categoryColor = when (report.threatCategory) {
        ThreatCategory.CRITICAL_VIRUS -> Color(0xFFFF1744)
        ThreatCategory.HIGH_RISK_SPYWARE -> Color(0xFFFF9100)
        ThreatCategory.DATA_THIEF_GB -> Color(0xFFFFD54F)
        else -> Color(0xFF00E5FF)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = RubySurface),
        border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(categoryColor.copy(alpha = 0.18f), CircleShape)
                            .border(1.dp, categoryColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (report.threatCategory) {
                                ThreatCategory.CRITICAL_VIRUS -> Icons.Default.BugReport
                                ThreatCategory.HIGH_RISK_SPYWARE -> Icons.Default.Visibility
                                ThreatCategory.DATA_THIEF_GB -> Icons.Default.DataSaverOn
                                else -> Icons.Default.Warning
                            },
                            contentDescription = "Threat",
                            tint = categoryColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = report.appName,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = report.packageName,
                            color = RubyTextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Surface(
                    color = categoryColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, categoryColor)
                ) {
                    Text(
                        text = "Risk Score: ${report.riskScore.toInt()}/100",
                        color = categoryColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = report.threatDescription,
                color = RubyTextMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            if (report.dangerousPermissions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    report.dangerousPermissions.take(3).forEach { perm ->
                        val cleanPerm = perm.substringAfterLast(".")
                        Surface(
                            color = RubySurfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "⚠️ $cleanPerm",
                                color = Color.White,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", report.packageName, null)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Fallback
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "App Details", fontSize = 11.sp, color = Color.White)
                }

                Button(
                    onClick = { onBlockData(report.packageName) },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (report.isBlocked) Color(0xFF00E676) else categoryColor
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (report.isBlocked) "Data Blocked ✓" else "Block GB Data",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
fun DataThiefBlockSection(
    threats: List<AppSecurityReport>,
    blockedPackages: Set<String>,
    onToggleBlock: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = RubySurface),
            border = BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.DataSaverOn,
                    contentDescription = "Data Guard",
                    tint = Color(0xFFFFD54F),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Data Chor & GB Drainer Shield",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Automatically blocks suspicious background apps stealing your internet data & battery.",
                        color = RubyTextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (threats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No heavy background data thief apps detected.",
                    color = RubyTextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(threats, key = { it.packageName }) { app ->
                    val isBlocked = blockedPackages.contains(app.packageName)

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RubySurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Data Consumed: ${app.dataUsageMB.toInt()} MB",
                                    color = Color(0xFFFFD54F),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Switch(
                                checked = isBlocked,
                                onCheckedChange = { onToggleBlock(app.packageName) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = Color(0xFF00E676),
                                    uncheckedThumbColor = RubyTextMuted,
                                    uncheckedTrackColor = RubySurfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AntiHackerShieldSection(
    overview: com.example.util.SystemSecurityOverview,
    context: android.content.Context
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            ShieldStatusCard(
                title = "Root & System Tamper Defense",
                subtitle = if (overview.isRootDetected) "WARNING: Device Rooted! Vulnerable to deep hacks." else "Protected: System binaries uncompromised.",
                isSecure = !overview.isRootDetected,
                icon = Icons.Default.AdminPanelSettings
            )
        }

        item {
            ShieldStatusCard(
                title = "ADB Debugging & Hook Monitor",
                subtitle = if (overview.isAdbDebuggingActive) "WARNING: USB/ADB Debugging Enabled." else "Protected: No remote ADB debug access.",
                isSecure = !overview.isAdbDebuggingActive,
                icon = Icons.Default.DeveloperMode
            )
        }

        item {
            ShieldStatusCard(
                title = "Sideload & Unknown Source Shield",
                subtitle = if (overview.isUnknownSourcesAllowed) "Caution: Installing from Unknown Sources permitted." else "Protected: Only trusted installation sources.",
                isSecure = !overview.isUnknownSourcesAllowed,
                icon = Icons.Default.InstallMobile
            )
        }

        item {
            ShieldStatusCard(
                title = "Camera & Mic Intrusion Protection",
                subtitle = "Active: Real-time C++ background monitor listening for secret spyware access.",
                isSecure = true,
                icon = Icons.Default.Videocam
            )
        }

        item {
            ShieldStatusCard(
                title = "Anti-Phishing & SMS Trojan Scanner",
                subtitle = "Active: Automatic clipboard & message link threat filtering.",
                isSecure = true,
                icon = Icons.Default.Link
            )
        }
    }
}

@Composable
fun ShieldStatusCard(
    title: String,
    subtitle: String,
    isSecure: Boolean,
    imageVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Security
) {
    val statusColor = if (isSecure) Color(0xFF00E676) else Color(0xFFFF1744)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = RubySurface),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(statusColor.copy(alpha = 0.15f), CircleShape)
                    .border(1.dp, statusColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = statusColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = RubyTextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Icon(
                imageVector = if (isSecure) Icons.Default.CheckCircle else Icons.Default.Error,
                contentDescription = "Status",
                tint = statusColor,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
