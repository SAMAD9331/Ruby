package com.example.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.nativecore.RubyNativeCore
import com.example.util.ElevenLabsTtsEngine
import com.example.util.RubyMusicianEngine
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ruby 18yo Live 3D Filament VTuber Character Avatar.
 * 
 * Includes:
 * - Google Filament 3D Real-Time Character Model Engine
 * - 100% Transparent WindowManager Overlay & Canvas Background
 * - Real-Time Lip-Sync synced with ElevenLabs / Local TTS audio amplitude
 * - C++ NDK 60 FPS Skeletal Breathing, Hair Physics, Eye Blinking
 * - Interactive Motion Response: Touch drag 3D rotation & positioning
 */

enum class RubyMood {
    CALM_IDLE,
    THINKING,
    SPEAKING,
    LISTENING,
    PLAYFUL,
    EXCITED,
    SHY
}

@Composable
fun RubyDigitalPet(
    isThinking: Boolean,
    isSpeaking: Boolean,
    isListening: Boolean,
    aiMoodOverride: String? = null,
    isMusician: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    // --- 1. State & Mood Management ---
    var currentMood by remember { mutableStateOf(RubyMood.CALM_IDLE) }
    var touchReactionTrigger by remember { mutableIntStateOf(0) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }

    val audioAmplitude = ElevenLabsTtsEngine.currentAudioAmplitude.floatValue

    val isMusicianMode = isMusician ||
            aiMoodOverride?.contains("musician", ignoreCase = true) == true ||
            aiMoodOverride?.contains("guitar", ignoreCase = true) == true ||
            aiMoodOverride?.contains("music", ignoreCase = true) == true ||
            RubyMusicianEngine.isCurrentlyPlayingMusic()

    LaunchedEffect(isThinking, isSpeaking, isListening, aiMoodOverride, touchReactionTrigger) {
        if (touchReactionTrigger > 0) {
            currentMood = if (touchReactionTrigger % 2 == 0) RubyMood.PLAYFUL else RubyMood.SHY
            delay(1800)
        }

        currentMood = when {
            aiMoodOverride?.contains("playful", ignoreCase = true) == true -> RubyMood.PLAYFUL
            aiMoodOverride?.contains("excited", ignoreCase = true) == true -> RubyMood.EXCITED
            aiMoodOverride?.contains("shy", ignoreCase = true) == true -> RubyMood.SHY
            isSpeaking -> RubyMood.SPEAKING
            isThinking -> RubyMood.THINKING
            isListening -> RubyMood.LISTENING
            else -> RubyMood.CALM_IDLE
        }
    }

    // --- 2. Live 3D VTuber Animations & Physics (C++ NDK Math Engine) ---
    val infiniteTransition = rememberInfiniteTransition(label = "RubyFilament3DSystem")

    // Running seconds clock for C++ physics calculations
    val currentTimeSec by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 3600f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "CurrentTimeSec"
    )

    // Calculate NDK 3D VTuber Inertia values: [breathDisplacementY, hipSwayX, shoulderPitchZ, hairInertiaX]
    val vtuberInertia = remember(currentTimeSec) {
        RubyNativeCore.computeVTuber3DInertia(0.016f, currentTimeSec)
    }

    // Calculate NDK 3D Lip-Sync morph targets: [mouthOpen, jawTranslation, lipStretch, eyeBlink]
    val morphTargets = remember(audioAmplitude, currentTimeSec, isSpeaking) {
        val effectiveAmp = if (isSpeaking) (if (audioAmplitude > 0.05f) audioAmplitude else 0.45f) else 0f
        RubyNativeCore.calculate3DMorphTargets(effectiveAmp, currentTimeSec)
    }

    // Orbit Particle Angle for 3D Holographic Stage Ring
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbitAngle"
    )

    // Smooth Touch Drag Tilt Spring
    val animatedDragX by animateFloatAsState(
        targetValue = dragX,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
        label = "DragX"
    )
    val animatedDragY by animateFloatAsState(
        targetValue = dragY,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
        label = "DragY"
    )

    val touchScale by animateFloatAsState(
        targetValue = if (touchReactionTrigger > 0) 1.10f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "TouchScale"
    )

    // Auto-reset touch drag
    LaunchedEffect(dragX, dragY) {
        if (dragX != 0f || dragY != 0f) {
            delay(1000)
            dragX = 0f
            dragY = 0f
        }
    }

    // Select realistic fallback artwork asset if needed
    val currentImageRes = when {
        isMusicianMode -> R.drawable.img_ruby_guitar
        isSpeaking || isListening -> R.drawable.img_ruby_talking
        else -> R.drawable.img_ruby_idle
    }

    // --- 3. UI Render (100% Transparent Filament 3D Canvas) ---
    Box(
        modifier = modifier
            .graphicsLayer {
                translationY = vtuberInertia[0] * 120f
                rotationY = (animatedDragX / 10f).coerceIn(-25f, 25f)
                rotationX = -(animatedDragY / 10f).coerceIn(-20f, 20f)
                cameraDistance = 16f * density
                scaleX = touchScale * (1f + morphTargets[0] * 0.04f)
                scaleY = touchScale * (1f + morphTargets[0] * 0.04f)
            }
            .pointerInput(Unit) {
                detectTapGestures {
                    touchReactionTrigger++
                    onClick?.invoke()
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragX += dragAmount.x
                        dragY += dragAmount.y
                    },
                    onDragEnd = {
                        dragX = 0f
                        dragY = 0f
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // --- Layer 1: 3D Holographic Particle Aura Canvas ---
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)
            val radius = minOf(w, h) / 2f

            val auraColor = when {
                isMusicianMode -> Color(0xFFFF2E93)
                isSpeaking -> Color(0xFFFF1744)
                isListening -> Color(0xFF00E676)
                isThinking -> Color(0xFF00E5FF)
                else -> Color(0xFFFF4081)
            }

            // Radial Deep Holographic Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        auraColor.copy(alpha = 0.40f),
                        auraColor.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 1.30f
                ),
                center = center,
                radius = radius * 1.30f
            )

            // Live Audio Wave Lip-Sync Pulse Ring
            if (isSpeaking || isMusicianMode) {
                val waveCount = 28
                val wavePath = Path()
                val baseR = radius * 1.02f
                for (i in 0..waveCount) {
                    val angle = (i * (360f / waveCount)) * (Math.PI / 180f)
                    val rMod = if (i % 2 == 0) morphTargets[0] * 35f else 0f
                    val r = baseR + rMod
                    val px = center.x + r * cos(angle).toFloat()
                    val py = center.y + r * sin(angle).toFloat()
                    if (i == 0) wavePath.moveTo(px, py) else wavePath.lineTo(px, py)
                }
                wavePath.close()

                drawPath(
                    path = wavePath,
                    color = auraColor.copy(alpha = 0.85f),
                    style = Stroke(width = 3.5f)
                )
            }

            // Orbiting 3D Energy Sparkles
            val particleCount = 8
            val orbitRadius = radius * 0.95f
            for (i in 0 until particleCount) {
                val angleRad = Math.toRadians((orbitAngle + i * (360f / particleCount)).toDouble())
                val px = center.x + orbitRadius * cos(angleRad).toFloat()
                val py = center.y + orbitRadius * sin(angleRad).toFloat() * 0.65f

                val pColor = when (i % 3) {
                    0 -> Color(0xFFFFD54F)
                    1 -> Color(0xFF00E5FF)
                    else -> Color(0xFFFF2E93)
                }

                drawCircle(
                    color = pColor,
                    center = Offset(px, py),
                    radius = 3.8f
                )
            }
        }

        // --- Layer 2: Filament 3D Character View ---
        Box(
            modifier = Modifier
                .fillMaxSize(0.90f)
                .shadow(20.dp, CircleShape, spotColor = Color(0xFFFF1744))
                .border(
                    width = if (isMusicianMode || isSpeaking) 3.5.dp else 2.5.dp,
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color(0xFFFF2E93),
                            Color(0xFFFFD54F),
                            Color(0xFF00E5FF),
                            Color(0xFFFF2E93)
                        )
                    ),
                    shape = CircleShape
                )
                .clip(CircleShape)
                .background(Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Ruby3DCharacterView(
                audioAmplitude = morphTargets[0],
                isSpeaking = isSpeaking,
                isListening = isListening,
                isMusicianMode = isMusicianMode,
                modifier = Modifier.fillMaxSize(),
                onTouchDrag = { dx, dy ->
                    dragX += dx
                    dragY += dy
                }
            )
        }

        // --- Layer 3: Interactive VTuber Badge at Bottom ---
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 6.dp)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFF1F0A2A), Color(0xFF3B123C))
                    ),
                    shape = CircleShape
                )
                .border(1.dp, Color(0xFFFF2E93).copy(alpha = 0.85f), CircleShape)
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            val badgeText = when {
                isMusicianMode -> "🎸 3D Guitarist Ruby"
                isSpeaking -> "🎙️ 3D Lip-Syncing..."
                isListening -> "👂 Listening..."
                isThinking -> "💭 3D Engine Thinking..."
                touchReactionTrigger > 0 -> "💖 Hehe~ 3D Touch"
                else -> "✨ Ruby 3D VTuber"
            }
            Text(
                text = badgeText,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
