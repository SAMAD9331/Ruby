package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.util.AddonItem
import com.example.util.RubyAddonManager

/**
 * MCPE-Style Dynamic Addon & Feature Importer Panel Dialog.
 * 
 * Features:
 * 1. Displays installed code modules & feature packs in a clean MCPE-style list.
 * 2. Active/Inactive toggle switches to enable/disable feature scripts instantly.
 * 3. File picker button to import new .js, .json, .zip, or .mcaddon code packs.
 * 4. Clean deletion of custom code modules.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddonManagerDialog(
    onDismiss: () -> Unit,
    onAddonStateChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    var addonList by remember { mutableStateOf(RubyAddonManager.getAvailableAddons(context)) }
    var showGuideDialog by remember { mutableStateOf(false) }

    // SAF Picker for importing script / zip / mcaddon files
    val addonFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val success = RubyAddonManager.importAddon(context, uri)
            if (success) {
                addonList = RubyAddonManager.getAvailableAddons(context)
                onAddonStateChanged()
                Toast.makeText(context, "MCPE Addon Pack imported successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Failed to import addon file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (showGuideDialog) {
        AddonGuideDialog(onDismiss = { showGuideDialog = false })
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color(0xFF4CAF50).copy(alpha = 0.6f), RoundedCornerShape(24.dp)),
            color = RubyBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFF2E7D32), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MCPE Addon & Feature Importer",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Dynamic Feature Packs & Code Modules",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showGuideDialog = true },
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color(0xFF1B5E20), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.HelpOutline,
                                contentDescription = "How to Use Guide",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.LightGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Import Addon Banner Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Installed Addons (${addonList.count { it.isActive }}/${addonList.size} Active)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Button(
                        onClick = { addonFilePicker.launch("*/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Import Pack", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // List of Addons
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(addonList, key = { it.id }) { item ->
                        AddonItemCard(
                            item = item,
                            onToggleActive = { isActive ->
                                RubyAddonManager.setAddonActive(context, item.id, isActive)
                                addonList = RubyAddonManager.getAvailableAddons(context)
                                onAddonStateChanged()
                            },
                            onDelete = {
                                RubyAddonManager.deleteAddon(context, item.id)
                                addonList = RubyAddonManager.getAvailableAddons(context)
                                onAddonStateChanged()
                                Toast.makeText(context, "Removed addon pack: ${item.name}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = RubySurfaceVariant),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Done", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddonItemCard(
    item: AddonItem,
    onToggleActive: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (item.isActive) 1.5.dp else 1.dp,
                color = if (item.isActive) Color(0xFF4CAF50) else Color(0xFF333344),
                shape = RoundedCornerShape(14.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isActive) Color(0xFF1B2E1C) else RubySurface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            if (item.isActive) Color(0xFF2E7D32) else Color(0xFF333348),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (item.isPrebundled) Icons.Default.Code else Icons.Default.Extension,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.name,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFF37474F),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "v${item.version}",
                                color = Color.LightGray,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = item.description,
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 2
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = item.isActive,
                    onCheckedChange = onToggleActive,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF4CAF50),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color(0xFF263238)
                    )
                )

                if (!item.isPrebundled) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Addon",
                            tint = Color(0xFFE53935),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * MCPE Addon Creation & Usage Guide Dialog.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddonGuideDialog(
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color(0xFF2E7D32), RoundedCornerShape(24.dp)),
            color = RubyBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF2E7D32), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HelpOutline,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Addon Creation & Usage Guide",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "MCPE-Style Feature Packs for Ruby AI",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Guide",
                            tint = Color.LightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Guide Content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        GuideSectionCard(
                            icon = Icons.Default.InsertDriveFile,
                            title = "1. Supported File Formats",
                            content = "You can import feature packs in .zip, .js, .json, or .mcaddon formats.\n" +
                                    "• Single Scripts: Import standalone .js or .json code files directly.\n" +
                                    "• Pack Archives: Import compressed .zip or .mcaddon archives containing scripts and resources."
                        )
                    }

                    item {
                        GuideSectionCard(
                            icon = Icons.Default.IntegrationInstructions,
                            title = "2. Manifest Requirement (ZIP / MCADDON)",
                            content = "For .zip or .mcaddon feature packs, include a manifest.json file at the root level defining the pack metadata:\n\n" +
                                    "{\n" +
                                    "  \"id\": \"custom_gamer_pack\",\n" +
                                    "  \"name\": \"Custom Stream Pack\",\n" +
                                    "  \"version\": \"1.0.0\",\n" +
                                    "  \"description\": \"Adds custom stream overlay alerts and gamer reactions.\",\n" +
                                    "  \"script_entry\": \"main.js\"\n" +
                                    "}"
                        )
                    }

                    item {
                        GuideSectionCard(
                            icon = Icons.Default.Psychology,
                            title = "3. Script Logic & Runtime Execution",
                            content = "The JavaScript or JSON code in active addons is dynamically loaded into Ruby's execution context:\n" +
                                    "• Prompt Injections: Inject specialized personality rules, system prompts, or response formatting.\n" +
                                    "• Extended Capabilities: Add custom tool calls, gamer overlay reactions, and automated scripts."
                        )
                    }

                    item {
                        GuideSectionCard(
                            icon = Icons.Default.ToggleOn,
                            title = "4. Real-time Active/Inactive Switch",
                            content = "Toggle any addon ON or OFF using the switch in the Addon Manager.\n" +
                                    "• Enable or disable packs instantly without restarting the app.\n" +
                                    "• Ruby will automatically load and apply active modules on her next prompt execution!"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Got it, Boss!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun GuideSectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    content: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RubySurface),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333348))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF81C784), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = content,
                color = Color.LightGray,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )
        }
    }
}

