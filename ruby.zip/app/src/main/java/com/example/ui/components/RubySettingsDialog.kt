package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.screens.AddonGuideDialog
import com.example.ui.theme.*
import com.example.util.AddonItem
import com.example.util.ModelItem
import com.example.util.RubyAddonManager
import com.example.util.RubySettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Unified Settings & Customization Panel Dialog for Ruby AI.
 * 
 * Features:
 * 1. Skin & 3D Model Manager (Gallery & Active Switcher & Deleter).
 * 2. Dynamic API Keys & ElevenLabs TTS Voice Management.
 * 3. Live "Test Credentials" Connectivity Verification.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RubySettingsDialog(
    onDismiss: () -> Unit,
    onModelChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTabIndex by remember { mutableIntStateOf(0) }

    // API Key State
    var geminiApiKey by remember { mutableStateOf(RubySettingsManager.getGeminiApiKey(context)) }
    var elevenLabsApiKey by remember { mutableStateOf(RubySettingsManager.getElevenLabsApiKey(context)) }
    var elevenLabsVoiceId by remember { mutableStateOf(RubySettingsManager.getElevenLabsVoiceId(context)) }

    var isGeminiKeyVisible by remember { mutableStateOf(false) }
    var isElevenLabsKeyVisible by remember { mutableStateOf(false) }

    // Test API Status
    var isTestingApi by remember { mutableStateOf(false) }
    var testResultStatus by remember { mutableStateOf<String?>(null) }
    var testResultSuccess by remember { mutableStateOf(false) }

    // Model Gallery State
    var modelList by remember { mutableStateOf(RubySettingsManager.getAvailableModels(context)) }

    // SAF File picker launcher for .glb models
    val glbPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val success = RubySettingsManager.importModel(context, uri)
            if (success) {
                modelList = RubySettingsManager.getAvailableModels(context)
                onModelChanged()
                Toast.makeText(context, "3D Model Skin imported & equipped!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Failed to import model skin file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color(0xFFE91E63).copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
            color = RubyBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Header Title Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RubyRed, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Ruby AI Settings",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "3D Skins & Dynamic API Credentials",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.LightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Navigation Tab Row
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = RubySurface,
                    contentColor = RubyRed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("3D Skin Gallery", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("API & Voice", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Extension, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MCPE Addons", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content view based on selected tab
                when (selectedTabIndex) {
                    0 -> {
                        // TAB 0: 3D Skin Gallery & Switcher
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "3D VTuber Avatar Skins",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Button(
                                    onClick = { glbPickerLauncher.launch("*/*") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7B1FA2)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Import .glb", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(modelList, key = { it.fileName }) { item ->
                                    SkinModelCard(
                                        item = item,
                                        onSelect = {
                                            RubySettingsManager.setActiveModel(context, item.fileName)
                                            modelList = RubySettingsManager.getAvailableModels(context)
                                            onModelChanged()
                                            Toast.makeText(context, "Equipped skin: ${item.name}", Toast.LENGTH_SHORT).show()
                                        },
                                        onDelete = {
                                            RubySettingsManager.deleteModel(context, item.fileName)
                                            modelList = RubySettingsManager.getAvailableModels(context)
                                            onModelChanged()
                                            Toast.makeText(context, "Deleted skin: ${item.name}", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // TAB 1: API Keys & TTS Voice Configuration
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Dynamic API Credentials & TTS Voice",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // 1. Gemini AI API Key Input
                            OutlinedTextField(
                                value = geminiApiKey,
                                onValueChange = { geminiApiKey = it },
                                label = { Text("Gemini AI API Key", color = Color.LightGray) },
                                placeholder = { Text("Enter custom Gemini API key...", color = Color.Gray) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RubyRed,
                                    unfocusedBorderColor = Color(0xFF444455),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                visualTransformation = if (isGeminiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                trailingIcon = {
                                    IconButton(onClick = { isGeminiKeyVisible = !isGeminiKeyVisible }) {
                                        Icon(
                                            imageVector = if (isGeminiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = Color.Gray
                                        )
                                    }
                                }
                            )

                            // 2. ElevenLabs API Key Input
                            OutlinedTextField(
                                value = elevenLabsApiKey,
                                onValueChange = { elevenLabsApiKey = it },
                                label = { Text("ElevenLabs TTS API Key", color = Color.LightGray) },
                                placeholder = { Text("Enter ElevenLabs xi-api-key...", color = Color.Gray) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RubyRed,
                                    unfocusedBorderColor = Color(0xFF444455),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                visualTransformation = if (isElevenLabsKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                trailingIcon = {
                                    IconButton(onClick = { isElevenLabsKeyVisible = !isElevenLabsKeyVisible }) {
                                        Icon(
                                            imageVector = if (isElevenLabsKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = Color.Gray
                                        )
                                    }
                                }
                            )

                            // 3. ElevenLabs Voice ID Input
                            OutlinedTextField(
                                value = elevenLabsVoiceId,
                                onValueChange = { elevenLabsVoiceId = it },
                                label = { Text("ElevenLabs Voice ID", color = Color.LightGray) },
                                placeholder = { Text("e.g. EXAVITQu4vr4xnSDxMaL (Bella)", color = Color.Gray) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RubyRed,
                                    unfocusedBorderColor = Color(0xFF444455),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            // Test Credentials Status Banner
                            testResultStatus?.let { status ->
                                Surface(
                                    color = if (testResultSuccess) Color(0xFF1B5E20) else Color(0xFFB71C1C),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (testResultSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = status, color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }

                            // Test Credentials Action Button
                            OutlinedButton(
                                onClick = {
                                    isTestingApi = true
                                    testResultStatus = null
                                    coroutineScope.launch(Dispatchers.IO) {
                                        val result = testApiCredentials(geminiApiKey, elevenLabsApiKey)
                                        withContext(Dispatchers.Main) {
                                            isTestingApi = false
                                            testResultStatus = result.second
                                            testResultSuccess = result.first
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isTestingApi,
                                shape = RoundedCornerShape(10.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(RubyRed))
                            ) {
                                if (isTestingApi) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = RubyRed, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Testing Credentials...", color = Color.White, fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp), tint = RubyRed)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Test Credentials Connectivity", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    2 -> {
                        // TAB 2: MCPE Addon & Feature Importer Panel
                        var addonList by remember { mutableStateOf(RubyAddonManager.getAvailableAddons(context)) }
                        var showGuideDialog by remember { mutableStateOf(false) }

                        val addonFilePicker = rememberLauncherForActivityResult(
                            contract = ActivityResultContracts.GetContent()
                        ) { uri: Uri? ->
                            if (uri != null) {
                                val success = RubyAddonManager.importAddon(context, uri)
                                if (success) {
                                    addonList = RubyAddonManager.getAvailableAddons(context)
                                    Toast.makeText(context, "MCPE Addon Pack imported!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Failed to import addon file.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }

                        if (showGuideDialog) {
                            AddonGuideDialog(onDismiss = { showGuideDialog = false })
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "MCPE Addons & Modules",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { showGuideDialog = true },
                                        modifier = Modifier
                                            .size(26.dp)
                                            .background(Color(0xFF1B5E20), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.HelpOutline,
                                            contentDescription = "Addon Guide",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Button(
                                    onClick = { addonFilePicker.launch("*/*") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Import Pack", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(addonList, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(
                                                width = if (item.isActive) 1.5.dp else 1.dp,
                                                color = if (item.isActive) Color(0xFF4CAF50) else Color(0xFF333344),
                                                shape = RoundedCornerShape(14.dp)
                                            ),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (item.isActive) Color(0xFF1B2E1C) else RubySurface
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .background(
                                                            if (item.isActive) Color(0xFF2E7D32) else Color(0xFF333348),
                                                            CircleShape
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (item.isPrebundled) Icons.Default.Code else Icons.Default.Extension,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }

                                                Spacer(modifier = Modifier.width(10.dp))

                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = item.name,
                                                            color = Color.White,
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = Color(0xFF37474F),
                                                            shape = RoundedCornerShape(6.dp)
                                                        ) {
                                                            Text(
                                                                text = "v${item.version}",
                                                                color = Color.LightGray,
                                                                fontSize = 9.sp,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(2.dp))

                                                    Text(
                                                        text = item.description,
                                                        color = Color.Gray,
                                                        fontSize = 11.sp,
                                                        maxLines = 2
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Switch(
                                                    checked = item.isActive,
                                                    onCheckedChange = { isActive ->
                                                        RubyAddonManager.setAddonActive(context, item.id, isActive)
                                                        addonList = RubyAddonManager.getAvailableAddons(context)
                                                    },
                                                    colors = SwitchDefaults.colors(
                                                        checkedThumbColor = Color.White,
                                                        checkedTrackColor = Color(0xFF4CAF50),
                                                        uncheckedThumbColor = Color.Gray,
                                                        uncheckedTrackColor = Color(0xFF263238)
                                                    )
                                                )

                                                if (!item.isPrebundled) {
                                                    IconButton(onClick = {
                                                        RubyAddonManager.deleteAddon(context, item.id)
                                                        addonList = RubyAddonManager.getAvailableAddons(context)
                                                        Toast.makeText(context, "Deleted addon pack: ${item.name}", Toast.LENGTH_SHORT).show()
                                                    }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Delete,
                                                            contentDescription = "Delete Addon",
                                                            tint = Color(0xFFE53935),
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Save & Apply Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.LightGray)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            RubySettingsManager.saveGeminiApiKey(context, geminiApiKey)
                            RubySettingsManager.saveElevenLabsApiKey(context, elevenLabsApiKey)
                            RubySettingsManager.saveElevenLabsVoiceId(context, elevenLabsVoiceId)
                            Toast.makeText(context, "Settings & API credentials saved!", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RubyRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save & Apply", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SkinModelCard(
    item: ModelItem,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (item.isActive) 2.dp else 1.dp,
                color = if (item.isActive) RubyRed else Color(0xFF333344),
                shape = RoundedCornerShape(14.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isActive) Color(0xFF2C1924) else RubySurface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (item.isActive) RubyRed else Color(0xFF333348),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (item.isDefaultAsset) Icons.Default.Face else Icons.Default.ViewInAr,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (item.isActive) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = RubyRed,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Equipped",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = if (item.isDefaultAsset) "Bundled Asset Model" else "${item.sizeBytes / 1024} KB • GLB Model",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!item.isActive) {
                    Button(
                        onClick = onSelect,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Equip", fontSize = 11.sp)
                    }
                }

                if (!item.isDefaultAsset) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Model",
                            tint = Color(0xFFE53935),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tests Gemini and ElevenLabs API credentials connectivity.
 */
private suspend fun testApiCredentials(geminiKey: String, elevenLabsKey: String): Pair<Boolean, String> {
    val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    var geminiOk = false
    var elevenLabsOk = false
    val statusMsgs = mutableListOf<String>()

    // 1. Test Gemini API
    if (geminiKey.isNotBlank()) {
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$geminiKey"
            val req = Request.Builder().url(url).build()
            val resp = client.newCall(req).execute()
            if (resp.isSuccessful) {
                geminiOk = true
                statusMsgs.add("Gemini: Valid ✅")
            } else {
                statusMsgs.add("Gemini: Error HTTP ${resp.code} ❌")
            }
        } catch (e: Exception) {
            statusMsgs.add("Gemini: Failed (${e.message}) ❌")
        }
    } else {
        statusMsgs.add("Gemini: No key set (Fallback active)")
    }

    // 2. Test ElevenLabs API
    if (elevenLabsKey.isNotBlank()) {
        try {
            val url = "https://api.elevenlabs.io/v1/user"
            val req = Request.Builder()
                .url(url)
                .addHeader("xi-api-key", elevenLabsKey)
                .build()
            val resp = client.newCall(req).execute()
            if (resp.isSuccessful) {
                elevenLabsOk = true
                statusMsgs.add("ElevenLabs: Valid ✅")
            } else {
                statusMsgs.add("ElevenLabs: Error HTTP ${resp.code} ❌")
            }
        } catch (e: Exception) {
            statusMsgs.add("ElevenLabs: Failed (${e.message}) ❌")
        }
    } else {
        statusMsgs.add("ElevenLabs: No key set (Local TTS active)")
    }

    val overallSuccess = (geminiKey.isBlank() || geminiOk) && (elevenLabsKey.isBlank() || elevenLabsOk)
    return Pair(overallSuccess, statusMsgs.joinToString(" | "))
}
