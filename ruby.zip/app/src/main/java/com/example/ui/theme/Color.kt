package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Main brand colors for Sleek Interface
val RubyRed = Color(0xFF6750A4)         // Sleek primary brand purple
val RubyOrange = Color(0xFFEADDFF)      // Sleek secondary light purple container
val RubyAccent = Color(0xFFFFD8E4)      // YouTuber highlight rose pink

val RubyBg = Color(0xFFFDF7FF)          // Light lilac-white background
val RubySurface = Color(0xFFFFFFFF)     // High contrast pure white surfaces
val RubySurfaceVariant = Color(0xFFF3EDF7) // Soft lilac-gray container / borders

val RubyText = Color(0xFF1D1B20)        // Deep rich charcoal text
val RubyTextMuted = Color(0xFF49454F)   // Soft Slate dark secondary text

// Additional specific colors for active items or warning/gemstones
val SleekGemStart = Color(0xFFFF4D4D)
val SleekGemEnd = Color(0xFF8B0000)
val SleekActiveGreen = Color(0xFF2E7D32)


