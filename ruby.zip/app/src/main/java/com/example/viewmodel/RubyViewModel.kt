package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.RubyRepository
import com.example.nativecore.RubyNativeCore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import java.util.regex.Pattern

enum class LaunchTargetType {
    PHOTO_EDITOR, VIDEO_EDITOR, CAMERA, GALLERY, CAPCUT, KINEMASTER, PICSART, LIGHTROOM, INSHOT,
    YOUTUBE, WHATSAPP, INSTAGRAM, FACEBOOK, CHROME, SETTINGS, CALCULATOR, SPOTIFY, TELEGRAM, PLAYSTORE, GMAIL, GENERIC_APP
}

data class LaunchIntentEvent(
    val target: LaunchTargetType,
    val label: String,
    val packageName: String? = null,
    val searchKeyword: String? = null
)

class RubyViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val database = AppDatabase.getDatabase(application)
    private val repository = RubyRepository(database.rubyDao())

    // UI States
    val messages: StateFlow<List<ChatMessage>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<GeneratedProject>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memoryLogs: StateFlow<List<MemoryLog>> = repository.allMemoryLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val youtubeDrafts: StateFlow<List<YouTubeDraft>> = repository.allYouTubeDrafts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userMemories: StateFlow<List<UserMemory>> = repository.allUserMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // State holding for Active Project Workspace
    private val _selectedProjectId = MutableStateFlow<Int?>(null)
    val selectedProjectId: StateFlow<Int?> = _selectedProjectId.asStateFlow()

    val selectedProjectFiles: StateFlow<List<ProjectFile>> = _selectedProjectId
        .flatMapLatest { id ->
            if (id != null) repository.getFilesForProject(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Ruby's Reactive Pet Expressions
    private val _isRubyThinking = MutableStateFlow(false)
    val isRubyThinking: StateFlow<Boolean> = _isRubyThinking.asStateFlow()

    private val _isRubySpeaking = MutableStateFlow(false)
    val isRubySpeaking: StateFlow<Boolean> = _isRubySpeaking.asStateFlow()

    private val _isRubyListening = MutableStateFlow(false)
    val isRubyListening: StateFlow<Boolean> = _isRubyListening.asStateFlow()

    private val _isMusicianMode = MutableStateFlow(false)
    val isMusicianMode: StateFlow<Boolean> = _isMusicianMode.asStateFlow()

    private var lastGeneratedSongTitle = "Ruby_Special_Melody"
    private var lastGeneratedLyrics = "Ruby is playing guitar for Boss..."

    private val _currentStatusText = MutableStateFlow("Ruby is ready, Boss!")
    val currentStatusText: StateFlow<String> = _currentStatusText.asStateFlow()

    // Live Voice Call Mode States
    private val _isVoiceCallActive = MutableStateFlow(false)
    val isVoiceCallActive: StateFlow<Boolean> = _isVoiceCallActive.asStateFlow()

    private val _isCallMuted = MutableStateFlow(false)
    val isCallMuted: StateFlow<Boolean> = _isCallMuted.asStateFlow()

    private val _isCallSpeakerOn = MutableStateFlow(true)
    val isCallSpeakerOn: StateFlow<Boolean> = _isCallSpeakerOn.asStateFlow()

    private val _callDurationSeconds = MutableStateFlow(0)
    val callDurationSeconds: StateFlow<Int> = _callDurationSeconds.asStateFlow()

    private var callTimerJob: kotlinx.coroutines.Job? = null

    // App Launch Event for Photo & Video Editing & System Apps
    private val _launchEvent = MutableStateFlow<LaunchIntentEvent?>(null)
    val launchEvent: StateFlow<LaunchIntentEvent?> = _launchEvent.asStateFlow()

    fun clearLaunchEvent() {
        _launchEvent.value = null
    }

    fun triggerAppLaunch(
        target: LaunchTargetType,
        label: String,
        packageName: String? = null,
        searchKeyword: String? = null
    ) {
        _launchEvent.value = LaunchIntentEvent(target, label, packageName, searchKeyword)
        speakSpeechSafe("Ji Boss! $label open kar rahi hu.")
    }

    // TextToSpeech Engine
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    init {
        tts = TextToSpeech(application, this)
        // Log initialization memory & Native Core Engine version
        viewModelScope.launch {
            val nativeVer = RubyNativeCore.getEngineVersionSafe()
            repository.logMemory("Ruby System & $nativeVer initialized successfully.", "SYSTEM", "COMPLETED")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN")) // Support Hindi/Hinglish pronunciation
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }

            // Select cute realistic female voice if available from TTS engine
            try {
                val availableVoices = tts?.voices
                val cuteFemaleVoice = availableVoices?.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    (name.contains("female") || name.contains("woman") || name.contains("girl") || name.contains("hi-in") || name.contains("en-in"))
                } ?: availableVoices?.firstOrNull { voice ->
                    voice.name.lowercase().contains("female") || voice.name.lowercase().contains("f0")
                }

                if (cuteFemaleVoice != null) {
                    tts?.voice = cuteFemaleVoice
                }
            } catch (e: Exception) {
                Log.e("RubyTTS", "Voice selection exception: ${e.message}")
            }

            // Fine-tune pitch and speech rate for a cute, clear realistic female voice
            tts?.setPitch(1.35f) // Higher pitch for cute anime girl tone
            tts?.setSpeechRate(1.05f) // Lively, natural speech rate

            isTtsReady = true
            speakSpeechSafe("Hello Boss! Ruby ki cute girl voice active ho gayi hai! Ab hum floating overlay screen par live baat kar sakte hain!")
        } else {
            Log.e("RubyTTS", "Initialization failed")
        }
    }

    fun setListeningState(isListening: Boolean) {
        _isRubyListening.value = isListening
        if (isListening) {
            _currentStatusText.value = "Listening to you, Boss..."
        } else {
            _currentStatusText.value = "Ruby is thinking..."
        }
    }

    // Voice Call Mode Actions
    fun startVoiceCall() {
        _isVoiceCallActive.value = true
        _callDurationSeconds.value = 0
        _isCallMuted.value = false
        _isCallSpeakerOn.value = true
        _currentStatusText.value = "Voice call active with Ruby"
        
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (_isVoiceCallActive.value) {
                kotlinx.coroutines.delay(1000)
                _callDurationSeconds.value += 1
            }
        }
        
        speakSpeechSafe("Hello Boss! Ruby live voice call active ho gaya hai. Aap mujh se baat kar sakte hain!")
    }

    fun endVoiceCall() {
        _isVoiceCallActive.value = false
        callTimerJob?.cancel()
        callTimerJob = null
        _isRubyListening.value = false
        tts?.stop()
        _isRubySpeaking.value = false
        _currentStatusText.value = "Call ended, Boss"
        speakSpeechSafe("Call disconnected, Boss.")
    }

    fun toggleCallMute() {
        _isCallMuted.value = !_isCallMuted.value
    }

    fun toggleCallSpeaker() {
        _isCallSpeakerOn.value = !_isCallSpeakerOn.value
    }

    fun setElevenLabsApiKey(apiKey: String) {
        com.example.util.ElevenLabsTtsEngine.saveApiKey(getApplication(), apiKey)
    }

    fun getElevenLabsApiKey(): String {
        return com.example.util.ElevenLabsTtsEngine.getApiKey(getApplication())
    }

    fun setElevenLabsVoiceId(voiceId: String) {
        com.example.util.ElevenLabsTtsEngine.saveVoiceId(getApplication(), voiceId)
    }

    fun getElevenLabsVoiceId(): String {
        return com.example.util.ElevenLabsTtsEngine.getVoiceId(getApplication())
    }

    fun speakSpeechSafe(text: String) {
        com.example.util.ElevenLabsTtsEngine.speak(
            context = getApplication(),
            text = text,
            tts = tts,
            isTtsReady = isTtsReady,
            onStart = {
                _isRubySpeaking.value = true
            },
            onDone = {
                _isRubySpeaking.value = false
            }
        )
    }

    fun playSongWithGuitar(songTitle: String, lyricsText: String) {
        lastGeneratedSongTitle = songTitle
        lastGeneratedLyrics = lyricsText
        _isMusicianMode.value = true
        _currentStatusText.value = "🎸 Ruby Musician Mode: Playing '$songTitle'..."
        com.example.util.RubyMusicianEngine.playGuitarMelody(12) {
            _isMusicianMode.value = false
        }
    }

    fun saveCurrentSongToRubyFolder() {
        val (txtFile, wavFile) = com.example.util.RubyMusicianEngine.saveSongToRubyFolder(
            getApplication(),
            lastGeneratedSongTitle,
            lastGeneratedLyrics
        )
        val msg = "Boss, '$lastGeneratedSongTitle' Ruby folder me txt aur audio file ke saath successfully save ho gaya hai!"
        speakSpeechSafe(msg)
        _currentStatusText.value = "Saved in Ruby folder: ${txtFile.name}"
    }

    // LTM Manual Methods
    fun saveUserMemory(category: String, key: String, value: String) {
        viewModelScope.launch {
            repository.saveUserMemory(category, key, value)
        }
    }

    fun deleteUserMemory(key: String) {
        viewModelScope.launch {
            repository.deleteUserMemoryByKey(key)
        }
    }

    fun clearUserMemories() {
        viewModelScope.launch {
            repository.clearUserMemories()
        }
    }

    private fun extractAndSaveMemories(userText: String) {
        val lower = userText.lowercase().trim()
        
        // Ignore small talk completely
        val smallTalkList = listOf("hello", "hi", "kaise ho", "kaise h", "kya haal hai", "kya kar rahi ho", "kya kar rhe ho", "good morning", "good night", "bye", "thanks", "thank you", "ok", "ha", "haan")
        if (smallTalkList.any { lower == it || lower.startsWith("$it ") }) return

        viewModelScope.launch(Dispatchers.IO) {
            when {
                // Identity Memory
                lower.contains("mera naam") || lower.contains("my name is") -> {
                    val name = userText.replace(Regex("(?i).*?(mera naam|my name is)\\s*"), "").replace(Regex("(?i)\\s*hai.*"), "").trim()
                    if (name.isNotEmpty()) repository.saveUserMemory("IDENTITY", "User Name", name)
                }
                lower.contains("mera nickname") || lower.contains("call me") -> {
                    val nick = userText.replace(Regex("(?i).*?(mera nickname|call me)\\s*"), "").replace(Regex("(?i)\\s*hai.*"), "").trim()
                    if (nick.isNotEmpty()) repository.saveUserMemory("IDENTITY", "User Nickname", nick)
                }
                lower.contains("meri age") || lower.contains("my age is") || lower.contains("years old") || lower.contains("umar") || lower.contains("saal ka") -> {
                    val age = if (lower.contains("15")) "15 years old" else userText.replace(Regex("(?i).*?(meri age|my age is|umar)\\s*"), "").replace(Regex("(?i)\\s*(hai|ka|saal).*"), "").trim()
                    if (age.isNotEmpty()) repository.saveUserMemory("IDENTITY", "User Age", age)
                }
                
                // Preference Memory
                lower.contains("favorite game") || lower.contains("pasandida game") -> {
                    val game = userText.replace(Regex("(?i).*?(favorite game|pasandida game)\\s*"), "").replace(Regex("(?i)\\s*(hai|is).*"), "").trim()
                    if (game.isNotEmpty()) repository.saveUserMemory("PREFERENCE", "Favorite Games", game)
                }
                lower.contains("favorite creator") || lower.contains("favorite youtuber") -> {
                    val creator = userText.replace(Regex("(?i).*?(favorite creator|favorite youtuber)\\s*"), "").replace(Regex("(?i)\\s*(hai|is).*"), "").trim()
                    if (creator.isNotEmpty()) repository.saveUserMemory("PREFERENCE", "Favorite Creators", creator)
                }
                lower.contains("favorite movie") -> {
                    val movie = userText.replace(Regex("(?i).*?favorite movie\\s*"), "").replace(Regex("(?i)\\s*(hai|is).*"), "").trim()
                    if (movie.isNotEmpty()) repository.saveUserMemory("PREFERENCE", "Favorite Movies", movie)
                }
                lower.contains("favorite music") || lower.contains("favorite song") -> {
                    val music = userText.replace(Regex("(?i).*?(favorite music|favorite song)\\s*"), "").replace(Regex("(?i)\\s*(hai|is).*"), "").trim()
                    if (music.isNotEmpty()) repository.saveUserMemory("PREFERENCE", "Favorite Music", music)
                }

                // Project Memory
                lower.contains("mera project") || lower.contains("my project") || lower.contains("channel ka naam") -> {
                    val proj = userText.replace(Regex("(?i).*?(mera project|my project|channel ka naam)\\s*"), "").replace(Regex("(?i)\\s*(hai|is).*"), "").trim()
                    if (proj.isNotEmpty()) repository.saveUserMemory("PROJECT", "Active Project", proj)
                }

                // Behavioral Memory
                lower.contains("short me answer") || lower.contains("brief response") -> {
                    repository.saveUserMemory("BEHAVIORAL", "Response Style", "Short, direct and friendly")
                }
                lower.contains("technical tone") || lower.contains("code explain karo") -> {
                    repository.saveUserMemory("BEHAVIORAL", "Response Style", "Technical and code-focused")
                }
            }
        }
    }

    private suspend fun handleSystemCommands(userText: String): Boolean {
        val lower = userText.lowercase()
        return when {
            lower.contains("volume badhao") || lower.contains("volume high") || lower.contains("sound badhao") || lower.contains("volume increase") -> {
                com.example.service.RubyAccessibilityService.adjustVolume(getApplication(), true)
                speakSpeechSafe("Volume badha diya hai Boss!")
                true
            }
            lower.contains("volume kam") || lower.contains("volume decrease") || lower.contains("sound kam") || lower.contains("volume low") -> {
                com.example.service.RubyAccessibilityService.adjustVolume(getApplication(), false)
                speakSpeechSafe("Volume kam kar diya hai Boss!")
                true
            }
            lower.contains("torch on") || lower.contains("flashlight on") || lower.contains("torch jalaye") || lower.contains("torch chalu") -> {
                val ok = com.example.service.RubyAccessibilityService.setTorch(getApplication(), true)
                if (ok) speakSpeechSafe("Torch ON kar diya hai, Boss!") else speakSpeechSafe("Torch ON karne me problem aayi, Boss.")
                true
            }
            lower.contains("torch off") || lower.contains("flashlight off") || lower.contains("torch band") -> {
                val ok = com.example.service.RubyAccessibilityService.setTorch(getApplication(), false)
                if (ok) speakSpeechSafe("Torch OFF kar diya hai!") else speakSpeechSafe("Torch OFF karne me problem aayi.")
                true
            }
            lower.contains("video pause") || lower.contains("youtube pause") || lower.contains("pause video") -> {
                com.example.service.RubyAccessibilityService.controlMedia(getApplication(), "pause")
                speakSpeechSafe("YouTube video pause kar diya hai, Boss!")
                true
            }
            lower.contains("video play") || lower.contains("youtube play") || lower.contains("play video") || lower.contains("resume video") -> {
                com.example.service.RubyAccessibilityService.controlMedia(getApplication(), "play")
                speakSpeechSafe("YouTube video play kar diya hai!")
                true
            }
            lower.contains("video skip") || lower.contains("youtube skip") || lower.contains("next video") || lower.contains("skip video") -> {
                com.example.service.RubyAccessibilityService.controlMedia(getApplication(), "skip")
                speakSpeechSafe("Next video skip kar diya hai, Boss!")
                true
            }
            lower.contains("copied text padho") || lower.contains("clipboard padho") || lower.contains("read clipboard") || lower.contains("clipboard text") -> {
                val clipText = com.example.service.RubyAccessibilityService.readClipboard(getApplication())
                if (!clipText.isNullOrEmpty()) {
                    speakSpeechSafe("Copied clipboard text hai: $clipText")
                } else {
                    speakSpeechSafe("Clipboard me koi text nahi mila, Boss.")
                }
                true
            }
            lower.contains("screenshot lo") || lower.contains("take screenshot") || lower.contains("screen capture") -> {
                val taken = com.example.service.RubyAccessibilityService.takeScreenshot()
                if (taken) {
                    speakSpeechSafe("Screenshot le liya hai, Boss!")
                } else {
                    speakSpeechSafe("Screenshot ke liye Accessibility Service active honi chahiye, Boss.")
                }
                true
            }
            lower.contains("hack mode") || lower.contains("cyber scan") || lower.contains("security scan") || lower.contains("port scan") || lower.contains("vulnerability scan") -> {
                val statusMsg = "Hacker Mode Active! Network Security Scanner, Termux Tool Suite, and Automated Exploit Auditing enabled for Ethical Testing, Boss!"
                repository.logMemory("Ruby Ethical Cyber Security Mode activated.", "SECURITY", "COMPLETED")
                speakSpeechSafe(statusMsg)
                true
            }
            lower.contains("gamer mode") || lower.contains("game play karo") || lower.contains("auto play game") || lower.contains("game khelo") || lower.contains("pro gamer mode") -> {
                val statusMsg = "Gamer Mode Active! Automated AI Gameplay, high-FPS tap/swipe macros, and Game Agent controls are ready, Boss! Bolne par game bhi khelungi!"
                repository.logMemory("Ruby Pro Gamer Mode activated.", "GAMING", "COMPLETED")
                speakSpeechSafe(statusMsg)
                true
            }
            else -> false
        }
    }

    fun sendMessage(userText: String) {
        if (userText.trim().isEmpty()) return

        // Save memories automatically from conversation (ignoring small talk)
        extractAndSaveMemories(userText)

        viewModelScope.launch {
            // 1. Insert User Message
            val userMsg = ChatMessage(text = userText, isUser = true)
            repository.insertMessage(userMsg)

            // Native Intent Analysis via C++ NDK/JNI Core
            val nativeIntent = RubyNativeCore.analyzeIntent(userText)
            Log.d("RubyViewModel", "Native Core analyzed intent: $nativeIntent")

            // Check if user is issuing a direct System Control command (Volume, Torch, Media, Clipboard, Screenshot)
            if (handleSystemCommands(userText)) {
                _isRubyThinking.value = false
                _currentStatusText.value = "Executed system command [$nativeIntent]!"
                return@launch
            }

            _isRubyThinking.value = true
            _currentStatusText.value = "Analyzing instructions..."

            // 2. Fetch current list of messages for context
            val currentHistory = messages.value

            // 3. Request Gemini API Response
            var response = repository.generateResponse(userText, currentHistory, getApplication())

            // 4. Update thinking state
            _isRubyThinking.value = false
            _currentStatusText.value = "Ruby is replying..."

            // Check if user is requesting to open any app, editor, camera, gallery, or social app
            val lowerText = userText.lowercase()
            when {
                lowerText.contains("termux") || lowerText.contains("terminal") || (lowerText.contains("script") && lowerText.contains("run")) -> {
                    triggerAppLaunch(LaunchTargetType.GENERIC_APP, "Termux", searchKeyword = "com.termux")
                    _currentStatusText.value = "Executing Termux script command..."
                }
                lowerText.contains("capcut") -> triggerAppLaunch(LaunchTargetType.CAPCUT, "CapCut Video Editor")
                lowerText.contains("kinemaster") -> triggerAppLaunch(LaunchTargetType.KINEMASTER, "KineMaster Video Editor")
                lowerText.contains("picsart") -> triggerAppLaunch(LaunchTargetType.PICSART, "PicsArt Photo Editor")
                lowerText.contains("lightroom") -> triggerAppLaunch(LaunchTargetType.LIGHTROOM, "Adobe Lightroom")
                lowerText.contains("inshot") -> triggerAppLaunch(LaunchTargetType.INSHOT, "InShot Video Editor")
                lowerText.contains("youtube") -> triggerAppLaunch(LaunchTargetType.YOUTUBE, "YouTube", "com.google.android.youtube")
                lowerText.contains("whatsapp") -> triggerAppLaunch(LaunchTargetType.WHATSAPP, "WhatsApp", "com.whatsapp")
                lowerText.contains("instagram") || lowerText.contains("insta") -> triggerAppLaunch(LaunchTargetType.INSTAGRAM, "Instagram", "com.instagram.android")
                lowerText.contains("facebook") || lowerText.contains("fb") -> triggerAppLaunch(LaunchTargetType.FACEBOOK, "Facebook", "com.facebook.katana")
                lowerText.contains("chrome") || lowerText.contains("browser") -> triggerAppLaunch(LaunchTargetType.CHROME, "Google Chrome", "com.android.chrome")
                lowerText.contains("setting") || lowerText.contains("settings") -> triggerAppLaunch(LaunchTargetType.SETTINGS, "Settings")
                lowerText.contains("calculator") || lowerText.contains("calc") -> triggerAppLaunch(LaunchTargetType.CALCULATOR, "Calculator")
                lowerText.contains("spotify") -> triggerAppLaunch(LaunchTargetType.SPOTIFY, "Spotify", "com.spotify.music")
                lowerText.contains("telegram") -> triggerAppLaunch(LaunchTargetType.TELEGRAM, "Telegram", "org.telegram.messenger")
                lowerText.contains("play store") || lowerText.contains("playstore") -> triggerAppLaunch(LaunchTargetType.PLAYSTORE, "Play Store", "com.android.vending")
                lowerText.contains("gmail") -> triggerAppLaunch(LaunchTargetType.GMAIL, "Gmail", "com.google.android.gm")
                lowerText.contains("video edit") || lowerText.contains("video editor") || lowerText.contains("video app") -> triggerAppLaunch(LaunchTargetType.VIDEO_EDITOR, "Video Editor")
                lowerText.contains("photo edit") || lowerText.contains("photo editor") || lowerText.contains("picture edit") || lowerText.contains("image edit") -> triggerAppLaunch(LaunchTargetType.PHOTO_EDITOR, "Photo Editor")
                lowerText.contains("camera") -> triggerAppLaunch(LaunchTargetType.CAMERA, "Camera")
                lowerText.contains("gallery") || lowerText.contains("photos kholo") -> triggerAppLaunch(LaunchTargetType.GALLERY, "Gallery")
                lowerText.contains("kholo") || lowerText.contains("open") || lowerText.contains("chalao") || lowerText.contains("launch") -> {
                    val appName = userText
                        .replace(Regex("(?i)kholo|open|chalao|launch|app|ko|please|ruby|samad|bhai"), "")
                        .trim()
                    if (appName.isNotEmpty()) {
                        triggerAppLaunch(LaunchTargetType.GENERIC_APP, appName, searchKeyword = appName)
                    }
                }
            }

            // Check if user is asking to draw/generate an image or graphic
            val isImageRequest = userText.contains("draw", ignoreCase = true) ||
                    userText.contains("image", ignoreCase = true) ||
                    userText.contains("paint", ignoreCase = true) ||
                    userText.contains("imagine", ignoreCase = true) ||
                    userText.contains("photo of", ignoreCase = true) ||
                    userText.contains("picture", ignoreCase = true) ||
                    userText.contains("graphic", ignoreCase = true) ||
                    userText.contains("thumbnail", ignoreCase = true) ||
                    userText.contains("logo", ignoreCase = true) ||
                    userText.contains("pollination", ignoreCase = true)

            if (isImageRequest) {
                try {
                    // Extract a clean prompt for image generation
                    val cleanPrompt = userText
                        .replace(Regex("(?i)draw|generate image of|create image of|make image of|imagine|photo of|picture of|graphic of|thumbnail of|logo of|pollinations|generate picture of|paint"), "")
                        .trim()
                        .ifEmpty { userText }
                    
                    val encoded = java.net.URLEncoder.encode(cleanPrompt, "UTF-8")
                    val seed = (10000..99999).random()
                    val imageUrl = "https://image.pollinations.ai/p/$encoded?width=800&height=800&nologo=true&seed=$seed"
                    
                    response += "\n\n[POLLINATIONS_IMAGE: $imageUrl]"
                    repository.logMemory("Generated custom AI asset with Pollinations: $cleanPrompt", "SYSTEM", "COMPLETED")
                } catch (e: Exception) {
                    Log.e("RubyViewModel", "Failed to generate pollinations image link", e)
                }
            }

            val isSaveSongRequest = lowerText.contains("save") && (lowerText.contains("ruby") || lowerText.contains("folder") || lowerText.contains("song") || lowerText.contains("gana"))
            val isSongRequest = lowerText.contains("song") || lowerText.contains("gana") || lowerText.contains("guitar") || lowerText.contains("gitar") ||
                    lowerText.contains("gao") || lowerText.contains("sing") || lowerText.contains("music") || lowerText.contains("tune") || lowerText.contains("dhun")

            if (isSaveSongRequest) {
                saveCurrentSongToRubyFolder()
            } else if (isSongRequest) {
                val songTitle = userText
                    .replace(Regex("(?i)gana|song|guitar|gitar|gao|sing|music|play|sonao|sunao|ke|ka|par|banao|me|me|ko"), "")
                    .trim()
                    .ifEmpty { "Ruby_Special_Melody" }
                playSongWithGuitar(songTitle, response)
            }

            // 5. Parse Emotion & Trigger Dynamic NDK Blendshapes
            val parsedResponse = com.example.util.RubyPersonaManager.parseResponse(response)

            // 6. Insert Assistant Response into Chat DB
            val assistantMsg = ChatMessage(text = parsedResponse.fullDisplayText, isUser = false)
            repository.insertMessage(assistantMsg)

            // 7. Speak Response Out Loud with clean speakable text (emotion tags stripped out)
            speakSpeechSafe(parsedResponse.speakableText)

            // 8. Parse if there's any file/project or feature addon generation requests or phone actions embedded in response
            parseAndGenerateApp(parsedResponse.fullDisplayText)
            parseAndGenerateAddon(parsedResponse.fullDisplayText)
            parseAndExecutePhoneActions(parsedResponse.fullDisplayText)
        }
    }

    // Generate and download a binary graphic asset from Pollinations directly into the project directory!
    fun generateAndSaveProjectAsset(projectId: Int, assetName: String, prompt: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _currentStatusText.value = "Downloading asset from Pollinations..."
                val project = repository.getProjectById(projectId)
                if (project != null) {
                    val encoded = java.net.URLEncoder.encode(prompt, "UTF-8")
                    val seed = (10000..99999).random()
                    val imageUrl = "https://image.pollinations.ai/p/$encoded?width=600&height=600&nologo=true&seed=$seed"
                    
                    val projectFolder = File(project.storageFolderPath)
                    val physicalFile = File(projectFolder, assetName)
                    physicalFile.parentFile?.mkdirs()
                    
                    // Read bytes directly from the Pollinations endpoint and save as physical file!
                    val bytes = java.net.URL(imageUrl).readBytes()
                    physicalFile.writeBytes(bytes)
                    
                    // Store as project file descriptor
                    repository.addProjectFile(
                        projectId = projectId,
                        fileName = assetName,
                        content = "[BINARY_ASSET_IMAGE: $imageUrl]",
                        relPath = assetName
                    )
                    
                    repository.logMemory("Created custom visual asset '$assetName' using Pollinations AI.", "APP_BUILD", "COMPLETED")
                    _currentStatusText.value = "Saved asset $assetName inside workspace."
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("RubyViewModel", "Failed to download asset from Pollinations", e)
                _currentStatusText.value = "Failed to fetch asset: ${e.message}"
                onComplete(false)
            }
        }
    }

    private fun parseAndGenerateApp(response: String) {
        // Look for: [GENERATE_APP: name | type | description]
        val appPattern = Pattern.compile("\\[GENERATE_APP:\\s*(.*?)\\s*\\|\\s*(.*?)\\s*\\|\\s*(.*?)\\s*\\]", Pattern.CASE_INSENSITIVE)
        val appMatcher = appPattern.matcher(response)
        
        if (appMatcher.find()) {
            val projectName = appMatcher.group(1)?.trim() ?: "Unnamed Project"
            val projectType = appMatcher.group(2)?.trim() ?: "Web HTML/CSS/JS"
            val projectDesc = appMatcher.group(3)?.trim() ?: "Auto-generated project"

            viewModelScope.launch {
                _currentStatusText.value = "Creating directory and generating project files..."
                repository.logMemory("Ruby started generating project: $projectName", "APP_BUILD", "IN_PROGRESS")
                
                // Set up Storage Folder inside external files directory (Android 15 crash-safe)
                val storageDir = try {
                    getApplication<Application>().getExternalFilesDir("Ruby") ?: getApplication<Application>().filesDir
                } catch (e: Exception) {
                    getApplication<Application>().filesDir
                }
                val projectFolder = File(storageDir, "RubyProjects/$projectName")
                if (!projectFolder.exists()) {
                    projectFolder.mkdirs()
                }

                // Create database entry for project
                val projectId = repository.createProject(projectName, projectDesc, projectType, projectFolder.absolutePath).toInt()

                // Parse individual files: [FILE: filename] file content [FILE_END]
                val filePattern = Pattern.compile("\\[FILE:\\s*(.*?)\\s*\\](.*?)\\[FILE_END\\]", Pattern.DOTALL)
                val fileMatcher = filePattern.matcher(response)
                var fileCount = 0

                while (fileMatcher.find()) {
                    val fileName = fileMatcher.group(1)?.trim() ?: "file_$fileCount"
                    val fileContent = fileMatcher.group(2)?.trim() ?: ""

                    // Add file to DB
                    repository.addProjectFile(projectId, fileName, fileContent, fileName)

                    // Write file to physical storage directory
                    try {
                        val physicalFile = File(projectFolder, fileName)
                        physicalFile.parentFile?.mkdirs()
                        physicalFile.writeText(fileContent)
                    } catch (e: Exception) {
                        Log.e("RubyAppBuilder", "Failed to write physical file", e)
                    }

                    fileCount++
                }

                repository.logMemory("Created project $projectName with $fileCount source files inside physical directory: ${projectFolder.name}", "APP_BUILD", "COMPLETED")
                _currentStatusText.value = "Built $projectName successfully! Files saved in storage."
                speakSpeechSafe("Boss, maine aapka app, $projectName storage par folder bana kar generate kar diya hai!")
            }
        }
    }

    private fun parseAndGenerateAddon(response: String) {
        // Look for: [CREATE_ADDON: name | description]
        val addonPattern = Pattern.compile("\\[CREATE_ADDON:\\s*(.*?)\\s*\\|\\s*(.*?)\\s*\\]", Pattern.CASE_INSENSITIVE)
        val addonMatcher = addonPattern.matcher(response)

        if (addonMatcher.find()) {
            val addonName = addonMatcher.group(1)?.trim() ?: "Ruby Dynamic Addon"
            val addonDesc = addonMatcher.group(2)?.trim() ?: "Custom feature generated by Ruby AI"

            // Look for script inside [ADDON_SCRIPT] ... [ADDON_SCRIPT_END] or [FILE: ...] ... [FILE_END]
            val scriptPattern = Pattern.compile("\\[(?:ADDON_SCRIPT|FILE:.*?)\\](.*?)\\[(?:ADDON_SCRIPT_END|FILE_END)\\]", Pattern.DOTALL)
            val scriptMatcher = scriptPattern.matcher(response)
            val scriptContent = if (scriptMatcher.find()) scriptMatcher.group(1)?.trim() ?: "" else "// Ruby $addonName addon script\nconsole.log('$addonName active');"

            viewModelScope.launch {
                val registered = com.example.util.RubyAddonManager.registerAddon(
                    context = getApplication(),
                    name = addonName,
                    description = addonDesc,
                    scriptContent = scriptContent,
                    author = "Ruby AI (Self-Created)"
                )

                if (registered != null) {
                    repository.logMemory("Ruby created and installed new addon: $addonName", "ADDON_BUILD", "COMPLETED")
                    _currentStatusText.value = "Installed new Ruby Addon: $addonName"
                    speakSpeechSafe("Boss! Maine apne liye naya feature addon '$addonName' bana kar Ruby folder me save aur activate kar diya hai!")
                }
            }
        }
    }

    private fun parseAndExecutePhoneActions(response: String) {
        val context = getApplication<Application>()

        // 1. Launch App tag: [LAUNCH_APP: AppName or Package]
        val appPattern = Pattern.compile("\\[LAUNCH_APP:\\s*(.*?)\\]", Pattern.CASE_INSENSITIVE)
        val appMatcher = appPattern.matcher(response)
        while (appMatcher.find()) {
            val target = appMatcher.group(1)?.trim() ?: ""
            if (target.isNotEmpty()) {
                launchAppByNameOrPackage(context, target)
            }
        }

        // 2. Generic Phone Actions: [PHONE_ACTION: ACTION_TYPE (| ARG1 (| ARG2)? )?]
        val phonePattern = Pattern.compile("\\[PHONE_ACTION:\\s*(.*?)\\]", Pattern.CASE_INSENSITIVE)
        val phoneMatcher = phonePattern.matcher(response)
        while (phoneMatcher.find()) {
            val content = phoneMatcher.group(1)?.trim() ?: ""
            val parts = content.split("|").map { it.trim() }
            val actionType = parts.getOrNull(0)?.uppercase() ?: ""

            when (actionType) {
                "CLICK_TEXT", "CLICK" -> {
                    val text = parts.getOrNull(1)?.removeSurrounding("\"") ?: ""
                    if (text.isNotEmpty()) {
                        com.example.service.RubyAccessibilityService.performClickOnText(text)
                    }
                }
                "TYPE", "INPUT" -> {
                    val text = parts.getOrNull(1)?.removeSurrounding("\"") ?: ""
                    if (text.isNotEmpty()) {
                        com.example.service.RubyAccessibilityService.typeIntoFocusedNode(text)
                    }
                }
                "HOME" -> com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                "BACK" -> com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                "RECENTS" -> com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                "NOTIFICATIONS" -> com.example.service.RubyAccessibilityService.triggerGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                "SCREENSHOT" -> com.example.service.RubyAccessibilityService.takeScreenshot()
                "TORCH_ON" -> com.example.service.RubyAccessibilityService.setTorch(context, true)
                "TORCH_OFF" -> com.example.service.RubyAccessibilityService.setTorch(context, false)
                "VOLUME_UP" -> com.example.service.RubyAccessibilityService.adjustVolume(context, true)
                "VOLUME_DOWN" -> com.example.service.RubyAccessibilityService.adjustVolume(context, false)
                "TAP" -> {
                    val x = parts.getOrNull(1)?.toFloatOrNull() ?: 500f
                    val y = parts.getOrNull(2)?.toFloatOrNull() ?: 500f
                    com.example.service.RubyAccessibilityService.performTap(x, y)
                }
                "SWIPE" -> {
                    val x1 = parts.getOrNull(1)?.toFloatOrNull() ?: 500f
                    val y1 = parts.getOrNull(2)?.toFloatOrNull() ?: 1000f
                    val x2 = parts.getOrNull(3)?.toFloatOrNull() ?: 500f
                    val y2 = parts.getOrNull(4)?.toFloatOrNull() ?: 300f
                    com.example.service.RubyAccessibilityService.performSwipe(x1, y1, x2, y2)
                }
            }
        }
    }

    private fun launchAppByNameOrPackage(context: Context, appNameOrPackage: String) {
        try {
            val pm: PackageManager = context.packageManager
            var intent: Intent? = pm.getLaunchIntentForPackage(appNameOrPackage)
            if (intent == null) {
                val installedApps: List<ApplicationInfo> = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                for (i in installedApps.indices) {
                    val appInfo = installedApps[i]
                    val label = pm.getApplicationLabel(appInfo).toString()
                    if (label.equals(appNameOrPackage, ignoreCase = true) || label.lowercase().contains(appNameOrPackage.lowercase())) {
                        intent = pm.getLaunchIntentForPackage(appInfo.packageName)
                        if (intent != null) break
                    }
                }
            }
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e("RubyViewModel", "Failed to launch app $appNameOrPackage", e)
        }
    }

    // Active Project Workspace Selection
    fun selectProject(projectId: Int?) {
        _selectedProjectId.value = projectId
    }

    // Manual Code Modifier in Workspace
    fun saveProjectFileContent(projectId: Int, fileId: Int, fileName: String, content: String, relPath: String) {
        viewModelScope.launch {
            // Update db
            val updatedFile = ProjectFile(id = fileId, projectId = projectId, fileName = fileName, fileContent = content, relativePath = relPath)
            repository.addProjectFile(projectId, fileName, content, relPath)

            // Update physical storage
            val project = repository.getProjectById(projectId)
            if (project != null) {
                val projectFolder = File(project.storageFolderPath)
                try {
                    val physicalFile = File(projectFolder, fileName)
                    physicalFile.writeText(content)
                    repository.logMemory("User updated source file '$fileName' manually.", "APP_BUILD", "COMPLETED")
                    _currentStatusText.value = "Updated $fileName successfully."
                } catch (e: Exception) {
                    Log.e("RubyAppBuilder", "Failed to write physical file manual edit", e)
                }
            }
        }
    }

    // YouTube Draft Generation (manual trigger or via chat auto-detection)
    fun saveYouTubeDraft(title: String, desc: String, tags: String, replies: String) {
        viewModelScope.launch {
            repository.createYouTubeDraft(title, desc, tags, replies)
            repository.logMemory("Saved YouTube Video optimization draft for: '$title'", "YOUTUBE_POST", "COMPLETED")
            _currentStatusText.value = "Saved YouTube draft."
        }
    }

    fun speakSamadDeleteCheck() {
        speakSpeechSafe("Samad bhai, kya is ko delete karu?")
    }

    fun deleteYouTubeDraft(id: Int) {
        viewModelScope.launch {
            repository.deleteYouTubeDraft(id)
            repository.logMemory("Deleted YouTube draft.", "YOUTUBE_POST", "COMPLETED")
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            val project = repository.getProjectById(id)
            if (project != null) {
                // Delete physical files
                val folder = File(project.storageFolderPath)
                if (folder.exists()) {
                    folder.deleteRecursively()
                }
                repository.deleteProject(id)
                repository.logMemory("Deleted project folder: ${project.projectName}", "APP_BUILD", "COMPLETED")
                _currentStatusText.value = "Project deleted."
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearChat()
            repository.logMemory("Cleared chat logs and conversation memories.", "SYSTEM", "COMPLETED")
            _currentStatusText.value = "Conversation logs cleared, Boss!"
        }
    }

    fun clearSystemLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            repository.logMemory("System action logs reset.", "SYSTEM", "COMPLETED")
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
